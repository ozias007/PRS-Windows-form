USE PremierServiceSolutions;

DECLARE @requestCount INT = 1;

WHILE @requestCount <= 50
BEGIN
    DECLARE @RequestDate DATETIME = DATEADD(DAY, -(RAND() * 365), GETDATE());
    DECLARE @ScheduledDate DATETIME = DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 30), @RequestDate);
    DECLARE @CompletedDate DATETIME = NULL;
    DECLARE @ExpectedDuration FLOAT = ABS(CHECKSUM(NEWID()) % 241);
    DECLARE @FinalDuration FLOAT = NULL;
    DECLARE @MaintenanceType NVARCHAR(50) = 
        CASE 
            WHEN ABS(CHECKSUM(NEWID()) % 3) = 0 THEN 'Mechanical'
            WHEN ABS(CHECKSUM(NEWID()) % 3) = 1 THEN 'Electrical'
            ELSE 'General'
        END;
    DECLARE @Priority NVARCHAR(25) = 
        CASE 
            WHEN ABS(CHECKSUM(NEWID()) % 3) = 0 THEN 'High'
            WHEN ABS(CHECKSUM(NEWID()) % 3) = 1 THEN 'Medium'
            ELSE 'Low'
        END;
    DECLARE @Status NVARCHAR(25) = 'Open';

    INSERT INTO WorkRequest (RequestDate, ScheduledDate, CompletedDate, ExpectedDuration, FinalDuration, MaintenanceType, [Priority], [Status])
    VALUES (@RequestDate, @ScheduledDate, @CompletedDate, @ExpectedDuration, @FinalDuration, @MaintenanceType, @Priority, @Status);

    DECLARE @LatestRequestID INT = SCOPE_IDENTITY();

    IF @requestCount > 10
    BEGIN
        DECLARE @TechnicianID INT;
        SELECT TOP 1 @TechnicianID = TechnicianID 
        FROM Technician
        ORDER BY NEWID();

        INSERT INTO WorkRequestAssignedTechnicians (RequestID, TechnicianID)
        VALUES (@LatestRequestID, @TechnicianID);

        DECLARE @ReportID INT;
        SELECT TOP 1 @ReportID = ReportID 
        FROM CallReport
        ORDER BY NEWID();

        INSERT INTO WorkRequestAssignedReports (RequestID, ReportID)
        VALUES (@LatestRequestID, @ReportID);

        UPDATE WorkRequest
        SET [Status] = 'In-progress'
        WHERE RequestID = @LatestRequestID;

        IF ABS(CHECKSUM(NEWID()) % 3) = 0 
        BEGIN
            SET @CompletedDate = DATEADD(MINUTE, ABS(CHECKSUM(NEWID()) % 121), @ScheduledDate);
            SET @FinalDuration = DATEDIFF(MINUTE, @ScheduledDate, @CompletedDate);
            UPDATE WorkRequest
            SET [Status] = 'Closed', CompletedDate = @CompletedDate, FinalDuration = @FinalDuration
            WHERE RequestID = @LatestRequestID;
        END
    END

    SET @requestCount = @requestCount + 1;
END;
