USE PremierServiceSolutions;

DECLARE @clientCount INT = 1;
DECLARE @individualClientCount INT = 0;
DECLARE @businessClientCount INT = 0;
DECLARE @addressID INT = 51;

WHILE @clientCount <= 50
BEGIN

    DECLARE @FirstName NVARCHAR(100) = 'ClientFirstName' + CAST(@clientCount AS NVARCHAR(3));
    DECLARE @LastName NVARCHAR(100) = 'ClientLastName' + CAST(@clientCount AS NVARCHAR(3));
    DECLARE @RegistrationDate DATETIME = DATEADD(YEAR, -1 - (RAND() * 10), GETDATE());
    DECLARE @Email NVARCHAR(50) = 'client' + CAST(@clientCount AS NVARCHAR(3)) + '@example.com';
    DECLARE @Phone NVARCHAR(25) = '+27' + 
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1));
    DECLARE @Category NVARCHAR(25);
    DECLARE @Status NVARCHAR(25) = CASE WHEN RAND() < 0.5 THEN 'Active' ELSE 'Inactive' END;
    DECLARE @Notes NVARCHAR(100);

    IF @individualClientCount < 25
    BEGIN
        SET @Category = 'Individual';
    END
    ELSE
    BEGIN
        SET @Category = 'Business';
    END

    INSERT INTO Client (AddressID, Category, FirstName, LastName, RegistrationDate, Email, Phone, [Status], Notes)
    VALUES (@addressID, @Category, @FirstName, @LastName, @RegistrationDate, @Email, @Phone, @Status, @Notes);

    DECLARE @LatestClientID INT = SCOPE_IDENTITY();

    IF @Category = 'Individual'
    BEGIN
        DECLARE @DateOfBirth DATETIME = DATEADD(YEAR, -25 - (RAND() * 50), GETDATE());

        INSERT INTO IndividualClient (ClientID, DateOfBirth)
        VALUES (@LatestClientID, @DateOfBirth);

        SET @individualClientCount = @individualClientCount + 1;
    END

    ELSE IF @Category = 'Business'
    BEGIN
        DECLARE @BusinessName NVARCHAR(100) = 'Biz' + CAST(@clientCount AS NVARCHAR(3));
        DECLARE @ContactTitle NVARCHAR(50) = CASE FLOOR(RAND() * 3)
            WHEN 0 THEN 'CEO'
            WHEN 1 THEN 'Manager'
            ELSE 'Coordinator'
        END;

        INSERT INTO BusinessClient (ClientID, BusinessName, ContactTitle)
        VALUES (@LatestClientID, @BusinessName, @ContactTitle);

        SET @businessClientCount = @businessClientCount + 1;
    END

    SET @addressID = @addressID + 1;
    SET @clientCount = @clientCount + 1;
END;
