USE PremierServiceSolutions;

DECLARE @counter INT = 1;

WHILE @counter <= 50
BEGIN
    DECLARE @Category NVARCHAR(25);
    DECLARE @Level NVARCHAR(25);
    DECLARE @Price FLOAT;
    DECLARE @ServiceName NVARCHAR(100);
    DECLARE @Description NVARCHAR(100);
    
    -- Randomly choose a category
    SELECT @Category = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.33 THEN 'General'
            WHEN RAND() BETWEEN 0.34 AND 0.66 THEN 'Mechanical'
            ELSE 'Electrical'
        END;

    -- Randomly choose a level
    SELECT @Level = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.33 THEN 'High'
            WHEN RAND() BETWEEN 0.34 AND 0.66 THEN 'Medium'
            ELSE 'Low'
        END;

    -- Generate a random price between $10 and $1000
    SELECT @Price = ROUND(RAND() * 990 + 10, 2);

    -- Generate service name and description based on the counter
    SELECT @ServiceName = 'ServiceName_' + CAST(@counter AS NVARCHAR(5));
    SELECT @Description = 'Description for ' + @ServiceName;

    -- Insert into the table
    INSERT INTO [Service]([Name], Category, Price, [Level], [Description])
    VALUES (@ServiceName, @Category, @Price, @Level, @Description);
    
    SET @counter = @counter + 1;
END;


DECLARE @PackageCounter INT = 1;
DECLARE @LastServiceIDUsed INT = 0;

WHILE @PackageCounter <= 25
BEGIN
    DECLARE @AvailableFrom DATE;
    DECLARE @AvailableUntil DATE;
    DECLARE @Status NVARCHAR(25);

    -- Randomly generate AvailableFrom and AvailableUntil dates within a year's range
    SELECT @AvailableFrom = DATEADD(DAY, (RAND() * 365), GETDATE());
    SELECT @AvailableUntil = DATEADD(DAY, (RAND() * 30), @AvailableFrom);

    -- Randomly determine the status
    SELECT @Status = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.5 THEN 'Available'
            ELSE 'Unavailable'
        END;

    -- Insert into ServicePackage table
    INSERT INTO ServicePackage(AvailableFrom, AvailableUntil, [Status])
    VALUES (@AvailableFrom, @AvailableUntil, @Status);
    
    -- Assuming ServiceIDs were generated from 1 to 50 sequentially
    -- Associate this package with the next 2 services
    INSERT INTO ServicePackageServices(PackageID, ServiceID)
    VALUES (@PackageCounter, @LastServiceIDUsed + 1),
           (@PackageCounter, @LastServiceIDUsed + 2);
    
    SET @LastServiceIDUsed = @LastServiceIDUsed + 2;
    SET @PackageCounter = @PackageCounter + 1;
END;

-- Additional logic to cover the condition of having some packages with 3 services
-- This will add 8 more packages, associating them with the remaining services and then looping over from the start

WHILE @PackageCounter <= 33
BEGIN

    -- Randomly generate AvailableFrom and AvailableUntil dates within a year's range
    SELECT @AvailableFrom = DATEADD(DAY, (RAND() * 365), GETDATE());
    SELECT @AvailableUntil = DATEADD(DAY, (RAND() * 30), @AvailableFrom);

    -- Randomly determine the status
    SELECT @Status = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.5 THEN 'Available'
            ELSE 'Unavailable'
        END;

    -- Insert into ServicePackage table
    INSERT INTO ServicePackage(AvailableFrom, AvailableUntil, [Status])
    VALUES (@AvailableFrom, @AvailableUntil, @Status);
    
    -- Loop over from the start if we've covered all 50 services
    IF @LastServiceIDUsed >= 50
        SET @LastServiceIDUsed = 0;
    
    -- Associate this package with the next 3 services
    INSERT INTO ServicePackageServices(PackageID, ServiceID)
    VALUES (@PackageCounter, @LastServiceIDUsed + 1),
           (@PackageCounter, @LastServiceIDUsed + 2),
           (@PackageCounter, @LastServiceIDUsed + 3);
    
    SET @LastServiceIDUsed = @LastServiceIDUsed + 3;
    SET @PackageCounter = @PackageCounter + 1;
END;

-- ... [Previous scripts for adding services and service packages] ...

DECLARE @SlaCounter INT = 1;

WHILE @SlaCounter <= 25 -- Assuming we are adding 25 SLA entries for demonstration purposes
BEGIN
    DECLARE @ServicePackageDetails NVARCHAR(MAX);
    DECLARE @ServicePriorityDetails NVARCHAR(MAX);
    DECLARE @TargetPerformanceDetails NVARCHAR(MAX);
    DECLARE @PartyObligationDetails NVARCHAR(MAX);
    DECLARE @BreachPenaltyDetails NVARCHAR(MAX);
    DECLARE @MetricProtocolDetails NVARCHAR(MAX);
    DECLARE @SLADescription NVARCHAR(100);
    
    -- Generating random ServicePackageDetails with 1 to 5 random PackageIDs
    DECLARE @NumberOfPackages INT = CEILING(RAND() * 5);
    DECLARE @PackageList NVARCHAR(MAX) = '';
    DECLARE @i INT = 0;
    WHILE @i < @NumberOfPackages
    BEGIN
        -- Randomly selecting a PackageID between 1 and 33 (as we created 33 packages before)
        DECLARE @RandomPackageID INT = CEILING(RAND() * 33);
        SET @PackageList = @PackageList + CAST(@RandomPackageID AS NVARCHAR(5)) + ', ';
        SET @i = @i + 1;
    END
    SET @ServicePackageDetails = LEFT(@PackageList, LEN(@PackageList) - 2); -- Removing the last ', '

    -- Generating random details based on SlaCounter
    SET @SLADescription = 'SLA Description ' + CAST(@SlaCounter AS NVARCHAR(5));
    SET @ServicePriorityDetails = 'Priority Details for SLA ' + CAST(@SlaCounter AS NVARCHAR(5));
    SET @TargetPerformanceDetails = 'Performance Details for SLA ' + CAST(@SlaCounter AS NVARCHAR(5));
    SET @PartyObligationDetails = 'Obligation Details for SLA ' + CAST(@SlaCounter AS NVARCHAR(5));
    SET @BreachPenaltyDetails = 'Breach Details for SLA ' + CAST(@SlaCounter AS NVARCHAR(5));
    SET @MetricProtocolDetails = 'Metric Details for SLA ' + CAST(@SlaCounter AS NVARCHAR(5));
    
    -- Inserting into SLA table
    INSERT INTO SLA([Description], ServicePackageDetails, ServicePriorityDetails, TargetPerformanceDetails, 
                   PartyObligationDetails, BreachPenaltyDetails, MetricProtocolDetails)
    VALUES (@SLADescription, @ServicePackageDetails, @ServicePriorityDetails, @TargetPerformanceDetails, 
            @PartyObligationDetails, @BreachPenaltyDetails, @MetricProtocolDetails);
    
    SET @SlaCounter = @SlaCounter + 1;
END;

