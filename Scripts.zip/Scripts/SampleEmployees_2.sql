USE PremierServiceSolutions;

DECLARE @empCount INT = 1;
DECLARE @managerCount INT = 0;
DECLARE @technicianCount INT = 0;
DECLARE @Areas TABLE (Area NVARCHAR(25));
INSERT INTO @Areas (Area) VALUES ('Electrical'), ('Mechanical'), ('General');

WHILE @empCount <= 50
BEGIN
    DECLARE @FirstName NVARCHAR(100) = 'EmpFirstName' + CAST(@empCount AS NVARCHAR(3));
    DECLARE @LastName NVARCHAR(100) = 'EmpLastName' + CAST(@empCount AS NVARCHAR(3));
    DECLARE @DateOfBirth DATETIME = DATEADD(YEAR, -25 - (RAND() * 20), GETDATE());
    DECLARE @Email NVARCHAR(50) = 'employee' + CAST(@empCount AS NVARCHAR(3)) + '@example.com';
    DECLARE @Phone NVARCHAR(25) = '+27' + 
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1)) +
            CAST(ABS(CHECKSUM(NEWID())) % 10 AS NVARCHAR(1));
    DECLARE @Category NVARCHAR(25);
    DECLARE @Status NVARCHAR(25) = CASE WHEN RAND() < 0.5 THEN 'Available' ELSE 'Unavailable' END;
    DECLARE @Schedule NVARCHAR(25) = CASE FLOOR(RAND() * 3)
        WHEN 0 THEN 'Primary'
        WHEN 1 THEN 'Secondary'
        ELSE 'Tertiary'
    END;
    DECLARE @Salary FLOAT = ROUND(30000 + (RAND() * 20000), 2);
    DECLARE @Notes NVARCHAR(100);

    IF @technicianCount < 20
    BEGIN
        SET @Category = 'Technician';
    END
    ELSE
    BEGIN
        SELECT TOP 1 @Category = Category 
        FROM (VALUES ('Technician'), ('Manager'), ('General')) AS C(Category)
        ORDER BY NEWID();
    END

    INSERT INTO Employee (AddressID, FirstName, LastName, DateOfBirth, Email, Phone, Category, [Status], Schedule, Salary, Notes)
    VALUES (@empCount, @FirstName, @LastName, @DateOfBirth, @Email, @Phone, @Category, @Status, @Schedule, @Salary, @Notes);

    DECLARE @LatestEmployeeID INT = SCOPE_IDENTITY();

    IF @Category = 'Technician'
    BEGIN
        DECLARE @CompletedRequests INT = FLOOR(RAND() * 100);
        DECLARE @Specialization NVARCHAR(25) = CASE FLOOR(RAND() * 3)
            WHEN 0 THEN 'Electrical'
            WHEN 1 THEN 'Mechanical'
            ELSE 'General'
        END;

        IF @CompletedRequests > 50
        BEGIN
            UPDATE Employee
            SET Notes = 'Experienced'
            WHERE EmployeeID = @LatestEmployeeID;
        END

        INSERT INTO Technician (EmployeeID, CompletedRequests, Specialization)
        VALUES (@LatestEmployeeID, @CompletedRequests, @Specialization);
        
        SET @technicianCount = @technicianCount + 1;
    END

    ELSE IF @Category = 'Manager' AND @managerCount < 5
    BEGIN
        DECLARE @Area NVARCHAR(25);

        IF @managerCount < 3
        BEGIN
            SELECT TOP 1 @Area = Area FROM @Areas ORDER BY NEWID();
            DELETE FROM @Areas WHERE Area = @Area;
        END
        ELSE
        BEGIN
            SELECT TOP 1 @Area = Area 
            FROM (
                VALUES ('Electrical'), ('Mechanical'), ('General')
            ) AS A(Area)
            ORDER BY NEWID();
        END

        INSERT INTO Manager (EmployeeID, Area)
        VALUES (@LatestEmployeeID, @Area);
        
        SET @managerCount = @managerCount + 1;
    END

    SET @empCount = @empCount + 1;
END;
