USE PremierServiceSolutions;

INSERT INTO Account (Username, [Password], Category) 
VALUES 
('admin', '$2a$11$jCRpiqTrv8U0mFDbZdQafOPDp7.Xnsrw0kYC5uieykaNgG2dMdFwq', 'admin'),
('call1', '$2a$11$NUnpnaeqBrMekJW11jlF6OhHPQaVoqs8QBxl.x7JcgaUX6DOgcEqO', 'callcentre'),
('service1', '$2a$11$bAKAPcLF7onJPjWsvZ5Q..xeRdJ5VPeuN0ZWPjsrBBJVnoO7JiieW', 'servicedepartment'),
('client1', '$2a$11$3WsWeKRLR1oz1oWKN/PmbOihoAJKnM2/IYlo4S7LAgX4UtR9uA2om', 'clientmaintenance'),
('contract1', '$2a$11$bI9ZRp6XzoHjnIysm/.AROX2W8WCGuVplk4P88WkvVFAKE78.o.5e', 'contractmaintenance');