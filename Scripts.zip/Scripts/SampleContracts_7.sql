USE PremierServiceSolutions;
GO

-- Variables to determine the number of entries and other data to be populated
DECLARE @NumberOfContracts INT = 50; -- Assuming we want to insert 50 contracts for this example
DECLARE @ContractCounter INT = 1;

WHILE @ContractCounter <= @NumberOfContracts
BEGIN
    DECLARE @RandomPackageID INT;
    DECLARE @RandomSlaID INT;
    DECLARE @Status NVARCHAR(25);
    DECLARE @Details NVARCHAR(MAX);
    DECLARE @Category NVARCHAR(25);
    DECLARE @PurchaseDate DATE = NULL;
    DECLARE @EffectDate DATE = NULL;
    DECLARE @ExpiryDate DATE = NULL;
    DECLARE @RandomClientID INT = NULL;

    -- Randomly select a PackageID, assuming there are 33 based on previous scripts
    SELECT @RandomPackageID = CEILING(RAND() * 33);

    -- Randomly select a SlaID, assuming there are 25 based on previous scripts
    SELECT @RandomSlaID = CEILING(RAND() * 25);

    -- Randomly determine the status
    SELECT @Status = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.5 THEN 'Active'
            ELSE 'Inactive'
        END;

    -- Randomly select a category
    SELECT @Category = 
        CASE 
            WHEN RAND() BETWEEN 0 AND 0.33 THEN 'General'
            WHEN RAND() BETWEEN 0.34 AND 0.66 THEN 'Mechanical'
            ELSE 'Electrical'
        END;

    -- Generating contract details based on ContractCounter
    SET @Details = 'Details for Contract ' + CAST(@ContractCounter AS NVARCHAR(5));

    -- For about half of the contracts, we associate with a client and set the purchase, effect, and expiry dates
    IF RAND() > 0.5
    BEGIN
        -- Randomly selecting a ClientID. Assuming ClientIDs range from 1 to 100 for simplicity. Adjust as per actual data.
        SELECT @RandomClientID = CEILING(RAND() * 100);

        SELECT @PurchaseDate = DATEADD(DAY, (RAND() * 365), GETDATE());
        SELECT @EffectDate = DATEADD(DAY, (RAND() * 10), @PurchaseDate); -- Assuming effect date is within 10 days after purchase
        SELECT @ExpiryDate = DATEADD(YEAR, 1, @EffectDate); -- Assuming a 1-year contract duration
    END

    -- Insert into ServiceContract table
    INSERT INTO ServiceContract(PackageID, SlaID, [Status], Details, [Category], PurchaseDate, EffectDate, ExpiryDate)
    VALUES (@RandomPackageID, @RandomSlaID, @Status, @Details, @Category, @PurchaseDate, @EffectDate, @ExpiryDate);

    -- If a client is associated, insert into ClientContracts
    IF @RandomClientID IS NOT NULL
    BEGIN
        INSERT INTO ClientContracts(ClientID, ContractID)
        VALUES (@RandomClientID, @ContractCounter);
    END
    
    SET @ContractCounter = @ContractCounter + 1;
END;
