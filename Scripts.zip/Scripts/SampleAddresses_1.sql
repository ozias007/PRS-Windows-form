USE PremierServiceSolutions;

DECLARE @count INT = 1;

WHILE @count <= 100
BEGIN
    DECLARE @ProvinceCity TABLE (
        Province NVARCHAR(50),
        City NVARCHAR(50)
    );

    INSERT INTO @ProvinceCity (Province, City)
    VALUES ('Eastern Cape', 'Port Elizabeth'),
           ('Free State', 'Bloemfontein'),
           ('Gauteng', 'Johannesburg'),
           ('Gauteng', 'Pretoria'),
           ('KwaZulu-Natal', 'Durban'),
           ('Limpopo', 'Polokwane'),
           ('Mpumalanga', 'Nelspruit'),
           ('North West', 'Mafikeng'),
           ('Western Cape', 'Cape Town');

    DECLARE @SelectedProvince NVARCHAR(50);
    DECLARE @SelectedCity NVARCHAR(50);

    SELECT TOP 1 @SelectedProvince = Province, @SelectedCity = City 
    FROM @ProvinceCity
    ORDER BY NEWID();

    INSERT INTO [Address] 
        (AddressLine1, AddressLine2, Country, PostalCode, City, Province)
    VALUES 
        (
            'Street ' + CAST(NEWID() AS NVARCHAR(50)),
            'Suburb ' + CAST(NEWID() AS NVARCHAR(50)),
            'South Africa',
            RIGHT(CAST(NEWID() AS NVARCHAR(50)), 4),
            @SelectedCity,
            @SelectedProvince
        );

    DELETE FROM @ProvinceCity;

    SET @count = @count + 1;
END;
