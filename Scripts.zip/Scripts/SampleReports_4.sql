USE PremierServiceSolutions;

DECLARE @reportCount INT = 1;

WHILE @reportCount <= 50
BEGIN
    DECLARE @ClientID INT = CEILING(RAND() * 50);
    DECLARE @Details NVARCHAR(MAX) = 'Details for Report ' + CAST(@reportCount AS NVARCHAR(3));
    DECLARE @Status NVARCHAR(25) = 
        CASE 
            WHEN RAND() < 0.33 THEN 'In-progress'
            WHEN RAND() < 0.66 THEN 'Open'
            ELSE 'Closed'
        END;
    DECLARE @ReportDate DATETIME = DATEADD(DAY, -(RAND() * 365), GETDATE());
    DECLARE @StartTime TIME = '00:00:00';
    DECLARE @EndTime TIME = CAST('00:' + 
                        RIGHT('00' + CAST(FLOOR(RAND() * 60) AS NVARCHAR(2)), 2) + ':' +
                        RIGHT('00' + CAST(FLOOR(RAND() * 60) AS NVARCHAR(2)), 2) AS TIME);

    IF DATEPART(HOUR, @EndTime) >= 2
    BEGIN
        SET @EndTime = '02:00:00';
    END

    INSERT INTO CallReport (ClientID, Details, [Status], ReportDate, StartTime, EndTime)
    VALUES (@ClientID, @Details, @Status, @ReportDate, @StartTime, @EndTime);

    SET @reportCount = @reportCount + 1;
END;
