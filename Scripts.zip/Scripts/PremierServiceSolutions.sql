USE [master];
GO
    DECLARE @directory VARCHAR(MAX)
    SELECT @directory = SUBSTRING(FILENAME, 1, CHARINDEX('master.mdf', LOWER(FILENAME)) - 1)
    FROM master.dbo.sysaltfiles 
    WHERE DBID = 1 AND FILEID = 1
    EXECUTE ('CREATE DATABASE PremierServiceSolutions
        ON PRIMARY (NAME = ''PSS_dat'', 
            FILENAME = ''' + @directory + 'PSSdat.mdf'', 
            SIZE = 100MB, 
            MAXSIZE = UNLIMITED,  
            FILEGROWTH = 50MB )
        LOG ON (NAME = ''PSS_log'',  
            FILENAME = ''' + @directory + 'PSSlog.ldf'',
            SIZE = 20MB,  
            MAXSIZE = 100MB,  
            FILEGROWTH = 5MB)');
GO
ALTER DATABASE [PremierServiceSolutions] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PremierServiceSolutions].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [PremierServiceSolutions] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET ARITHABORT OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [PremierServiceSolutions] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [PremierServiceSolutions] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET  DISABLE_BROKER 
GO
ALTER DATABASE [PremierServiceSolutions] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [PremierServiceSolutions] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [PremierServiceSolutions] SET  MULTI_USER 
GO
ALTER DATABASE [PremierServiceSolutions] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [PremierServiceSolutions] SET DB_CHAINING OFF 
GO
ALTER DATABASE [PremierServiceSolutions] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [PremierServiceSolutions] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [PremierServiceSolutions] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [PremierServiceSolutions] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [PremierServiceSolutions] SET QUERY_STORE = OFF
GO
USE [PremierServiceSolutions]
GO
-- Tables
-- Account
CREATE TABLE Account (
    AccountID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(100) NOT NULL,
    [Password] NVARCHAR(100) NOT NULL,
    Category NVARCHAR(25) NOT NULL
);
GO
-- Address
CREATE TABLE [Address] (
    AddressID INT IDENTITY(1,1) PRIMARY KEY ,
    AddressLine1 NVARCHAR(100) NOT NULL,
    AddressLine2 NVARCHAR(100),
    Country NVARCHAR(50) NOT NULL,
    PostalCode NVARCHAR(25) NOT NULL,
    City NVARCHAR(50) NOT NULL,
    Province NVARCHAR(50) NOT NULL
);
GO
-- Employee
CREATE TABLE Employee (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    AddressID INT NOT NULL,
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    DateOfBirth DATE NOT NULL,
    Email NVARCHAR(50) NOT NULL,
    Phone NVARCHAR(25) NOT NULL,
    Category NVARCHAR(25) NOT NULL,
    [Status] NVARCHAR(25) NOT NULL,
    Schedule NVARCHAR(25) NOT NULL,
    Salary FLOAT NOT NULL,
    Notes NVARCHAR(100),
    FOREIGN KEY (AddressID) REFERENCES [Address](AddressID)
);
GO
-- Technician
CREATE TABLE Technician (
    TechnicianID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    CompletedRequests INT NOT NULL,
    Specialization NVARCHAR(25) NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
GO
-- Manager
CREATE TABLE Manager (
    ManagerID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    Area NVARCHAR(25) NOT NULL,
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
-- Service
CREATE TABLE [Service] (
    ServiceID INT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(100) NOT NULL,
    Category NVARCHAR(25) NOT NULL,
    Price FLOAT NOT NULL,
    [Level] NVARCHAR(25) NOT NULL,
    [Description] NVARCHAR(100),
);
GO
-- ServicePackage
CREATE TABLE ServicePackage (
    PackageID INT IDENTITY(1,1) PRIMARY KEY,
    AvailableFrom DATE,
    AvailableUntil DATE,
    [Status] NVARCHAR(25) NOT NULL
);
GO
-- ServicePackageServices (Bridge)
CREATE TABLE ServicePackageServices (
    PackageID INT NOT NULL,
    ServiceID INT NOT NULL,
    FOREIGN KEY (PackageID) REFERENCES ServicePackage(PackageID),
    FOREIGN KEY (ServiceID) REFERENCES [Service](ServiceID)
);
GO
-- SLA
CREATE TABLE SLA (
    SlaID INT IDENTITY(1,1) PRIMARY KEY,
    [Description] NVARCHAR(100),
    ServicePackageDetails NVARCHAR(MAX) NOT NULL,
    ServicePriorityDetails NVARCHAR(MAX) NOT NULL,
    TargetPerformanceDetails NVARCHAR(MAX) NOT NULL,
    PartyObligationDetails NVARCHAR(MAX) NOT NULL,
    BreachPenaltyDetails NVARCHAR(MAX) NOT NULL,
    MetricProtocolDetails NVARCHAR(MAX) NOT NULL,
);
GO
-- Client
CREATE TABLE Client (
    ClientID INT IDENTITY(1,1) PRIMARY KEY,
    AddressID INT NOT NULL,
    Category NVARCHAR(25) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    RegistrationDate DATE NOT NULL,
    Email NVARCHAR(50) NOT NULL,
    Phone NVARCHAR(25) NOT NULL,
    [Status] NVARCHAR(25) NOT NULL,
    Notes NVARCHAR(100),
    FOREIGN KEY (AddressID) REFERENCES [Address](AddressID)
);
GO
-- IndividualClient
CREATE TABLE IndividualClient (
    IndividualID INT IDENTITY(1,1) PRIMARY KEY,
    ClientID INT NOT NULL,
    DateOfBirth DATE NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID)
);
GO
-- BusinessClient
CREATE TABLE BusinessClient (
    BusinessID INT IDENTITY(1,1) PRIMARY KEY,
    ClientID INT NOT NULL,
    BusinessName NVARCHAR(100) NOT NULL,
    ContactTitle NVARCHAR(50) NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID)
);
GO
-- ServiceContract
CREATE TABLE ServiceContract (
    ContractID INT IDENTITY(1,1) PRIMARY KEY,
    PackageID INT NOT NULL,
    SlaID INT NOT NULL,
    [Status] NVARCHAR(25) NOT NULL,
    Details NVARCHAR(MAX) NOT NULL,
    [Category] NVARCHAR(25) NOT NULL,
    PurchaseDate DATE,
    EffectDate DATE,
    ExpiryDate DATE,
    FOREIGN KEY (PackageID) REFERENCES ServicePackage(PackageID),
    FOREIGN KEY (SlaID) REFERENCES SLA(SlaID)
);
GO
-- ClientContracts (Bridge)
CREATE TABLE ClientContracts (
    ClientID INT NOT NULL,
    ContractID INT NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID),
    FOREIGN KEY (ContractID) REFERENCES ServiceContract(ContractID)
);
GO
-- CallReport
CREATE TABLE CallReport (
    ReportID INT IDENTITY(1,1) PRIMARY KEY,
    ClientID INT NOT NULL,
    Details NVARCHAR(MAX) NOT NULL,
    [Status] NVARCHAR(25) NOT NULL,
    ReportDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    FOREIGN KEY (ClientID) REFERENCES Client(ClientID)
);
GO
-- WorkRequest
CREATE TABLE WorkRequest (
    RequestID INT IDENTITY(1,1) PRIMARY KEY,
    RequestDate DATE NOT NULL,
    ScheduledDate DATE NOT NULL,
    CompletedDate DATE,
    ExpectedDuration INT NOT NULL,
    FinalDuration INT,
    MaintenanceType NVARCHAR(50) NOT NULL,
    [Priority] NVARCHAR(25) NOT NULL,
    [Status] NVARCHAR(25) NOT NULL
);
GO
-- WorkRequestAssignedTechnicians
CREATE TABLE WorkRequestAssignedTechnicians (
    RequestID INT NOT NULL,
    TechnicianID INT NOT NULL,
    FOREIGN KEY (RequestID) REFERENCES WorkRequest(RequestID),
    FOREIGN KEY (TechnicianID) REFERENCES Technician(TechnicianID)
);
GO
-- WorkRequestAssignedReports
CREATE TABLE WorkRequestAssignedReports (
    RequestID INT NOT NULL,
    ReportID INT NOT NULL,
    FOREIGN KEY (RequestID) REFERENCES WorkRequest(RequestID),
    FOREIGN KEY (ReportID) REFERENCES CallReport(ReportID)
);
GO

-- Account
CREATE NONCLUSTERED INDEX IX_Account_Username ON Account(Username);
CREATE NONCLUSTERED INDEX IX_Account_Category ON Account(Category);
GO
-- Employee
CREATE NONCLUSTERED INDEX IX_Employee_AddressID ON Employee(AddressID);
CREATE NONCLUSTERED INDEX IX_Employee_Email ON Employee(Email);
CREATE NONCLUSTERED INDEX IX_Employee_Category ON Employee(Category);
CREATE NONCLUSTERED INDEX IX_Employee_Status ON Employee([Status]);
GO
-- Technician
CREATE NONCLUSTERED INDEX IX_Technician_EmployeeID ON Technician(EmployeeID);
CREATE NONCLUSTERED INDEX IX_Technician_Specialization ON Technician(Specialization);
GO
-- Manager
CREATE NONCLUSTERED INDEX IX_Manager_EmployeeID_Manager ON Manager(EmployeeID);
GO
-- Service
CREATE NONCLUSTERED INDEX IX_Service_Name ON [Service]([Name]);
CREATE NONCLUSTERED INDEX IX_Service_Cateogry ON [Service](Category);
GO
-- ServicePackageServices
CREATE NONCLUSTERED INDEX IX_SPS_PackageID ON ServicePackageServices(PackageID);
CREATE NONCLUSTERED INDEX IX_SPS_ServiceID ON ServicePackageServices(ServiceID);
GO
-- Client
CREATE NONCLUSTERED INDEX IX_Client_Email_Client ON Client(Email);
CREATE NONCLUSTERED INDEX IX_Client_AddressID_Client ON Client(AddressID);
CREATE NONCLUSTERED INDEX IX_Client_Category_Client ON Client(Category);
CREATE NONCLUSTERED INDEX IX_Client_Status_Client ON Client([Status]);
GO
-- IndividualClient
CREATE NONCLUSTERED INDEX IX_IndividualClient_ClientID ON IndividualClient(ClientID);
GO
-- BusinessClient
CREATE NONCLUSTERED INDEX IX_BusinessClient_ClientID ON BusinessClient(ClientID);
GO
-- ServiceContract
CREATE NONCLUSTERED INDEX IX_ServiceContract_PackageID ON ServiceContract(PackageID);
CREATE NONCLUSTERED INDEX IX_ServiceContract_SlaID ON ServiceContract(SlaID);
CREATE NONCLUSTERED INDEX IX_ServiceContract_Status ON ServiceContract([Status]);
GO
-- ClientContracts
CREATE NONCLUSTERED INDEX IX_ClientContracts_ClientID ON ClientContracts(ClientID);
CREATE NONCLUSTERED INDEX IX_ClientContracts_ContractID ON ClientContracts(ContractID);
GO
-- CallReport
CREATE NONCLUSTERED INDEX IX_CallReport_ClientID ON CallReport(ClientID);
CREATE NONCLUSTERED INDEX IX_CallReport_Status ON CallReport([Status]);
GO
-- WorkRequestAssignedTechnicians
CREATE NONCLUSTERED INDEX IX_WorkRequestAssignedTechnicians_RequestID ON WorkRequestAssignedTechnicians(RequestID);
CREATE NONCLUSTERED INDEX IX_WorkRequestAssignedTechnicians_TechnicianID ON WorkRequestAssignedTechnicians(TechnicianID);
GO
-- WorkRequestAssignedReports
CREATE NONCLUSTERED INDEX IX_WorkRequestAssignedReports_RequestID ON WorkRequestAssignedReports(RequestID);
CREATE NONCLUSTERED INDEX IX_WorkRequestAssignedReports_ReportID ON WorkRequestAssignedReports(ReportID);
GO

-- Stored Procedures
-- Account
-- Create
CREATE PROCEDURE USP_CreateAccount
    @Username NVARCHAR(100),
    @Password NVARCHAR(100),
    @Category NVARCHAR(25)
AS
BEGIN
    INSERT INTO Account (Username, [Password], Category)
    VALUES (@Username, @Password, @Category);
END;
GO
-- Read
CREATE PROCEDURE USP_GetAccountByUsername
    @Username NVARCHAR(100) 
AS
BEGIN
    SELECT * FROM Account WHERE Username = @Username;
END;
GO
CREATE PROCEDURE USP_GetAccounts
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM Account'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateAccount
    @AccountID INT,
    @Username NVARCHAR(100),
    @Password NVARCHAR(100),
    @Category NVARCHAR(25)
AS
BEGIN
    UPDATE Account
    SET Username = @Username,
        [Password] = @Password,
        Category = @Category
    WHERE AccountID = @AccountID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteAccount
    @AccountID INT
AS
BEGIN
    DELETE FROM Account WHERE AccountID = @AccountID;
END;
GO

-- Address
-- Create
CREATE PROCEDURE USP_CreateAddress
    @AddressLine1 NVARCHAR(100),
    @AddressLine2 NVARCHAR(100) = NULL,
    @Country NVARCHAR(50),
    @PostalCode NVARCHAR(25),
    @City NVARCHAR(50),
    @Province NVARCHAR(50),
    @NewAddressID INT OUTPUT
AS
BEGIN
    INSERT INTO [Address] (AddressLine1, AddressLine2, Country, PostalCode, City, Province)
    VALUES (@AddressLine1, @AddressLine2, @Country, @PostalCode, @City, @Province);

    SET @NewAddressID = SCOPE_IDENTITY();
END;
GO
-- Read
CREATE PROCEDURE USP_GetByAddressID
    @AddressID INT
AS
BEGIN
    SELECT * FROM [Address] WHERE AddressID = @AddressID
END;
GO
CREATE PROCEDURE USP_GetAddresses
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM Address'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateAddress 
    @AddressID INT,
    @AddressLine1 NVARCHAR(100),
    @AddressLine2 NVARCHAR(100),
    @Country NVARCHAR(50),
    @PostalCode NVARCHAR(25),
    @City NVARCHAR(50),
    @Province NVARCHAR(50)
AS
BEGIN
    UPDATE [Address]
    SET AddressLine1 = @AddressLine1,
        AddressLine2 = @AddressLine2,
        Country = @Country,
        PostalCode = @PostalCode,
        City = @City,
        Province = @Province
    WHERE AddressID = @AddressID
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteAddress 
    @AddressID INT
AS
BEGIN
    DELETE FROM [Address] WHERE AddressID = @AddressID
END;
GO

-- Employee
-- Create
CREATE PROCEDURE USP_CreateEmployee
    @AddressID INT, 
    @FirstName NVARCHAR(100), 
    @LastName NVARCHAR(100), 
    @DateOfBirth DATE, 
    @Email NVARCHAR(50), 
    @Phone NVARCHAR(25),
    @Category NVARCHAR(25),
    @Status NVARCHAR(25),
    @Schedule NVARCHAR(25),
    @Salary FLOAT, 
    @Notes NVARCHAR(100)
AS
BEGIN
    INSERT INTO Employee (AddressID, FirstName, LastName, DateOfBirth, Email, Phone, Category, [Status], Schedule, Salary, Notes) 
    VALUES (@AddressID, @FirstName, @LastName, @DateOfBirth, @Email, @Phone, @Category, @Status, @Schedule, @Salary, @Notes);
END;
GO
-- Read
CREATE PROCEDURE USP_GetEmployeeByID
    @EmployeeID INT
AS
BEGIN
    SELECT * FROM Employee WHERE EmployeeID = @EmployeeID;
END;
GO
CREATE PROCEDURE USP_GetEmployees
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM Employee'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateEmployee
    @EmployeeID INT,
    @AddressID INT, 
    @FirstName NVARCHAR(100), 
    @LastName NVARCHAR(100), 
    @DateOfBirth DATE, 
    @Email NVARCHAR(50), 
    @Phone NVARCHAR(25),
    @Category NVARCHAR(25),
    @Status NVARCHAR(25),
    @Schedule NVARCHAR(25),
    @Salary FLOAT, 
    @Notes NVARCHAR(100)
AS
BEGIN
    UPDATE Employee 
    SET AddressID = @AddressID, 
        FirstName = @FirstName, 
        LastName = @LastName, 
        DateOfBirth = @DateOfBirth, 
        Email = @Email, 
        Phone = @Phone,
        Category = @Category,
        [Status] = @Status,
        Schedule = @Schedule,
        Salary = @Salary, 
        Notes = @Notes
    WHERE EmployeeID = @EmployeeID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteEmployee
    @EmployeeID INT 
AS
BEGIN
    DELETE FROM Technician WHERE EmployeeID = @EmployeeID;
    DELETE FROM Manager WHERE EmployeeID = @EmployeeID;
    DELETE FROM Employee WHERE EmployeeID = @EmployeeID;
END;
GO

-- Technician
-- Create
CREATE PROCEDURE USP_CreateTechnician
    @AddressID INT,
    @FirstName NVARCHAR(100),
    @LastName NVARCHAR(100),
    @DateOfBirth DATE,
    @Email NVARCHAR(50),
    @Phone NVARCHAR(25),
    @Category NVARCHAR(25),
    @Status NVARCHAR(25),
    @Schedule NVARCHAR(25),
    @Salary FLOAT,
    @Notes NVARCHAR(100) = NULL,
    @CompletedRequests INT,
    @Specialization NVARCHAR(25)
AS
BEGIN
    INSERT INTO Employee(AddressID, FirstName, LastName, DateOfBirth, Email, Phone, Category, [Status], Schedule, Salary, Notes)
    VALUES (@AddressID, @FirstName, @LastName, @DateOfBirth, @Email, @Phone, @Category, @Status, @Schedule, @Salary, @Notes);

    DECLARE @NewEmployeeID INT;
    SET @NewEmployeeID = SCOPE_IDENTITY();

    INSERT INTO Technician(EmployeeID, CompletedRequests, Specialization)
    VALUES (@NewEmployeeID, @CompletedRequests, @Specialization);
END;
GO
-- Read
CREATE PROCEDURE USP_GetTechnicianByID
    @TechnicianID INT
AS
BEGIN
    SELECT * FROM Technician WHERE TechnicianID = @TechnicianID;
END;
GO
CREATE PROCEDURE USP_GetTechnicians
AS
BEGIN
    SELECT t.TechnicianID, t.CompletedRequests, t.Specialization, e.*
    FROM Technician t
    JOIN Employee e ON t.EmployeeID = e.EmployeeID
END
GO
-- Update
CREATE PROCEDURE USP_UpdateTechnician
    @TechnicianID INT,
    @EmployeeID INT,
    @CompletedRequests INT,
    @Specialization NVARCHAR(25)
AS
BEGIN
    UPDATE Technician
    SET EmployeeID = @EmployeeID,
        CompletedRequests = @CompletedRequests,
        Specialization = @Specialization
    WHERE TechnicianID = @TechnicianID;
END;
GO

-- Manager
-- Create
CREATE PROCEDURE USP_CreateManager
    @EmployeeID INT,
    @Area NVARCHAR(25)
AS
BEGIN
    INSERT INTO Manager (EmployeeID, Area) 
    VALUES (@EmployeeID, @Area);
END;
GO
-- Read
CREATE PROCEDURE USP_GetManagerByID
    @ManagerID INT
AS
BEGIN
    SELECT * FROM Manager WHERE ManagerID = @ManagerID;
END;
GO
CREATE PROCEDURE USP_GetManagers
AS
BEGIN
    SELECT e.*, m.ManagerID, m.Area
    FROM Manager m
    JOIN Employee e ON m.EmployeeID = e.EmployeeID
END
GO
-- Update
CREATE PROCEDURE USP_UpdateManager
    @ManagerID INT,
    @EmployeeID INT,
    @Area NVARCHAR(25)
AS
BEGIN
    UPDATE Manager
    SET EmployeeID = @EmployeeID,
        Area = @Area
    WHERE ManagerID = @ManagerID;
END;
GO

-- Service
-- Create
CREATE PROCEDURE USP_CreateService
    @Name NVARCHAR(100), 
    @Category NVARCHAR(25), 
    @Price FLOAT, 
    @Level NVARCHAR(25), 
    @Description NVARCHAR(100)
AS
BEGIN
    INSERT INTO [Service] ([Name], Category, Price, [Level], [Description])
    VALUES (@Name, @Category, @Price, @Level, @Description);
END;
GO
-- Read
CREATE PROCEDURE USP_GetServiceByID
    @ServiceID INT
AS
BEGIN
    SELECT * FROM [Service] WHERE ServiceID = @ServiceID;
END;
GO
CREATE PROCEDURE USP_GetServices
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM [Service]'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateService
    @ServiceID INT,
    @Name NVARCHAR(100), 
    @Category NVARCHAR(25), 
    @Price FLOAT, 
    @Level NVARCHAR(25), 
    @Description NVARCHAR(100)
AS
BEGIN
    UPDATE [Service]
    SET [Name] = @Name, 
        Category = @Category, 
        Price = @Price, 
        [Level] = @Level, 
        [Description] = @Description
    WHERE ServiceID = @ServiceID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteService
    @ServiceID INT
AS
BEGIN
    DELETE FROM [Service] WHERE ServiceID = @ServiceID;
END;
GO

-- ServicePackage
-- Create
CREATE PROCEDURE USP_CreateServicePackage
    @AvailableFrom DATE, 
    @AvailableUntil DATE, 
    @Status NVARCHAR(25)
AS
BEGIN
    INSERT INTO ServicePackage (AvailableFrom, AvailableUntil, [Status]) 
    VALUES (@AvailableFrom, @AvailableUntil, @Status);
END;
GO
-- Read
CREATE PROCEDURE USP_GetServicePackageByID
    @PackageID INT
AS
BEGIN
    SELECT * FROM ServicePackage WHERE PackageID = @PackageID;
END;
GO
CREATE PROCEDURE USP_GetServicePackages
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM ServicePackage'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateServicePackage 
    @PackageID INT, 
    @AvailableFrom DATE, 
    @AvailableUntil DATE, 
    @Status NVARCHAR(25)
AS
BEGIN
    UPDATE ServicePackage 
    SET AvailableFrom = @AvailableFrom, 
        AvailableUntil = @AvailableUntil, 
        [Status] = @Status
    WHERE PackageID = @PackageID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteServicePackage 
    @PackageID INT 
AS
BEGIN
    DELETE FROM ServicePackage WHERE PackageID = @PackageID;
END;
GO

-- ServicePackageServices
-- Create
CREATE PROCEDURE USP_CreateSPS
    @PackageID INT, 
    @ServiceID INT
AS
BEGIN
    INSERT INTO ServicePackageServices (PackageID, ServiceID) 
    VALUES (@PackageID, @ServiceID);
END;
GO
-- Read
CREATE PROCEDURE USP_GetSPS
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM ServicePackageServices'
    EXEC sp_executesql @Query
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteSPS
    @PackageID INT, 
    @ServiceID INT
AS
BEGIN
    DELETE FROM ServicePackageServices WHERE PackageID = @PackageID AND ServiceID = @ServiceID;
END;
GO

-- SLA
-- Create
CREATE PROCEDURE USP_CreateSLA
    @Description NVARCHAR(100),
    @ServicePackageDetails NVARCHAR(MAX),
    @ServicePriorityDetails NVARCHAR(MAX),
    @TargetPerformanceDetails NVARCHAR(MAX),
    @PartyObligationDetails NVARCHAR(MAX),
    @BreachPenaltyDetails NVARCHAR(MAX),
    @MetricProtocolDetails NVARCHAR(MAX)
AS
BEGIN
    INSERT INTO SLA ([Description], ServicePackageDetails, ServicePriorityDetails, TargetPerformanceDetails, PartyObligationDetails, BreachPenaltyDetails, MetricProtocolDetails)
    VALUES (@Description, @ServicePackageDetails, @ServicePriorityDetails, @TargetPerformanceDetails, @PartyObligationDetails, @BreachPenaltyDetails, @MetricProtocolDetails);
END;
GO
-- Read
CREATE PROCEDURE USP_GetSLAByID
    @SlaID INT
AS
BEGIN
    SELECT * FROM SLA WHERE SlaID = @SlaID;
END;
GO
CREATE PROCEDURE USP_GetSLAs
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM SLA'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateSLA
    @SlaID INT,
    @Description NVARCHAR(100),
    @ServicePackageDetails NVARCHAR(MAX),
    @ServicePriorityDetails NVARCHAR(MAX),
    @TargetPerformanceDetails NVARCHAR(MAX),
    @PartyObligationDetails NVARCHAR(MAX),
    @BreachPenaltyDetails NVARCHAR(MAX),
    @MetricProtocolDetails NVARCHAR(MAX)
AS
BEGIN
    UPDATE SLA
    SET [Description] = @Description,
        ServicePackageDetails = @ServicePackageDetails,
        ServicePriorityDetails = @ServicePriorityDetails,
        TargetPerformanceDetails = @TargetPerformanceDetails,
        PartyObligationDetails = @PartyObligationDetails,
        BreachPenaltyDetails = @BreachPenaltyDetails,
        MetricProtocolDetails = @MetricProtocolDetails
    WHERE SlaID = @SlaID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteSLA
    @SlaID INT
AS
BEGIN
    DELETE FROM SLA WHERE SlaID = @SlaID;
END;
GO

-- Client
-- Create
CREATE PROCEDURE USP_CreateClient
    @AddressID INT,
    @Category NVARCHAR(25),
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @RegistrationDate DATE,
    @Email NVARCHAR(50),
    @Phone NVARCHAR(25),
    @Status NVARCHAR(25),
    @Notes NVARCHAR(100),
    -- IndividualClient Params
    @DateOfBirth DATE = NULL,
    -- BusinessClient Params
    @BusinessName NVARCHAR(100) = NULL,
    @ContactTitle NVARCHAR(50) = NULL
AS
BEGIN
    DECLARE @InsertedClientID INT

    INSERT INTO Client (AddressID, Category, FirstName, LastName, RegistrationDate, Email, Phone, [Status], Notes)
    VALUES (@AddressID, @Category, @FirstName, @LastName, @RegistrationDate, @Email, @Phone, @Status, @Notes)

    SET @InsertedClientID = SCOPE_IDENTITY()

    IF (@Category = 'Individual')
    BEGIN
        INSERT INTO IndividualClient (ClientID, DateOfBirth)
        VALUES (@InsertedClientID, @DateOfBirth)
    END

    IF (@Category = 'Business')
    BEGIN
        INSERT INTO BusinessClient (ClientID, BusinessName, ContactTitle)
        VALUES (@InsertedClientID, @BusinessName, @ContactTitle)
    END
END
GO

-- Read
CREATE PROCEDURE USP_GetClients AS
SELECT 
    c.ClientID, c.AddressID, c.Category, c.FirstName, c.LastName, 
    c.RegistrationDate, c.Email, c.Phone, c.[Status], c.Notes,
    i.IndividualID, i.DateOfBirth,
    b.BusinessID, b.BusinessName, b.ContactTitle
FROM Client c
LEFT JOIN IndividualClient i ON c.ClientID = i.ClientID
LEFT JOIN BusinessClient b ON c.ClientID = b.ClientID;
GO
CREATE PROCEDURE USP_GetClientIDs
    @ClientID INT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM Clients WHERE ClientID = ' + @ClientID
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateClient
    @ClientID INT,
    @AddressID INT,
    @Category NVARCHAR(25),
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @RegistrationDate DATE,
    @Email NVARCHAR(50),
    @Phone NVARCHAR(25),
    @Status NVARCHAR(25),
    @Notes NVARCHAR(100)
AS
BEGIN
    UPDATE Client
    SET AddressID = @AddressID,
        Category = @Category,
        FirstName = @FirstName,
        LastName = @LastName,
        RegistrationDate = @RegistrationDate,
        Email = @Email,
        Phone = @Phone,
        [Status] = @Status,
        Notes = @Notes
    WHERE ClientID = @ClientID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteClient
    @ClientID INT
AS
BEGIN
    DELETE FROM IndividualClient WHERE ClientID = @ClientID;
    DELETE FROM BusinessClient WHERE ClientID = @ClientID;
    DELETE FROM Client WHERE ClientID = @ClientID;
END;
GO

-- IndividualClient
-- Create
CREATE PROCEDURE USP_CreateIndividualClient
    @ClientID INT,
    @DateOfBirth DATE
AS
BEGIN
    INSERT INTO IndividualClient (ClientID, DateOfBirth)
    VALUES (@ClientID, @DateOfBirth);
END;
GO
-- Read
CREATE PROCEDURE USP_GetIndividualClientByID
    @IndividualID INT
AS
BEGIN
    SELECT * FROM IndividualClient WHERE IndividualID = @IndividualID;
END;
GO
CREATE PROCEDURE USP_GetIndividualClients
AS
BEGIN
    SELECT c.*, i.IndividualID, i.DateOfBirth
    FROM IndividualClient i
    JOIN Client c ON i.ClientID = c.ClientID
END
GO
-- Update
CREATE PROCEDURE USP_UpdateIndividualClient
    @IndividualID INT,
    @ClientID INT,
    @DateOfBirth DATE
AS
BEGIN
    UPDATE IndividualClient
    SET ClientID = @ClientID,
        DateOfBirth = @DateOfBirth
    WHERE IndividualID = @IndividualID;
END;
GO

-- BusinessClient
-- Create
CREATE PROCEDURE USP_CreateBusinessClient
    @ClientID INT,
    @BusinessName NVARCHAR(100),
    @ContactTitle NVARCHAR(50)
AS
BEGIN
    INSERT INTO BusinessClient (ClientID, BusinessName, ContactTitle)
    VALUES (@ClientID, @BusinessName, @ContactTitle);
END;
GO
-- Read
CREATE PROCEDURE USP_GetBusinessClientByID
    @BusinessID INT
AS
BEGIN
    SELECT * FROM BusinessClient WHERE BusinessID = @BusinessID;
END;
GO
CREATE PROCEDURE USP_GetBusinessClients
AS
BEGIN
    SELECT c.*, b.BusinessID, b.BusinessName, b.ContactTitle
    FROM BusinessClient b
    JOIN Client c ON b.ClientID = c.ClientID
END
GO
-- Update
CREATE PROCEDURE USP_UpdateBusinessClient
    @BusinessID INT,
    @ClientID INT,
    @BusinessName NVARCHAR(100),
    @ContactTitle NVARCHAR(100)
AS
BEGIN
    UPDATE BusinessClient
    SET ClientID = @ClientID,
        BusinessName = @BusinessName,
        ContactTitle = @ContactTitle
    WHERE BusinessID = @BusinessID;
END;
GO

-- ServiceContract
-- Create
CREATE PROCEDURE USP_CreateServiceContract
    @PackageID INT,
    @SlaID INT,
    @Status NVARCHAR(25),
    @Details NVARCHAR(MAX),
    @Category NVARCHAR(25),
    @PurchaseDate DATE,
    @EffectDate DATE,
    @ExpiryDate DATE
AS
BEGIN
    INSERT INTO ServiceContract (PackageID, SlaID, [Status], Details, Category, PurchaseDate, EffectDate, ExpiryDate)
    VALUES (@PackageID, @SlaID, @Status, @Details, @Category, @PurchaseDate, @EffectDate, @ExpiryDate);
END;
GO
-- Read
CREATE PROCEDURE USP_GetServiceContractByID
    @ContractID INT
AS
BEGIN
    SELECT * FROM ServiceContract WHERE ContractID = @ContractID;
END;
GO
CREATE PROCEDURE USP_GetServiceContracts
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM ServiceContract'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateServiceContract
    @ContractID INT,
    @PackageID INT,
    @SlaID INT,
    @Status NVARCHAR(25),
    @Details NVARCHAR(MAX),
    @Category NVARCHAR(25),
    @PurchaseDate DATE,
    @EffectDate DATE,
    @ExpiryDate DATE
AS
BEGIN
    UPDATE ServiceContract
    SET PackageID = @PackageID,
        SlaID = @SlaID,
        [Status] = @Status,
        Details = @Details,
        Category = @Category,
        PurchaseDate = @PurchaseDate,
        EffectDate = @EffectDate,
        ExpiryDate = @ExpiryDate
    WHERE ContractID = @ContractID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteServiceContract
    @ContractID INT
AS
BEGIN
    DELETE FROM ServiceContract WHERE ContractID = @ContractID;
END;
GO

-- ClientContract
-- Create
CREATE PROCEDURE USP_CreateClientContract
    @ClientID INT,
    @ContractID INT
AS
BEGIN
    INSERT INTO ClientContracts (ClientID, ContractID)
    VALUES (@ClientID, @ContractID);
END;
GO
-- Read
CREATE PROCEDURE USP_GetClientContracts
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM ClientContracts'
    EXEC sp_executesql @Query
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteClientContract
    @ClientID INT,
    @ContractID INT
AS
BEGIN
    DELETE FROM ClientContracts WHERE ClientID = @ClientID AND ContractID = @ContractID;
END;
GO

-- CallReport
-- Create
CREATE PROCEDURE USP_CreateCallReport
    @ClientID INT,
    @Details NVARCHAR(MAX),
    @Status NVARCHAR(25),
    @ReportDate DATE,
    @StartTime TIME,
    @EndTime TIME
AS
BEGIN
    INSERT INTO CallReport (ClientID, Details, [Status], ReportDate, StartTime, EndTime)
    VALUES (@ClientID, @Details, @Status, @ReportDate, @StartTime, @EndTime);
END;
GO
-- Read
CREATE PROCEDURE USP_GetCallReportByID
    @ReportID INT
AS
BEGIN
    SELECT * FROM CallReport WHERE ReportID = @ReportID;
END;
GO
CREATE PROCEDURE USP_GetCallReports
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM CallReport'
    EXEC sp_executesql @Query
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateCallReport
    @ReportID INT,
    @ClientID INT,
    @Details NVARCHAR(MAX),
    @Status NVARCHAR(25),
    @ReportDate DATE,
    @StartTime TIME,
    @EndTime TIME
AS
BEGIN
    UPDATE CallReport
    SET ClientID = @ClientID,
        Details = @Details,
        [Status] = @Status,
        ReportDate = @ReportDate,
        StartTime = @StartTime,
        EndTime = @EndTime
    WHERE ReportID = @ReportID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteCallReport
    @ReportID INT
AS
BEGIN
    DELETE FROM CallReport WHERE ReportID = @ReportID;
END;
GO

-- WorkRequest
-- Create
CREATE TYPE TechnicianIDTableType AS TABLE
(
    TechnicianID INT
);
GO
CREATE TYPE ReportIDTableType AS TABLE
(
    ReportID INT
);
GO
CREATE PROCEDURE USP_CreateWorkRequest
    @RequestDate DATE,
    @ScheduledDate DATE,
    @CompletedDate DATE = NULL,
    @ExpectedDuration INT,
    @FinalDuration INT = NULL,
    @MaintenanceType NVARCHAR(50),
    @Priority NVARCHAR(25),
    @Status NVARCHAR(25),
    @TechnicianIDs TechnicianIDTableType READONLY,
    @ReportIDs ReportIDTableType READONLY
AS
BEGIN
    DECLARE @InsertedRequestID INT;

    -- Insert into WorkRequest table
    INSERT INTO WorkRequest (RequestDate, ScheduledDate, CompletedDate, ExpectedDuration, FinalDuration, MaintenanceType, [Priority], [Status])
    VALUES (@RequestDate, @ScheduledDate, @CompletedDate, @ExpectedDuration, @FinalDuration, @MaintenanceType, @Priority, @Status);

    SET @InsertedRequestID = SCOPE_IDENTITY(); -- Fetch the inserted request ID

    -- Insert technicians associated with this request
    INSERT INTO WorkRequestAssignedTechnicians (RequestID, TechnicianID)
    SELECT @InsertedRequestID, TechnicianID FROM @TechnicianIDs;

    -- Insert reports associated with this request
    INSERT INTO WorkRequestAssignedReports (RequestID, ReportID)
    SELECT @InsertedRequestID, ReportID FROM @ReportIDs;

END
GO

-- Read
CREATE PROCEDURE USP_GetWorkRequestByID
    @RequestID INT
AS
BEGIN
    SELECT * FROM WorkRequest WHERE RequestID = @RequestID;
END;
GO
-- Update
CREATE PROCEDURE USP_UpdateWorkRequest
    @RequestID INT,
    @RequestDate DATE,
    @ScheduledDate DATE,
    @CompletedDate DATE,
    @ExpectedDuration INT,
    @FinalDuration INT,
    @MaintenanceType NVARCHAR(50),
    @Priority NVARCHAR(25),
    @Status NVARCHAR(25)
AS
BEGIN
    UPDATE WorkRequest
    SET RequestDate = @RequestDate,
        ScheduledDate = @ScheduledDate,
        CompletedDate = @CompletedDate,
        ExpectedDuration = @ExpectedDuration,
        FinalDuration = @FinalDuration,
        MaintenanceType = @MaintenanceType,
        [Priority] = @Priority,
        [Status] = @Status
    WHERE RequestID = @RequestID;
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteWorkRequest
    @RequestID INT
AS
BEGIN
    DELETE FROM WorkRequest WHERE RequestID = @RequestID;
END;
GO
-- Search
CREATE PROCEDURE USP_SearchWorkRequest
    @Field NVARCHAR(50),
    @Value NVARCHAR(100)
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequest WHERE ' + @Field + ' LIKE ''%' + @Value + '%'''
    EXEC sp_executesql @Query
END;
GO
-- Get
CREATE PROCEDURE USP_GetWorkRequests
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequest'
    EXEC sp_executesql @Query
END;
GO

-- WorkRequestAssignedTechnicians
-- Create
CREATE PROCEDURE USP_CreateWRAT
    @RequestID INT,
    @TechnicianID INT
AS
BEGIN
    INSERT INTO WorkRequestAssignedTechnicians (RequestID, TechnicianID)
    VALUES (@RequestID, @TechnicianID);
END;
GO
-- Read
CREATE PROCEDURE USP_GetWRATByTechnicianID
    @TechnicianID INT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedTechnicians WHERE TechnicianID = ' + @TechnicianID
    EXEC sp_executesql @Query
END;
GO
CREATE PROCEDURE USP_GetWRATByRequestID
    @RequestID INT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedTechnicians WHERE RequestID = ' + @RequestID
    EXEC sp_executesql @Query
END;
GO
CREATE PROCEDURE USP_GetWRAT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedTechnicians'
    EXEC sp_executesql @Query
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteWRAT
    @RequestID INT,
    @TechnicianID INT
AS
BEGIN
    DELETE FROM WorkRequestAssignedTechnicians WHERE RequestID = @RequestID AND TechnicianID = @TechnicianID
END;
GO

-- WorkRequestAssignedReports
-- Create
CREATE PROCEDURE USP_CreateWRAR
    @RequestID INT,
    @ReportID INT
AS
BEGIN
    INSERT INTO WorkRequestAssignedReports (RequestID, ReportID)
    VALUES (@RequestID, @ReportID);
END;
GO
-- Read
CREATE PROCEDURE USP_GetWRARByReportID
    @ReportID INT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedReports WHERE ReportID = ' + @ReportID
    EXEC sp_executesql @Query
END;
GO
CREATE PROCEDURE USP_GetWRARByRequestID
    @RequestID INT
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedReports WHERE RequestID = ' + @RequestID
    EXEC sp_executesql @Query
END;
GO
CREATE PROCEDURE USP_GetWRAR
AS
BEGIN
    DECLARE @Query NVARCHAR(MAX)
    SET @Query = 'SELECT * FROM WorkRequestAssignedReports'
    EXEC sp_executesql @Query
END;
GO
-- Delete
CREATE PROCEDURE USP_DeleteWRAR
    @RequestID INT,
    @ReportID INT
AS
BEGIN
    DELETE FROM WorkRequestAssignedReports WHERE RequestID = @RequestID AND ReportID = @ReportID
END;

