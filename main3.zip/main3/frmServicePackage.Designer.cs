﻿namespace Main
{
    partial class frmServicePackage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServicePackage));
            this.txtPackageID = new System.Windows.Forms.TextBox();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.dtpAvailableUntil = new System.Windows.Forms.DateTimePicker();
            this.lblAvailableUntil = new System.Windows.Forms.Label();
            this.dtpAvailableFrom = new System.Windows.Forms.DateTimePicker();
            this.lblAvailableFrom = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblPackageID = new System.Windows.Forms.Label();
            this.lblServicePackageTitle = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.pnlControls.SuspendLayout();
            this.pnlTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtPackageID
            // 
            this.txtPackageID.Enabled = false;
            this.txtPackageID.Location = new System.Drawing.Point(9, 19);
            this.txtPackageID.Name = "txtPackageID";
            this.txtPackageID.Size = new System.Drawing.Size(100, 22);
            this.txtPackageID.TabIndex = 130;
            this.txtPackageID.Tag = "PackageID";
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.checkedListBox1);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.dtpAvailableUntil);
            this.pnlControls.Controls.Add(this.lblAvailableUntil);
            this.pnlControls.Controls.Add(this.dtpAvailableFrom);
            this.pnlControls.Controls.Add(this.lblAvailableFrom);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.txtPackageID);
            this.pnlControls.Controls.Add(this.lblPackageID);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(225, 195);
            this.pnlControls.TabIndex = 21;
            this.pnlControls.Tag = "Controls";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Available",
            "Unavailable"});
            this.cmbStatus.Location = new System.Drawing.Point(9, 142);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 161;
            this.cmbStatus.Tag = "Status";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(7, 128);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 160;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // dtpAvailableUntil
            // 
            this.dtpAvailableUntil.Enabled = false;
            this.dtpAvailableUntil.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAvailableUntil.Location = new System.Drawing.Point(9, 102);
            this.dtpAvailableUntil.Name = "dtpAvailableUntil";
            this.dtpAvailableUntil.Size = new System.Drawing.Size(100, 22);
            this.dtpAvailableUntil.TabIndex = 154;
            this.dtpAvailableUntil.Tag = "AvailableUntil";
            // 
            // lblAvailableUntil
            // 
            this.lblAvailableUntil.AutoSize = true;
            this.lblAvailableUntil.Enabled = false;
            this.lblAvailableUntil.Location = new System.Drawing.Point(6, 88);
            this.lblAvailableUntil.Name = "lblAvailableUntil";
            this.lblAvailableUntil.Size = new System.Drawing.Size(84, 13);
            this.lblAvailableUntil.TabIndex = 153;
            this.lblAvailableUntil.Tag = "";
            this.lblAvailableUntil.Text = "Available Until:";
            // 
            // dtpAvailableFrom
            // 
            this.dtpAvailableFrom.Enabled = false;
            this.dtpAvailableFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAvailableFrom.Location = new System.Drawing.Point(9, 59);
            this.dtpAvailableFrom.Name = "dtpAvailableFrom";
            this.dtpAvailableFrom.Size = new System.Drawing.Size(100, 22);
            this.dtpAvailableFrom.TabIndex = 152;
            this.dtpAvailableFrom.Tag = "AvailableFrom";
            // 
            // lblAvailableFrom
            // 
            this.lblAvailableFrom.AutoSize = true;
            this.lblAvailableFrom.Enabled = false;
            this.lblAvailableFrom.Location = new System.Drawing.Point(8, 45);
            this.lblAvailableFrom.Name = "lblAvailableFrom";
            this.lblAvailableFrom.Size = new System.Drawing.Size(85, 13);
            this.lblAvailableFrom.TabIndex = 151;
            this.lblAvailableFrom.Tag = "";
            this.lblAvailableFrom.Text = "Available From:";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(170, 168);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 129;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(196, 168);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 128;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblPackageID
            // 
            this.lblPackageID.AutoSize = true;
            this.lblPackageID.Enabled = false;
            this.lblPackageID.Location = new System.Drawing.Point(5, 5);
            this.lblPackageID.Name = "lblPackageID";
            this.lblPackageID.Size = new System.Drawing.Size(66, 13);
            this.lblPackageID.TabIndex = 127;
            this.lblPackageID.Tag = "";
            this.lblPackageID.Text = "Package ID:";
            // 
            // lblServicePackageTitle
            // 
            this.lblServicePackageTitle.AutoSize = true;
            this.lblServicePackageTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServicePackageTitle.Location = new System.Drawing.Point(3, 4);
            this.lblServicePackageTitle.Name = "lblServicePackageTitle";
            this.lblServicePackageTitle.Size = new System.Drawing.Size(82, 25);
            this.lblServicePackageTitle.TabIndex = 6;
            this.lblServicePackageTitle.Tag = "";
            this.lblServicePackageTitle.Text = "Package";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblServicePackageTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(-5, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(230, 35);
            this.pnlTitleBar.TabIndex = 20;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(115, 19);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(101, 140);
            this.checkedListBox1.TabIndex = 162;
            // 
            // frmServicePackage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(225, 230);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlTitleBar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmServicePackage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmServicePackage";
            this.Load += new System.EventHandler(this.frmServicePackage_Load);
            this.Shown += new System.EventHandler(this.frmServicePackage_Shown);
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.TextBox txtPackageID;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Label lblPackageID;
        private System.Windows.Forms.Label lblServicePackageTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.DateTimePicker dtpAvailableUntil;
        private System.Windows.Forms.Label lblAvailableUntil;
        private System.Windows.Forms.DateTimePicker dtpAvailableFrom;
        private System.Windows.Forms.Label lblAvailableFrom;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
    }
}