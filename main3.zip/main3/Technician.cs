﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Technician : Employee
    {
        public int TechnicianID { get; private set; }
        public int CompletedRequests { get; private set; }
        public string Specialization { get; private set; }

        public Technician(
            int technicianID = 0,
            int completedRequests = 0,
            string specialization = "",
            int employeeID = 0,
            int addressID = 0,
            string firstName = "",
            string lastName = "",
            DateTime dateOfBirth = default,
            string email = "",
            string phone = "",
            string category = "",
            string status = "",
            string schedule = "",
            float salary = 0,
            string notes = "")
            : base(employeeID, addressID, firstName, lastName, dateOfBirth, email, phone, category, status, schedule, salary, notes)
        {
            TechnicianID = technicianID;
            CompletedRequests = completedRequests;
            Specialization = specialization;
        }
    }


}
