﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class ServiceContract
    {
        public int ContractID { get; private set; }
        public int PackageID { get; private set; }
        public int SlaID { get; private set; }
        public string Status { get; private set; }
        public string Details { get; private set; }
        public string Category { get; private set; }
        public DateTime? PurchaseDate { get; private set; }
        public DateTime? EffectDate { get; private set; }
        public DateTime? ExpiryDate { get; private set; }
        public ServiceContract(
            int contractID = 0,
            int packageID = 0,
            int slaID = 0,
            string status = "",
            string details = "",
            string category = "",
            DateTime? purchaseDate = null,
            DateTime? effectDate = null,
            DateTime? expiryDate = null)
        {
            ContractID = contractID;
            PackageID = packageID;
            SlaID = slaID;
            Status = status;
            Details = details;
            Category = category;
            PurchaseDate = purchaseDate;
            EffectDate = effectDate;
            ExpiryDate = expiryDate;
        }
    }
}
