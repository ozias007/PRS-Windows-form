﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class SLA
    {
        public int SlaID { get; private set; }
        public string Description { get; private set; }
        public string ServicePackageDetails { get; private set; }
        public string ServicePriorityDetails { get; private set; }
        public string TargetPerformanceDetails { get; private set; }
        public string PartyObligationDetails { get; private set; }
        public string BreachPenaltyDetails { get; private set; }
        public string MetricProtocolDetails { get; private set; }
        public SLA(
            int slaID = 0,
            string description = "",
            string servicePackageDetails = "",
            string servicePriorityDetails = "",
            string targetPerformanceDetails = "",
            string partyObligationDetails = "",
            string breachPenaltyDetails = "",
            string metricProtocolDetails = "")
        {
            SlaID = slaID;
            Description = description;
            ServicePackageDetails = servicePackageDetails;
            ServicePriorityDetails = servicePriorityDetails;
            TargetPerformanceDetails = targetPerformanceDetails;
            PartyObligationDetails = partyObligationDetails;
            BreachPenaltyDetails = breachPenaltyDetails;
            MetricProtocolDetails = metricProtocolDetails;
        }
    }
}
