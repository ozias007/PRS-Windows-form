﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class ServicePackageServices
    {
        public int PackageID { get; private set; }
        public int ServiceID { get; private set; }
        public ServicePackageServices(
            int packageID,
            int serviceID)
        {
            PackageID = packageID;
            ServiceID = serviceID;
        }
    }
}
