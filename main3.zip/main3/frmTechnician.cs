﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmTechnician : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        public static ComboBox cmbA;
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Address> addresses = new List<Address>();
        public frmTechnician()
        {
            InitializeComponent();
        }

        private void frmTechnician_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
            cmbA = cmbAddressID;
        }

        private void frmTechnician_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            addresses = dlh.GetAddresses();
            uim.AddListToCmb(addresses, cmbAddressID, address => address.AddressID.ToString());
            uim.SetControlState(frmState.ToLower());
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
                cmbCategory.Enabled = false;
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                Technician technician = new Technician(
                    technicianID: 0,
                    completedRequests: 0,
                    specialization: cmbSpecialization.Text,
                    employeeID: 0,
                    addressID: int.Parse(cmbAddressID.Text),
                    firstName: txtFirstName.Text,
                    lastName: txtLastName.Text,
                    dateOfBirth: dtpDateOfBirth.Value.Date,
                    email: txtEmail.Text,
                    phone: mxtPhone.Text,
                    category: cmbCategory.Text,
                    status: cmbStatus.Text,
                    schedule: cmbSchedule.Text,
                    salary: float.Parse(mxtSalary.Text),
                    notes: txtNotes.Text
                );

                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateTechnician(technician);
                    uim.ClearControls(this);
                    MessageBox.Show("Technician created.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }

        private void btnAddress_Click(object sender, EventArgs e)
        {
            frmAddress.frmState = frmState.ToLower();
            frmAddress.frmSender = "technician";
            uim.SelectedOption("address");
        }
    }
}
