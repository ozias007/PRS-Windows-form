﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class ServicePackage
    {
        public int PackageID { get; private set; }
        public DateTime? AvailableFrom { get; private set; }
        public DateTime? AvailableUntil { get; private set; }
        public string Status { get; private set; }
        public ServicePackage(
            int packageID = 0,
            DateTime? availableFrom = null,
            DateTime? availableUntil = null,
            string status = "")
        {
            PackageID = packageID;
            AvailableFrom = availableFrom;
            AvailableUntil = availableUntil;
            Status = status;
        }
    }
}