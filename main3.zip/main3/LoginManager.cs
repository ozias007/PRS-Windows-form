﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BCrypt.Net;

namespace Main
{
    public class LoginManager 
    {
        public static LoginManager lm = GetInstance();
        private static LoginManager instance;
        private bool isLoggedIn = false;
        private Account loggedInAccount;
        DataHandler dlh = new DataHandler();
        private LoginManager() { }
        public static LoginManager GetInstance()
        {
            if (instance == null)
            {
                instance = new LoginManager();
            }
            return instance;
        }
        public bool Login(string username, string password)
        {
            Account account = dlh.GetAccountByUsername(username);
            if (account != null)
            {
                bool validPassword = BCrypt.Net.BCrypt.Verify(password, account.Password);
                if (validPassword == true)
                {
                    loggedInAccount = account;
                    isLoggedIn = true;
                }
            }
            return isLoggedIn;
        }
        public void Logout()
        {
            loggedInAccount = null;
            isLoggedIn = false;
        }
        public bool IsLoggedIn()
        {
            return isLoggedIn;
        }
        public Account GetLoggedInAccount()
        {
            return loggedInAccount;
        }

        //public static void GenerateAccounts()
        //{
        //    string msg;
        //    List<string> exists = new List<string>();
        //    List<string> created = new List<string>();
        //    string[,] accounts = {
        //        { "admin", "adminp", "admin" },
        //        { "call1", "callp", "callcentre" },
        //        { "service1", "servicep", "servicedepartment" },
        //        { "client1", "clientp", "clientmaintenance" },
        //        { "contract1", "contractp", "contractmaintenance" },
        //    };

        //    for (int i = 0; i < accounts.GetLength(0); i++)
        //    {
        //        string username = accounts[i, 0];
        //        if (lm.dlh.GetAccountByUsername(username) == null)
        //        {
        //            string password = accounts[i, 1];
        //            string hashed = BCrypt.Net.BCrypt.HashPassword(password);
        //            string category = accounts[i, 2];
        //            Account account = new Account(username, hashed, category);
        //            lm.dlh.CreateAccount(account);
        //            created.Add(username);
        //        }
        //        else exists.Add(username);
        //    }

        //    //if (exists.Count > 0)
        //    //{
        //    //    msg = $"{string.Join(", ", exists)} already exists.";
        //    //    MessageBox.Show(msg);
        //    //}
        //    //if (created.Count > 0)
        //    //{
        //    //    msg = $"{string.Join(", ", created)} created.";
        //    //    MessageBox.Show(msg);
        //    //}
        //}
    }
}