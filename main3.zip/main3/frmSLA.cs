﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmSLA : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        public frmSLA()
        {
            InitializeComponent();
        }

        private void frmSLA_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
        }

        private void frmSLA_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            uim.SetControlState(frmState.ToLower());
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                SLA sLA = new SLA(0, 
                    rtbDescription.Text,
                    mxtServicePackageDetails.Text,
                    rtbServicePriority.Text, 
                    rtbPerformanceTarget.Text, 
                    rtbPartyObligation.Text, 
                    rtbBreachPenalty.Text, 
                    rtbMetricProtocol.Text);
                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateSLA(sLA);
                    uim.ClearControls(this);
                    MessageBox.Show("SLA created.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }
    }
}
