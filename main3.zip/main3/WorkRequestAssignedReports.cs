﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class WorkRequestAssignedReports
    {
        public int RequestID { get; private set; }
        public int ReportID { get; private set; }
        public WorkRequestAssignedReports(int requestID = 0, int reportID = 0)
        {
            RequestID = requestID;
            ReportID = reportID;
        }
    }
}
