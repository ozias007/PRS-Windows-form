﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmWorkRequest : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private string requestID = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Technician> technicians = new List<Technician>();
        private List<CallReport> reports = new List<CallReport>();
        private List<WorkRequestAssignedReports> assignedReports= new List<WorkRequestAssignedReports>();
        private List<WorkRequestAssignedTechnicians> assignedTechnicians= new List<WorkRequestAssignedTechnicians>();

        public frmWorkRequest()
        {
            InitializeComponent();
        }

        private void frmWorkRequest_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
        }

        private void frmWorkRequest_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            uim.SetControlState(frmState.ToLower());
            requestID = txtRequestID.Text;
            technicians = dlh.GetTechnicians();
            reports = dlh.GetCallReports();
            assignedReports = dlh.GetWRAR();
            assignedTechnicians = dlh.GetWRAT();
            uim.AddTechnicianIDs(technicians, clbTechnicians, requestID, assignedTechnicians);
            uim.AddReportIDs(reports, clbReports, requestID, assignedReports);
            uim.CheckedState(frmState.ToLower());
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
                cmbStatus.Enabled = false;
                dtpCompletedDate.Checked = false;
                dtpCompletedDate.Enabled = false;
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                List<int> technicianIDs = new List<int>();
                List<int> reportIDs = new List<int>();
                if (clbTechnicians.CheckedItems.Count > 0 || clbReports.CheckedItems.Count > 0)
                {
                    if (clbTechnicians.CheckedItems.Count > 0 && clbReports.CheckedItems.Count > 0)
                    {
                        cmbStatus.SelectedItem = "In-progress";
                    }
                    if (clbTechnicians.CheckedItems.Count > 0)
                    {
                        for (int i = 0; i < clbTechnicians.CheckedItems.Count; i++)
                        {
                            technicianIDs.Add(int.Parse(clbTechnicians.CheckedItems[i].ToString()));
                        }
                    }
                    if (clbReports.CheckedItems.Count > 0)
                    {
                        for (int i = 0; i < clbReports.CheckedItems.Count; i++)
                        {
                            reportIDs.Add(int.Parse(clbReports.CheckedItems[i].ToString()));
                        }
                    }
                }
                bool finalDurationSuccess = int.TryParse(mxtFinalDuration.Text, out int parsedFinalDuration);
                bool expectedDurationSuccess = int.TryParse(mxtExpectedDuration.Text, out int parsedExpectedDuration);

                WorkRequest request = new WorkRequest(
                    requestID: 0,
                    requestDate: dtpRequestDate.Value.Date,
                    scheduledDate: dtpScheduledDate.Value.Date,
                    completedDate: dtpCompletedDate.Checked ? dtpCompletedDate.Value.Date : (DateTime?)null,
                    expectedDuration: expectedDurationSuccess ? parsedExpectedDuration : 0,
                    finalDuration: finalDurationSuccess ? parsedFinalDuration : (int?)null,
                    maintenanceType: cmbMaintenanceType.Text,
                    priority: cmbPriority.Text,
                    status: cmbStatus.Text
                );

                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateWorkRequest(request, technicianIDs, reportIDs);
                    uim.ClearControls(this);
                    MessageBox.Show("Request created.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
