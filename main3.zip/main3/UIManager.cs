﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using static System.Windows.Forms.AxHost;
using System.Data;
using Twilio.TwiML.Voice;
using System.Globalization;
using static System.Windows.Forms.LinkLabel;
using static System.Net.WebRequestMethods;

namespace Main
{
    public class UIManager
    {
        public static string dgvState;
        public static Dictionary<string, object> recordDetails;
        public List<string> invalid = new List<string>();
        public Color disabledBackColor = SystemColors.Control;
        public Color disabledForeColor = SystemColors.GrayText;
        private List<string> columnHeaders = new List<string>();
        private DataHandler dlh = new DataHandler();
        private Form form;
        private PictureBox exitPic;
        private Panel pnlMainBtns, titleBar, pnlSubControls;
        private List<ListBox> btnLsts;
        private DataGridView dgv;
        private ComboBox search;
        private TextBox searchVal;
        private bool isDragging = false;
        private Point lastCursor;
        private Point lastForm;
        public UIManager(Form form = null, Panel titleBar = null, PictureBox exitPic = null, Panel pnlBtns = null, List<ListBox> btnLsts = null, DataGridView dgv = null, ComboBox search = null, TextBox searchVal = null, Panel subControls = null)
        {
            this.form = form;
            this.titleBar = titleBar;
            this.exitPic = exitPic;
            this.pnlMainBtns = pnlBtns;
            this.btnLsts = btnLsts;
            this.dgv = dgv;
            this.search = search;
            this.searchVal = searchVal;
            this.pnlSubControls = subControls;
        }
        public void RegisterControlEvents()
        {
            if (titleBar != null)
            {
                titleBar.MouseDown += TitleBar_MouseDown;
                titleBar.MouseMove += TitleBar_MouseMove;
                titleBar.MouseUp += TitleBar_MouseUp;
            }
            if (exitPic != null)
            {
                exitPic.MouseEnter += Exit_MouseEnter;
                exitPic.MouseLeave += Exit_MouseLeave;
            }
            if (pnlMainBtns != null)
            {
                foreach (Control cntrl in pnlMainBtns.Controls)
                {
                    if (cntrl is Button || cntrl is PictureBox)
                    {
                        cntrl.MouseEnter += Item_MouseEnter;
                        cntrl.MouseLeave += Item_MouseLeave;
                    }
                }
            }
            if (btnLsts != null)
            {
                foreach (ListBox lstBox in btnLsts)
                {
                    lstBox.SelectedIndexChanged += List_SelectedIndexChanged;
                }
            }
            if (dgv != null)
            {
                dgv.CellClick += ViewDetails_CellClick;
            }
            if (search != null)
            {
                GetHeaders(dgv);
            }
            if (searchVal != null)
            {
                searchVal.TextChanged += Search_TextChanged;
            }
        }


        // Open forms, load data, set form states etc. based on selected list options
        public void SelectedOption(string option, ListBox lst = null)
        {
            switch (option.ToLower())
            {
                case "all":
                    dgvState = lst.Tag.ToString().ToLower();
                    switch (dgvState)
                    {
                        case "technician":
                            dlh.LoadTechnicianData(dgv);
                            break;
                        case "workrequest":
                            dlh.LoadWorkRequestData(dgv);
                            break;
                        case "callreport":
                            dlh.LoadCallReportData(dgv);
                            break;
                        case "sla":
                            dlh.LoadSLAData(dgv);
                            break;
                        case "client":
                            dlh.LoadClientData(dgv);
                            break;
                        case "servicecontract":
                            dlh.LoadServiceContractData(dgv);
                            break;
                        case "service":
                            dlh.LoadServiceData(dgv);
                            break;
                        case "servicepackage":
                            dlh.LoadServicePackageData(dgv);
                            break;
                    }
                    GetHeaders(dgv);
                    break;
                case "create":
                    switch (lst.Tag.ToString().ToLower())
                    {
                        case "technician":
                            if (frmTechnician.frmCount == 0)
                            {
                                frmTechnician.frmState = "create";
                                ShowForm("Main.frmTechnician");
                            }
                            break;
                        case "workrequest":
                            if (frmWorkRequest.frmCount == 0)
                            {
                                frmWorkRequest.frmState = "create";
                                ShowForm("Main.frmWorkRequest");
                            }
                            break;
                        case "callreport":
                            if (frmCallReport.frmCount == 0)
                            {
                                frmCallReport.frmState = "create";
                                ShowForm("Main.frmCallReport");
                            }
                            break;
                        case "sla":
                            if (frmSLA.frmCount == 0)
                            {
                                frmSLA.frmState = "create";
                                ShowForm("Main.frmSLA");
                            }
                            break;
                        case "client":
                            if (frmClient.frmCount == 0)
                            {
                                frmClient.frmState = "create";
                                ShowForm("Main.frmClient");
                            }
                            break;
                        case "servicecontract":
                            if (frmServiceContract.frmCount == 0)
                            {
                                frmServiceContract.frmState = "create";
                                ShowForm("Main.frmServiceContract");
                            }
                            break;
                        case "service":
                            if (frmService.frmCount == 0)
                            {
                                frmService.frmState = "create";
                                ShowForm("Main.frmService");
                            }
                            break;
                        case "servicepackage":
                            if (frmServicePackage.frmCount == 0)
                            {
                                frmServicePackage.frmState = "create";
                                ShowForm("Main.frmServicePackage");
                            }
                            break;
                    }
                    break;
                case "message":
                    if (frmMessage.frmCount == 0)
                    {
                        ShowForm("Main.frmMessage");
                    }
                    break;
                case "address":
                    if (frmAddress.frmCount == 0)
                    {
                        ShowForm("Main.frmAddress");
                    }
                    break;
                case "view":
                    switch (dgvState.ToLower())
                    {
                        case "technician":
                            if (frmTechnician.frmCount == 0)
                            {
                                frmTechnician.frmState = "view";
                                ShowForm("Main.frmTechnician");
                            }
                            break;
                        case "workrequest":
                            if (frmWorkRequest.frmCount == 0)
                            {
                                frmWorkRequest.frmState = "view";
                                ShowForm("Main.frmWorkRequest");
                            }
                            break;
                        case "callreport":
                            if (frmCallReport.frmCount == 0)
                            {
                                frmCallReport.frmState = "view";
                                ShowForm("Main.frmCallReport");
                            }
                            break;
                        case "sla":
                            if (frmSLA.frmCount == 0)
                            {
                                frmSLA.frmState = "view";
                                ShowForm("Main.frmSLA");
                            }
                            break;
                        case "client":
                            if (frmClient.frmCount == 0)
                            {
                                frmClient.frmState = "view";
                                ShowForm("Main.frmClient");
                            }
                            break;
                        case "servicecontract":
                            if (frmServiceContract.frmCount == 0)
                            {
                                frmServiceContract.frmState = "view";
                                ShowForm("Main.frmServiceContract");
                            }
                            break;
                        case "service":
                            if (frmService.frmCount == 0)
                            {
                                frmService.frmState = "view";
                                ShowForm("Main.frmService");
                            }
                            break;
                        case "servicepackage":
                            if (frmServicePackage.frmCount == 0)
                            {
                                frmServicePackage.frmState = "view";
                                ShowForm("Main.frmServicePackage");
                            }
                            break;
                    }
                    break;
            }
        }

        // Set the state of subform controls
        public void SetControlState(string state)
        {
            switch (state)
            {
                case "create":

                    foreach (Control cntrl in pnlSubControls.Controls)
                    {
                        cntrl.Enabled = true;
                        switch (cntrl)
                        {
                            case ComboBox cmb:
                                if (cmb.Items.Count > 0)
                                {
                                    cmb.SelectedIndex = 0;
                                }
                                break;
                            case CheckedListBox clb:
                                for (int i = clb.Items.Count - 1; i >= 0; i--)
                                {
                                    if (clb.GetItemChecked(i))
                                    {
                                        clb.Items.Remove(clb.Items[i]);
                                    }
                                }
                                break;
                            case DateTimePicker dtp:
                                dtp.Text = default;
                                break;
                            case Label lbl:
                                break;
                            case Panel pnl:
                                foreach (Control cntr in pnl.Controls)
                                {
                                    cntr.Enabled = true;
                                }
                                break;
                            case Button btn:
                                btn.Enabled = true;
                                if (btn.Tag.ToString().ToLower() == "confirm")
                                {
                                    btn.BackgroundImage = Image.FromFile(ImagePath("accept.png"));
                                }
                                break;
                            default:
                                    cntrl.Text = "";
                                break;
                        }
                        if (!(cntrl is ComboBox))
                        {
                            if (cntrl.Tag != null)
                            {
                                string tag = cntrl.Tag.ToString().ToLower();
                                if (tag.Length >= 2 && tag.Substring(tag.Length - 2) == "id")
                                {
                                    cntrl.Enabled = false;
                                    cntrl.Text = "auto";
                                }
                            }
                        }
                    }
                    break;
                case "view":
                    if (recordDetails != null)
                    {
                        foreach (var item in recordDetails)
                        {
                            if (item.Value != null && item.Value.ToString() != "")
                            {
                                string key = item.Key.ToString().ToLower();
                                foreach (Control cntrl in pnlSubControls.Controls)
                                {
                                    string tag = "";
                                    if (cntrl.Tag != null)
                                    {
                                        tag = cntrl.Tag.ToString().ToLower();
                                    }
                                    if (cntrl is Panel pnl)
                                    {
                                        if (tag.Length >= 4)
                                        {
                                            if (tag.Substring(0, 4) != "date")
                                            {
                                                pnl.Enabled = true;
                                                foreach (Control ctrl in pnl.Controls)
                                                {
                                                    ctrl.Enabled = true;
                                                }
                                            }
                                        }
                                    }
                                    if (cntrl is Button btn)
                                    {
                                        if (tag == "confirm")
                                        {
                                            btn.BackgroundImage = Image.FromFile(ImagePath("accept2.png"));
                                            btn.Enabled = false;
                                        }
                                        if (tag == "add")
                                        {
                                            btn.BackgroundImage = Image.FromFile(ImagePath("plus1.png"));
                                            btn.Enabled = false;
                                        }
                                    }
                                    if (!(cntrl is Label) && !(cntrl is Button) && !(cntrl is Panel))
                                    {
                                        if (tag == key)
                                        {
                                            switch (cntrl)
                                            {
                                                case ComboBox cmb:
                                                    cmb.SelectedItem = item.Value.ToString();
                                                    break;
                                                case CheckedListBox clb:
                                                    GetChecked(clb);
                                                    break;
                                                default:
                                                    cntrl.Text = item.Value.ToString();
                                                    break;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                            
                        }
                    }
                    break;
            }
        }

        // Prevent checklistbox value alterations when a form is in view state
        public void clb_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            e.NewValue = e.CurrentValue;
        }
        // Enable the dragging of a window using its titlebar panel
        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            isDragging = true;
            lastCursor = Cursor.Position;
            lastForm = form.Location;
        }
        private void TitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point difference = Point.Subtract(Cursor.Position, new Size(lastCursor));
                form.Location = Point.Add(lastForm, new Size(difference));
            }
        }
        private void TitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }
        // Change the colour of exit icons
        private void Exit_MouseEnter(object sender, EventArgs e)
        {
            exitPic.BackgroundImage = Image.FromFile(ImagePath("back2.png"));
        }
        private void Exit_MouseLeave(object sender, EventArgs e)
        {
            exitPic.BackgroundImage = Image.FromFile(ImagePath("back1.png"));
        }
        // Change colour of buttons and related icons
        private void Item_MouseEnter(object sender, EventArgs e)
        {
            ChangeColor(sender, Color.LightGray);
        }
        private void Item_MouseLeave(object sender, EventArgs e)
        {
            ChangeColor(sender, Color.White);
        }
        // Prevent a form from completely leaving the screen
        private void Form_LocationChanged(object sender, EventArgs e)
        {
            Form currentForm = sender as Form;
            if (currentForm == null) return;
            Screen screen = Screen.FromControl(currentForm);
            int edgeBuffer = 30; // visibility
            // Horizontal visibility
            if (currentForm.Left < screen.WorkingArea.Left - currentForm.Width + edgeBuffer)
            {
                currentForm.Left = screen.WorkingArea.Left - currentForm.Width + edgeBuffer;
            }
            if (currentForm.Right > screen.WorkingArea.Right + currentForm.Width - edgeBuffer)
            {
                currentForm.Left = screen.WorkingArea.Right - edgeBuffer;
            }
            // Vertical visibility
            if (currentForm.Top < screen.WorkingArea.Top - currentForm.Height + edgeBuffer)
            {
                currentForm.Top = screen.WorkingArea.Top - currentForm.Height + edgeBuffer;
            }
            if (currentForm.Bottom > screen.WorkingArea.Bottom + currentForm.Height - edgeBuffer)
            {
                currentForm.Top = screen.WorkingArea.Bottom - edgeBuffer;
            }
        }
        // List index change event
        private void List_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sender is ListBox lst)
            {
                string listOption = lst.SelectedItem.ToString();
                SelectedOption(listOption, lst);
            }
        }
        // Search event
        private void Search_TextChanged(object sender, EventArgs e)
        {
            Search(searchVal.Text, search.Text);
        }
        // View details of a record
        private void ViewDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (recordDetails != null)
            {
                recordDetails.Clear();
            }
            DataGridView dgv = sender as DataGridView;
            if (dgv == null) return;
            if (e.ColumnIndex == dgv.Columns["btnColumn"].Index && e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv.Rows[e.RowIndex];
                try
                {
                    if (!string.IsNullOrWhiteSpace(row.Cells[1].Value.ToString()))
                    {
                        Dictionary<string, object> rowData = new Dictionary<string, object>();
                        foreach (DataGridViewCell cell in row.Cells)
                        {
                            if (cell.ColumnIndex != 0)
                            {
                                string headerName = dgv.Columns[cell.ColumnIndex].HeaderText;
                                object value = cell.Value;
                                rowData[headerName] = value;
                            }
                        }
                        recordDetails = rowData;
                        SelectedOption("view");
                    }
                }
                catch (Exception ex) { }
            }
        }
        // Methods
        // Get datagridview headers
        public void GetChecked(CheckedListBox clb)
        {
            switch (clb.Tag.ToString().ToLower())
            {
                case "assignedtechnicians":
                    List<WorkRequestAssignedTechnicians> assignedTechnicians = dlh.GetWRAT();
                    foreach (WorkRequestAssignedTechnicians technician in assignedTechnicians)
                    {
                        for (int i = 0; i < clb.Items.Count; i++)
                        {
                            if (technician.TechnicianID.ToString() == clb.Items[i].ToString())
                            {
                                clb.SetItemChecked(i, true);
                                break;
                            }
                        }
                    }
                    break;
                case "assignedreports":
                    List<WorkRequestAssignedReports> assignedReports = dlh.GetWRAR();
                    foreach (WorkRequestAssignedReports report in assignedReports)
                    {
                        for (int i = 0; i < clb.Items.Count; i++)
                        {
                            if (report.ReportID.ToString() == clb.Items[i].ToString())
                            {
                                clb.SetItemChecked(i, true);
                                break;
                            }
                        }
                    }
                    break;
            }
        }
        private void GetHeaders(DataGridView dgv)
        {
            search.Items.Clear();
            columnHeaders.Clear();
            foreach (DataGridViewColumn column in dgv.Columns)
            {
                if (column.Index != 0)
                {
                    columnHeaders.Add(column.HeaderText);
                }
            }
            foreach (var item in columnHeaders)
            {
                search.Items.Add(item);
            }
            if (search.Items.Count > 0)
            {
                search.SelectedIndex = 0;
            }
        }
        // Change button/picturebox colour method
        private void ChangeColor(object sender, Color color)
        {
            string iconName, btnName;
            if (sender is Button btn)
            {
                btn.BackColor = color;
                iconName = "pic" + btn.Tag;
                pnlMainBtns.Controls[iconName].BackColor = color;
            }
            else if (sender is PictureBox pic)
            {
                pic.BackColor = color;
                btnName = "btn" + pic.Name.Substring(3);
                pnlMainBtns.Controls[btnName].BackColor = color;
            }
        }
        // Set the visible state of dropdown lists and enabled of buttons
        public int SetButtonState(int click, Button btn, Panel pnl)
        {
            click++;
            bool state = false;
            if (click > 1)
            {
                state = true;
                click = 0;
            }
            foreach (Control cntrl in pnl.Controls)
            {
                if (cntrl is Button)
                {
                    if (cntrl != btn)
                    {
                        cntrl.Enabled = state;
                    }
                }
            }
            return click;
        }
        public void SetListState(ListBox lst, string[] array, Button btn)
        {
            if (!lst.Visible)
            {
                lst.Location = new Point(btn.Left, btn.Bottom);
                lst.Items.Clear();
                lst.Items.AddRange(array);
                lst.Size = new Size(btn.Width, (20 + (array.Length * 10)));
                lst.Visible = true;
            }
            else lst.Visible = false;
        }
        // Show any existing form
        public void ShowForm(string formName)
        {
            Type formType = Assembly.GetExecutingAssembly().GetType(formName);
            if (formType != null && formType.IsSubclassOf(typeof(Form)))
            {
                Form formInstance = Activator.CreateInstance(formType) as Form;
                formInstance.LocationChanged += Form_LocationChanged;
                formInstance.Show();
            }
            else
            {
                MessageBox.Show("Form not found.");
            }
        }
        // Set the state of the home form
        public void SetHomeState(string state)
        {
            foreach (Control cntrl in pnlMainBtns.Controls)
            {
                if (cntrl.Tag.ToString().ToLower() != state.ToLower())
                {
                    cntrl.Enabled = false;
                }
            }
        }
        // Get the path of a specific image
        public string ImagePath(string imgName)
        {
            string startupPath = System.Windows.Forms.Application.StartupPath;
            string parentDirectory = Directory.GetParent(startupPath).FullName;
            string imagePath = Path.Combine(parentDirectory, "Images", imgName);
            return imagePath;
        }
        // Datagridview template
        public void dgvTemplate(DataGridView dgv)
        {
            DataGridViewButtonColumn btnColumn = new DataGridViewButtonColumn();
            btnColumn.HeaderText = "Details";
            btnColumn.Text = "View";
            btnColumn.Name = "btnColumn";
            btnColumn.UseColumnTextForButtonValue = true;
            dgv.Columns.Add(btnColumn);

            dgv.ReadOnly = true;
            dgv.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor = Color.LightGray;
            dgv.RowHeadersVisible = false;

            dgv.RowsDefaultCellStyle.BackColor = Color.Lavender;
            dgv.AlternatingRowsDefaultCellStyle.BackColor = Color.White;

            dgv.EnableHeadersVisualStyles = false;
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgv.ColumnHeadersDefaultCellStyle.Font = new Font(dgv.Font, FontStyle.Bold);
        }
        // Search functionality
        public void Search(string val, string column)
        {
            if (dgv.DataSource is BindingSource bindingSource)
            {
                if (string.IsNullOrEmpty(val))
                {
                    bindingSource.Filter = "";
                }
                else
                {
                    bindingSource.Filter = string.Format("CONVERT([{0}], 'System.String') LIKE '%{1}%'", column, val.Replace("'", "''"));

                    if (bindingSource.Cast<DataRowView>().Any(row => string.Compare(row[column].ToString(), val, StringComparison.OrdinalIgnoreCase) == 0))
                    {
                        bindingSource.Filter = string.Format("CONVERT([{0}], 'System.String') = '{1}'", column, val.Replace("'", "''"));
                    }
                }
                if (dgv.Rows.Count > 0)
                {
                    dgv.FirstDisplayedScrollingRowIndex = 0;
                }
            }
        }

        // Add a list to a combobox
        public void AddListToCmb<T>(List<T> items, ComboBox cmb, Func<T, string> selector)
        {
            cmb.Items.Clear();
            foreach (T item in items)
            {
                cmb.Items.Add(selector(item));
            }
        }

        public void AddItemToCmb(string id, ComboBox cmb, bool selected = false)
        {
            cmb.Items.Add(id); 
            if (selected) 
            { 
                cmb.SelectedItem = id;
            }
        }

        public void AddTechnicianIDs(List<Technician> technicians, CheckedListBox clb, string id = "", List<WorkRequestAssignedTechnicians> wrat = null)
        {
            clb.Items.Clear();
            foreach (var technician in technicians)
            {
                clb.Items.Add(technician.TechnicianID.ToString());
            }
            if (wrat != null && id != "")
            {
                for (int i = 0; i < clb.Items.Count; i++)
                {
                    foreach (var assigned in wrat)
                    {
                        if (assigned.TechnicianID.ToString() == clb.Items[i].ToString() && assigned.RequestID.ToString() == id)
                        {
                            clb.SetItemChecked(i, true);
                        }
                    }
                }
            }
        }
        public void AddReportIDs(List<CallReport> reports, CheckedListBox clb, string id = "", List<WorkRequestAssignedReports> wrar = null)
        {
            clb.Items.Clear();
            foreach (var report in reports)
            {
                clb.Items.Add(report.ReportID.ToString());
            }
            if (wrar != null && id != "")
            {
                for (int i = 0; i < clb.Items.Count; i++)
                {
                    foreach (var assigned in wrar)
                    {
                        if (assigned.ReportID.ToString() == clb.Items[i].ToString() && assigned.RequestID.ToString() == id)
                        {
                            clb.SetItemChecked(i, true);
                            break;
                        }
                    }
                }
            }
        }

        public void AddContractIDs(List<ServiceContract> contracts, CheckedListBox clb, string id = "", List<ClientContracts> cc = null)
        {
            clb.Items.Clear();
            foreach (var contract in contracts)
            {
                clb.Items.Add(contract.ContractID.ToString());
            }
            if (cc != null && id != "")
            {
                for (int i = 0; i < clb.Items.Count; i++)
                {
                    foreach (var contract in cc)
                    {
                        if (contract.ContractID.ToString() == clb.Items[i].ToString() && contract.ClientID.ToString() == id)
                        {
                            clb.SetItemChecked(i, true);
                            break;
                        }
                    }
                }
            }
        }

        public void ClearControls(Control parent)
        {
            foreach (Control cntrl in parent.Controls)
            {
                if (cntrl is TextBox)
                {
                    ((TextBox)cntrl).Clear();
                    string text = "";
                    if (cntrl.Tag != null)
                    {
                        string tag = cntrl.Tag.ToString().ToLower();
                        if (tag.Length >= 2)
                        {
                            if (tag.Substring(tag.Length - 2, 2) == "id") { text = "auto"; }
                        }
                        if (tag == "starttime") { text = "00:00:00"; }
                    }
                    cntrl.Text = text;
                }
                else if (cntrl is RichTextBox)
                {
                    ((RichTextBox)cntrl).Clear();
                }
                else if (cntrl is MaskedTextBox)
                {
                    ((MaskedTextBox)cntrl).Clear();
                }
                else if (cntrl is ComboBox)
                {
                    ComboBox cmb = (ComboBox)cntrl;
                    if(cmb.Tag != null)
                    {
                        string tag = cmb.Tag.ToString().ToLower();
                        if (tag != "addressid")
                        {
                            if (cmb.Items.Count > 0)
                            {
                                cmb.SelectedIndex = 0;
                            }
                            else cmb.SelectedIndex = -1;
                        }
                    }
                }
                else if (cntrl is DateTimePicker)
                {
                    ((DateTimePicker)cntrl).Value = DateTime.Now;
                }
                else if (cntrl is CheckBox)
                {
                    ((CheckBox)cntrl).Checked = false;
                }
                else if (cntrl is RadioButton)
                {
                    ((RadioButton)cntrl).Checked = false;
                }
                else if (cntrl is CheckedListBox)
                {
                    CheckedListBox clb = (CheckedListBox)cntrl;
                    for (int i = 0; i < clb.Items.Count; i++)
                    {
                        clb.SetItemChecked(i, false);
                    }
                }
                else if (cntrl is ListBox)
                {
                    ((ListBox)cntrl).ClearSelected();
                }
                else if (cntrl is GroupBox || cntrl is Panel || cntrl is TabControl || cntrl is TabPage)
                {
                    ClearControls(cntrl);
                }
            }
        }

        public int ValidateInput(Panel pnl)
        {
            int count = 0;
            foreach (Control cntrl in pnl.Controls)
            {
                bool isValid = false;
                switch (cntrl)
                {
                    case Panel subpnl:
                        isValid = dtpValid(subpnl);
                        break;
                    case RichTextBox rtb:
                        isValid = !string.IsNullOrWhiteSpace(rtb.Text);
                        break;
                    case MaskedTextBox mxt:
                        isValid = mxt.MaskCompleted;
                        break;
                    case TextBox txt:
                        if (txt.Tag != null)
                        {
                            string tag = txt.Tag.ToString().ToLower();
                            if (tag != "notes" && tag != "addressline2")
                            {
                                isValid = !string.IsNullOrWhiteSpace(txt.Text);
                            }
                            else isValid = true;
                        }
                        break;
                    case ComboBox cmb:
                        isValid = cmb.SelectedIndex != -1;
                        break;
                    default:
                        isValid = true;
                        break;
                }
                cntrl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                if (isValid == false)
                {
                    count++;
                }
            }
            return count;
        }

        private bool dtpValid(Panel pnl)
        {
            bool isValid = true;
            foreach(Control cntrl in pnl.Controls)
            {
                if (cntrl is DateTimePicker dtp)
                {
                    DateTime startDate = new DateTime(2023, 1, 1);
                    DateTime endDate = new DateTime(2024, 1, 1);
                    string tag = cntrl.Parent.Tag.ToString().ToLower();
                    switch (tag)
                    {
                        case "datepickernow":
                            isValid = dtp.Value.Date == DateTime.Now.Date;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                        case "datepickerdob":
                            startDate = new DateTime(1823, 1, 1);
                            endDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                            isValid = dtp.Value.Date >= startDate && dtp.Value.Date <= endDate;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                        case ("datepickerreq"):
                            isValid = dtp.Value.Date == DateTime.Now.Date;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                        case ("datepickersch"):
                            startDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);
                            endDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day + 5);
                            isValid = dtp.Value.Date >= startDate && dtp.Value.Date <= endDate;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                        case ("datepickercom"):
                            isValid = dtp.Value.Date == DateTime.Now.Date;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                        default:
                            startDate = new DateTime(2023, 1, 1);
                            endDate = new DateTime(2024, 1, 1);
                            isValid = dtp.Value.Date >= startDate && dtp.Value.Date <= endDate;
                            pnl.BackColor = isValid ? SystemColors.Window : Color.LightPink;
                            break;
                    }
                }
            }
            return isValid;
        }

        public void CheckedState(string frmS)
        {
            if (frmS == "view")
            {
                foreach (Control cntrl in pnlSubControls.Controls)
                {
                    if (cntrl is CheckedListBox clb)
                    {
                        clb.ItemCheck += clb_ItemCheck;
                        clb.BackColor = disabledBackColor;
                        clb.ForeColor = disabledForeColor;
                        clb.Enabled = true;
                    }
                }
            }
            if (frmS == "create")
            {
                foreach (Control cntrl in pnlSubControls.Controls)
                {
                        if (cntrl is CheckedListBox clb)
                        {
                            clb.ItemCheck -= clb_ItemCheck;
                            clb.BackColor = default;
                            clb.ForeColor = default;
                            clb.Enabled = true;
                        }
                }
            }
        }
    }
}
