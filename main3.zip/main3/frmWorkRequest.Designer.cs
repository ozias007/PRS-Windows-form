﻿namespace Main
{
    partial class frmWorkRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWorkRequest));
            this.lblExpectedDuration = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblCompletedDate = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblPriority = new System.Windows.Forms.Label();
            this.lblTechnicians = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblMaintenanceType = new System.Windows.Forms.Label();
            this.lblRequestDate = new System.Windows.Forms.Label();
            this.lblFinalDuration = new System.Windows.Forms.Label();
            this.txtRequestID = new System.Windows.Forms.TextBox();
            this.lblRequestID = new System.Windows.Forms.Label();
            this.lblWorkRequestTitle = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.lblScheduledDate = new System.Windows.Forms.Label();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.mxtFinalDuration = new System.Windows.Forms.MaskedTextBox();
            this.mxtExpectedDuration = new System.Windows.Forms.MaskedTextBox();
            this.clbReports = new System.Windows.Forms.CheckedListBox();
            this.clbTechnicians = new System.Windows.Forms.CheckedListBox();
            this.cmbMaintenanceType = new System.Windows.Forms.ComboBox();
            this.cmbPriority = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.pnlCompletedDate = new System.Windows.Forms.Panel();
            this.dtpCompletedDate = new System.Windows.Forms.DateTimePicker();
            this.pnlScheduledDate = new System.Windows.Forms.Panel();
            this.dtpScheduledDate = new System.Windows.Forms.DateTimePicker();
            this.pnlRequestDate = new System.Windows.Forms.Panel();
            this.dtpRequestDate = new System.Windows.Forms.DateTimePicker();
            this.pnlTitleBar.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.pnlCompletedDate.SuspendLayout();
            this.pnlScheduledDate.SuspendLayout();
            this.pnlRequestDate.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblExpectedDuration
            // 
            this.lblExpectedDuration.AutoSize = true;
            this.lblExpectedDuration.Enabled = false;
            this.lblExpectedDuration.Location = new System.Drawing.Point(112, 5);
            this.lblExpectedDuration.Name = "lblExpectedDuration";
            this.lblExpectedDuration.Size = new System.Drawing.Size(82, 13);
            this.lblExpectedDuration.TabIndex = 76;
            this.lblExpectedDuration.Tag = "";
            this.lblExpectedDuration.Text = "Min. Expected:";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Open",
            "In-progress",
            "Closed"});
            this.cmbStatus.Location = new System.Drawing.Point(221, 59);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 73;
            this.cmbStatus.Tag = "Status";
            this.cmbStatus.SelectedIndexChanged += new System.EventHandler(this.cmbStatus_SelectedIndexChanged);
            // 
            // lblCompletedDate
            // 
            this.lblCompletedDate.AutoSize = true;
            this.lblCompletedDate.Enabled = false;
            this.lblCompletedDate.Location = new System.Drawing.Point(6, 165);
            this.lblCompletedDate.Name = "lblCompletedDate";
            this.lblCompletedDate.Size = new System.Drawing.Size(93, 13);
            this.lblCompletedDate.TabIndex = 70;
            this.lblCompletedDate.Tag = "";
            this.lblCompletedDate.Text = "Completed Date:";
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Enabled = false;
            this.lblReports.Location = new System.Drawing.Point(217, 85);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(50, 13);
            this.lblReports.TabIndex = 68;
            this.lblReports.Tag = "";
            this.lblReports.Text = "Reports:";
            // 
            // lblPriority
            // 
            this.lblPriority.AutoSize = true;
            this.lblPriority.Enabled = false;
            this.lblPriority.Location = new System.Drawing.Point(113, 45);
            this.lblPriority.Name = "lblPriority";
            this.lblPriority.Size = new System.Drawing.Size(46, 13);
            this.lblPriority.TabIndex = 66;
            this.lblPriority.Tag = "";
            this.lblPriority.Text = "Priority:";
            // 
            // lblTechnicians
            // 
            this.lblTechnicians.AutoSize = true;
            this.lblTechnicians.Enabled = false;
            this.lblTechnicians.Location = new System.Drawing.Point(112, 85);
            this.lblTechnicians.Name = "lblTechnicians";
            this.lblTechnicians.Size = new System.Drawing.Size(69, 13);
            this.lblTechnicians.TabIndex = 62;
            this.lblTechnicians.Text = "Technicians:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(219, 45);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 61;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // lblMaintenanceType
            // 
            this.lblMaintenanceType.AutoSize = true;
            this.lblMaintenanceType.Enabled = false;
            this.lblMaintenanceType.Location = new System.Drawing.Point(6, 45);
            this.lblMaintenanceType.Name = "lblMaintenanceType";
            this.lblMaintenanceType.Size = new System.Drawing.Size(77, 13);
            this.lblMaintenanceType.TabIndex = 59;
            this.lblMaintenanceType.Tag = "";
            this.lblMaintenanceType.Text = "Maintenance:";
            // 
            // lblRequestDate
            // 
            this.lblRequestDate.AutoSize = true;
            this.lblRequestDate.Enabled = false;
            this.lblRequestDate.Location = new System.Drawing.Point(6, 85);
            this.lblRequestDate.Name = "lblRequestDate";
            this.lblRequestDate.Size = new System.Drawing.Size(79, 13);
            this.lblRequestDate.TabIndex = 56;
            this.lblRequestDate.Tag = "";
            this.lblRequestDate.Text = "Request Date:";
            // 
            // lblFinalDuration
            // 
            this.lblFinalDuration.AutoSize = true;
            this.lblFinalDuration.Enabled = false;
            this.lblFinalDuration.Location = new System.Drawing.Point(218, 5);
            this.lblFinalDuration.Name = "lblFinalDuration";
            this.lblFinalDuration.Size = new System.Drawing.Size(61, 13);
            this.lblFinalDuration.TabIndex = 55;
            this.lblFinalDuration.Tag = "";
            this.lblFinalDuration.Text = "Min. Final:";
            // 
            // txtRequestID
            // 
            this.txtRequestID.Enabled = false;
            this.txtRequestID.Location = new System.Drawing.Point(9, 19);
            this.txtRequestID.Name = "txtRequestID";
            this.txtRequestID.Size = new System.Drawing.Size(100, 22);
            this.txtRequestID.TabIndex = 54;
            this.txtRequestID.Tag = "RequestID";
            // 
            // lblRequestID
            // 
            this.lblRequestID.AutoSize = true;
            this.lblRequestID.Enabled = false;
            this.lblRequestID.Location = new System.Drawing.Point(5, 5);
            this.lblRequestID.Name = "lblRequestID";
            this.lblRequestID.Size = new System.Drawing.Size(66, 13);
            this.lblRequestID.TabIndex = 51;
            this.lblRequestID.Tag = "";
            this.lblRequestID.Text = "Request ID:";
            // 
            // lblWorkRequestTitle
            // 
            this.lblWorkRequestTitle.AutoSize = true;
            this.lblWorkRequestTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkRequestTitle.Location = new System.Drawing.Point(3, 4);
            this.lblWorkRequestTitle.Name = "lblWorkRequestTitle";
            this.lblWorkRequestTitle.Size = new System.Drawing.Size(80, 25);
            this.lblWorkRequestTitle.TabIndex = 6;
            this.lblWorkRequestTitle.Tag = "";
            this.lblWorkRequestTitle.Text = "Request";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblWorkRequestTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 16;
            this.pnlTitleBar.Tag = "TitleBar";
            // 
            // lblScheduledDate
            // 
            this.lblScheduledDate.AutoSize = true;
            this.lblScheduledDate.Enabled = false;
            this.lblScheduledDate.Location = new System.Drawing.Point(6, 125);
            this.lblScheduledDate.Name = "lblScheduledDate";
            this.lblScheduledDate.Size = new System.Drawing.Size(91, 13);
            this.lblScheduledDate.TabIndex = 58;
            this.lblScheduledDate.Tag = "";
            this.lblScheduledDate.Text = "Scheduled Date:";
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.Controls.Add(this.mxtFinalDuration);
            this.pnlControls.Controls.Add(this.mxtExpectedDuration);
            this.pnlControls.Controls.Add(this.clbReports);
            this.pnlControls.Controls.Add(this.clbTechnicians);
            this.pnlControls.Controls.Add(this.cmbMaintenanceType);
            this.pnlControls.Controls.Add(this.cmbPriority);
            this.pnlControls.Controls.Add(this.lblExpectedDuration);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.lblCompletedDate);
            this.pnlControls.Controls.Add(this.lblReports);
            this.pnlControls.Controls.Add(this.lblPriority);
            this.pnlControls.Controls.Add(this.lblTechnicians);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.lblMaintenanceType);
            this.pnlControls.Controls.Add(this.lblScheduledDate);
            this.pnlControls.Controls.Add(this.lblRequestDate);
            this.pnlControls.Controls.Add(this.lblFinalDuration);
            this.pnlControls.Controls.Add(this.txtRequestID);
            this.pnlControls.Controls.Add(this.lblRequestID);
            this.pnlControls.Controls.Add(this.pnlCompletedDate);
            this.pnlControls.Controls.Add(this.pnlScheduledDate);
            this.pnlControls.Controls.Add(this.pnlRequestDate);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 235);
            this.pnlControls.TabIndex = 17;
            this.pnlControls.Tag = "Controls";
            // 
            // mxtFinalDuration
            // 
            this.mxtFinalDuration.Enabled = false;
            this.mxtFinalDuration.Location = new System.Drawing.Point(221, 19);
            this.mxtFinalDuration.Mask = "9999999999";
            this.mxtFinalDuration.Name = "mxtFinalDuration";
            this.mxtFinalDuration.Size = new System.Drawing.Size(100, 22);
            this.mxtFinalDuration.TabIndex = 107;
            this.mxtFinalDuration.Tag = "FinalDuration";
            // 
            // mxtExpectedDuration
            // 
            this.mxtExpectedDuration.Enabled = false;
            this.mxtExpectedDuration.Location = new System.Drawing.Point(115, 19);
            this.mxtExpectedDuration.Mask = "0999999999";
            this.mxtExpectedDuration.Name = "mxtExpectedDuration";
            this.mxtExpectedDuration.Size = new System.Drawing.Size(100, 22);
            this.mxtExpectedDuration.TabIndex = 106;
            this.mxtExpectedDuration.Tag = "ExpectedDuration";
            // 
            // clbReports
            // 
            this.clbReports.FormattingEnabled = true;
            this.clbReports.Location = new System.Drawing.Point(221, 99);
            this.clbReports.Name = "clbReports";
            this.clbReports.Size = new System.Drawing.Size(100, 89);
            this.clbReports.TabIndex = 105;
            this.clbReports.Tag = "ReportIDs";
            // 
            // clbTechnicians
            // 
            this.clbTechnicians.FormattingEnabled = true;
            this.clbTechnicians.Location = new System.Drawing.Point(115, 99);
            this.clbTechnicians.Name = "clbTechnicians";
            this.clbTechnicians.Size = new System.Drawing.Size(100, 89);
            this.clbTechnicians.TabIndex = 104;
            this.clbTechnicians.Tag = "TechnicianIDs";
            // 
            // cmbMaintenanceType
            // 
            this.cmbMaintenanceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaintenanceType.Enabled = false;
            this.cmbMaintenanceType.FormattingEnabled = true;
            this.cmbMaintenanceType.Items.AddRange(new object[] {
            "General",
            "Mechanical",
            "Electrical"});
            this.cmbMaintenanceType.Location = new System.Drawing.Point(9, 59);
            this.cmbMaintenanceType.Name = "cmbMaintenanceType";
            this.cmbMaintenanceType.Size = new System.Drawing.Size(100, 21);
            this.cmbMaintenanceType.TabIndex = 100;
            this.cmbMaintenanceType.Tag = "MaintenanceType";
            // 
            // cmbPriority
            // 
            this.cmbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPriority.Enabled = false;
            this.cmbPriority.FormattingEnabled = true;
            this.cmbPriority.Items.AddRange(new object[] {
            "High",
            "Medium",
            "Low"});
            this.cmbPriority.Location = new System.Drawing.Point(115, 59);
            this.cmbPriority.Name = "cmbPriority";
            this.cmbPriority.Size = new System.Drawing.Size(100, 21);
            this.cmbPriority.TabIndex = 99;
            this.cmbPriority.Tag = "Priority";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(274, 206);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(300, 206);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // pnlCompletedDate
            // 
            this.pnlCompletedDate.Controls.Add(this.dtpCompletedDate);
            this.pnlCompletedDate.Location = new System.Drawing.Point(8, 178);
            this.pnlCompletedDate.Name = "pnlCompletedDate";
            this.pnlCompletedDate.Size = new System.Drawing.Size(102, 24);
            this.pnlCompletedDate.TabIndex = 108;
            this.pnlCompletedDate.Tag = "DatePickerCom";
            // 
            // dtpCompletedDate
            // 
            this.dtpCompletedDate.Enabled = false;
            this.dtpCompletedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCompletedDate.Location = new System.Drawing.Point(1, 1);
            this.dtpCompletedDate.Name = "dtpCompletedDate";
            this.dtpCompletedDate.Size = new System.Drawing.Size(100, 22);
            this.dtpCompletedDate.TabIndex = 104;
            this.dtpCompletedDate.Tag = "CompletedDate";
            // 
            // pnlScheduledDate
            // 
            this.pnlScheduledDate.Controls.Add(this.dtpScheduledDate);
            this.pnlScheduledDate.Location = new System.Drawing.Point(8, 138);
            this.pnlScheduledDate.Name = "pnlScheduledDate";
            this.pnlScheduledDate.Size = new System.Drawing.Size(102, 24);
            this.pnlScheduledDate.TabIndex = 110;
            this.pnlScheduledDate.Tag = "DatePickerSch";
            // 
            // dtpScheduledDate
            // 
            this.dtpScheduledDate.Enabled = false;
            this.dtpScheduledDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpScheduledDate.Location = new System.Drawing.Point(1, 1);
            this.dtpScheduledDate.Name = "dtpScheduledDate";
            this.dtpScheduledDate.Size = new System.Drawing.Size(100, 22);
            this.dtpScheduledDate.TabIndex = 72;
            this.dtpScheduledDate.Tag = "ScheduledDate";
            // 
            // pnlRequestDate
            // 
            this.pnlRequestDate.Controls.Add(this.dtpRequestDate);
            this.pnlRequestDate.Location = new System.Drawing.Point(8, 98);
            this.pnlRequestDate.Name = "pnlRequestDate";
            this.pnlRequestDate.Size = new System.Drawing.Size(102, 24);
            this.pnlRequestDate.TabIndex = 111;
            this.pnlRequestDate.Tag = "DatePickerReq";
            // 
            // dtpRequestDate
            // 
            this.dtpRequestDate.Enabled = false;
            this.dtpRequestDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRequestDate.Location = new System.Drawing.Point(1, 1);
            this.dtpRequestDate.Name = "dtpRequestDate";
            this.dtpRequestDate.Size = new System.Drawing.Size(100, 22);
            this.dtpRequestDate.TabIndex = 103;
            this.dtpRequestDate.Tag = "RequestDate";
            // 
            // frmWorkRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 270);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlControls);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmWorkRequest";
            this.Tag = "WorkRequest";
            this.Text = "frmWorkRequest";
            this.Load += new System.EventHandler(this.frmWorkRequest_Load);
            this.Shown += new System.EventHandler(this.frmWorkRequest_Shown);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlCompletedDate.ResumeLayout(false);
            this.pnlScheduledDate.ResumeLayout(false);
            this.pnlRequestDate.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblExpectedDuration;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblCompletedDate;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblPriority;
        private System.Windows.Forms.Label lblTechnicians;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblMaintenanceType;
        private System.Windows.Forms.Label lblRequestDate;
        private System.Windows.Forms.Label lblFinalDuration;
        private System.Windows.Forms.TextBox txtRequestID;
        private System.Windows.Forms.Label lblRequestID;
        private System.Windows.Forms.Label lblWorkRequestTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Label lblScheduledDate;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.CheckedListBox clbReports;
        private System.Windows.Forms.CheckedListBox clbTechnicians;
        private System.Windows.Forms.ComboBox cmbMaintenanceType;
        private System.Windows.Forms.ComboBox cmbPriority;
        private System.Windows.Forms.MaskedTextBox mxtFinalDuration;
        private System.Windows.Forms.MaskedTextBox mxtExpectedDuration;
        private System.Windows.Forms.Panel pnlCompletedDate;
        private System.Windows.Forms.Panel pnlScheduledDate;
        private System.Windows.Forms.Panel pnlRequestDate;
        private System.Windows.Forms.DateTimePicker dtpCompletedDate;
        private System.Windows.Forms.DateTimePicker dtpScheduledDate;
        private System.Windows.Forms.DateTimePicker dtpRequestDate;
    }
}