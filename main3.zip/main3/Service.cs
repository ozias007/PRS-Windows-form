﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Service
    {
        public int ServiceID { get; private set; }
        public string Name { get; private set; }
        public string Category { get; private set; }
        public float Price { get; private set; }
        public string Level { get; private set; }
        public string Description { get; private set; }
        public Service(
            int serviceID = 0,
            string name = "",
            string category = "",
            float price = 0,
            string level = "",
            string description = "")
        {
            ServiceID = serviceID;
            Name = name;
            Category = category;
            Price = price;
            Level = level;
            Description = description;
        }
    }
}
