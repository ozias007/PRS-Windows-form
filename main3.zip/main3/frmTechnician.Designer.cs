﻿namespace Main
{
    partial class frmTechnician
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTechnician));
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.lblTechnicianTitle = new System.Windows.Forms.Label();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.pnlDatePicker = new System.Windows.Forms.Panel();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.pnlAddress = new System.Windows.Forms.Panel();
            this.btnAddress = new System.Windows.Forms.Button();
            this.cmbAddressID = new System.Windows.Forms.ComboBox();
            this.lblAddressID = new System.Windows.Forms.Label();
            this.cmbSchedule = new System.Windows.Forms.ComboBox();
            this.lblSchedule = new System.Windows.Forms.Label();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.mxtCompleted = new System.Windows.Forms.MaskedTextBox();
            this.mxtSalary = new System.Windows.Forms.MaskedTextBox();
            this.mxtPhone = new System.Windows.Forms.MaskedTextBox();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblCompletedRequests = new System.Windows.Forms.Label();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.lblEmployeeID = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.cmbSpecialization = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblNotes = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblSpecialization = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblDateOfBirth = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtTechnicianID = new System.Windows.Forms.TextBox();
            this.lblTechnicianID = new System.Windows.Forms.Label();
            this.pnlTitleBar.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.pnlDatePicker.SuspendLayout();
            this.pnlAddress.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblTechnicianTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 14;
            // 
            // lblTechnicianTitle
            // 
            this.lblTechnicianTitle.AutoSize = true;
            this.lblTechnicianTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTechnicianTitle.Location = new System.Drawing.Point(3, 4);
            this.lblTechnicianTitle.Name = "lblTechnicianTitle";
            this.lblTechnicianTitle.Size = new System.Drawing.Size(101, 25);
            this.lblTechnicianTitle.TabIndex = 6;
            this.lblTechnicianTitle.Tag = "";
            this.lblTechnicianTitle.Text = "Technician";
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.Controls.Add(this.pnlDatePicker);
            this.pnlControls.Controls.Add(this.pnlAddress);
            this.pnlControls.Controls.Add(this.cmbAddressID);
            this.pnlControls.Controls.Add(this.lblAddressID);
            this.pnlControls.Controls.Add(this.cmbSchedule);
            this.pnlControls.Controls.Add(this.lblSchedule);
            this.pnlControls.Controls.Add(this.txtNotes);
            this.pnlControls.Controls.Add(this.mxtCompleted);
            this.pnlControls.Controls.Add(this.mxtSalary);
            this.pnlControls.Controls.Add(this.mxtPhone);
            this.pnlControls.Controls.Add(this.cmbCategory);
            this.pnlControls.Controls.Add(this.lblCategory);
            this.pnlControls.Controls.Add(this.lblCompletedRequests);
            this.pnlControls.Controls.Add(this.txtEmployeeID);
            this.pnlControls.Controls.Add(this.lblEmployeeID);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.cmbSpecialization);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.lblNotes);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.lblPhone);
            this.pnlControls.Controls.Add(this.lblSalary);
            this.pnlControls.Controls.Add(this.txtLastName);
            this.pnlControls.Controls.Add(this.lblLastName);
            this.pnlControls.Controls.Add(this.lblSpecialization);
            this.pnlControls.Controls.Add(this.txtEmail);
            this.pnlControls.Controls.Add(this.lblEmail);
            this.pnlControls.Controls.Add(this.lblDateOfBirth);
            this.pnlControls.Controls.Add(this.txtFirstName);
            this.pnlControls.Controls.Add(this.lblFirstName);
            this.pnlControls.Controls.Add(this.txtTechnicianID);
            this.pnlControls.Controls.Add(this.lblTechnicianID);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 235);
            this.pnlControls.TabIndex = 15;
            this.pnlControls.Tag = "Controls";
            // 
            // pnlDatePicker
            // 
            this.pnlDatePicker.Controls.Add(this.dtpDateOfBirth);
            this.pnlDatePicker.Location = new System.Drawing.Point(9, 139);
            this.pnlDatePicker.Name = "pnlDatePicker";
            this.pnlDatePicker.Size = new System.Drawing.Size(102, 24);
            this.pnlDatePicker.TabIndex = 109;
            this.pnlDatePicker.Tag = "DatePickerDOB";
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.Enabled = false;
            this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateOfBirth.Location = new System.Drawing.Point(1, 1);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(100, 22);
            this.dtpDateOfBirth.TabIndex = 72;
            this.dtpDateOfBirth.Tag = "DateOfBirth";
            // 
            // pnlAddress
            // 
            this.pnlAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddress.Controls.Add(this.btnAddress);
            this.pnlAddress.Enabled = false;
            this.pnlAddress.Location = new System.Drawing.Point(221, 19);
            this.pnlAddress.Name = "pnlAddress";
            this.pnlAddress.Size = new System.Drawing.Size(21, 21);
            this.pnlAddress.TabIndex = 108;
            this.pnlAddress.Tag = "Address";
            // 
            // btnAddress
            // 
            this.btnAddress.BackColor = System.Drawing.SystemColors.Control;
            this.btnAddress.BackgroundImage = global::Main.Properties.Resources.add;
            this.btnAddress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddress.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddress.Enabled = false;
            this.btnAddress.FlatAppearance.BorderSize = 0;
            this.btnAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddress.Location = new System.Drawing.Point(2, 2);
            this.btnAddress.Name = "btnAddress";
            this.btnAddress.Size = new System.Drawing.Size(15, 15);
            this.btnAddress.TabIndex = 101;
            this.btnAddress.Tag = "Address";
            this.btnAddress.UseVisualStyleBackColor = false;
            this.btnAddress.Click += new System.EventHandler(this.btnAddress_Click);
            // 
            // cmbAddressID
            // 
            this.cmbAddressID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddressID.Enabled = false;
            this.cmbAddressID.FormattingEnabled = true;
            this.cmbAddressID.Location = new System.Drawing.Point(242, 19);
            this.cmbAddressID.Name = "cmbAddressID";
            this.cmbAddressID.Size = new System.Drawing.Size(79, 21);
            this.cmbAddressID.TabIndex = 107;
            this.cmbAddressID.Tag = "AddressID";
            // 
            // lblAddressID
            // 
            this.lblAddressID.AutoSize = true;
            this.lblAddressID.Enabled = false;
            this.lblAddressID.Location = new System.Drawing.Point(219, 5);
            this.lblAddressID.Name = "lblAddressID";
            this.lblAddressID.Size = new System.Drawing.Size(65, 13);
            this.lblAddressID.TabIndex = 106;
            this.lblAddressID.Tag = "";
            this.lblAddressID.Text = "Address ID:";
            // 
            // cmbSchedule
            // 
            this.cmbSchedule.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSchedule.Enabled = false;
            this.cmbSchedule.FormattingEnabled = true;
            this.cmbSchedule.Items.AddRange(new object[] {
            "Primary",
            "Secondary",
            "Tertiary"});
            this.cmbSchedule.Location = new System.Drawing.Point(221, 139);
            this.cmbSchedule.Name = "cmbSchedule";
            this.cmbSchedule.Size = new System.Drawing.Size(100, 21);
            this.cmbSchedule.TabIndex = 100;
            this.cmbSchedule.Tag = "Schedule";
            // 
            // lblSchedule
            // 
            this.lblSchedule.AutoSize = true;
            this.lblSchedule.Enabled = false;
            this.lblSchedule.Location = new System.Drawing.Point(217, 125);
            this.lblSchedule.Name = "lblSchedule";
            this.lblSchedule.Size = new System.Drawing.Size(57, 13);
            this.lblSchedule.TabIndex = 99;
            this.lblSchedule.Tag = "";
            this.lblSchedule.Text = "Schedule:";
            // 
            // txtNotes
            // 
            this.txtNotes.Enabled = false;
            this.txtNotes.Location = new System.Drawing.Point(9, 179);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(100, 22);
            this.txtNotes.TabIndex = 96;
            this.txtNotes.Tag = "Notes";
            // 
            // mxtCompleted
            // 
            this.mxtCompleted.Enabled = false;
            this.mxtCompleted.Location = new System.Drawing.Point(115, 179);
            this.mxtCompleted.Mask = "0999999999";
            this.mxtCompleted.Name = "mxtCompleted";
            this.mxtCompleted.Size = new System.Drawing.Size(100, 22);
            this.mxtCompleted.TabIndex = 91;
            this.mxtCompleted.Tag = "CompletedRequests";
            // 
            // mxtSalary
            // 
            this.mxtSalary.Enabled = false;
            this.mxtSalary.Location = new System.Drawing.Point(115, 139);
            this.mxtSalary.Mask = "0999999999";
            this.mxtSalary.Name = "mxtSalary";
            this.mxtSalary.Size = new System.Drawing.Size(100, 22);
            this.mxtSalary.TabIndex = 90;
            this.mxtSalary.Tag = "Salary";
            // 
            // mxtPhone
            // 
            this.mxtPhone.Enabled = false;
            this.mxtPhone.Location = new System.Drawing.Point(115, 59);
            this.mxtPhone.Mask = "+0000000000099999";
            this.mxtPhone.Name = "mxtPhone";
            this.mxtPhone.Size = new System.Drawing.Size(100, 22);
            this.mxtPhone.TabIndex = 89;
            this.mxtPhone.Tag = "Phone";
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Enabled = false;
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "Technician"});
            this.cmbCategory.Location = new System.Drawing.Point(221, 179);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(100, 21);
            this.cmbCategory.TabIndex = 81;
            this.cmbCategory.Tag = "Category";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Enabled = false;
            this.lblCategory.Location = new System.Drawing.Point(218, 165);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(56, 13);
            this.lblCategory.TabIndex = 80;
            this.lblCategory.Tag = "";
            this.lblCategory.Text = "Category:";
            // 
            // lblCompletedRequests
            // 
            this.lblCompletedRequests.AutoSize = true;
            this.lblCompletedRequests.Enabled = false;
            this.lblCompletedRequests.Location = new System.Drawing.Point(112, 165);
            this.lblCompletedRequests.Name = "lblCompletedRequests";
            this.lblCompletedRequests.Size = new System.Drawing.Size(66, 13);
            this.lblCompletedRequests.TabIndex = 78;
            this.lblCompletedRequests.Tag = "";
            this.lblCompletedRequests.Text = "Completed:";
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Enabled = false;
            this.txtEmployeeID.Location = new System.Drawing.Point(115, 19);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.Size = new System.Drawing.Size(100, 22);
            this.txtEmployeeID.TabIndex = 77;
            this.txtEmployeeID.Tag = "EmployeeID";
            // 
            // lblEmployeeID
            // 
            this.lblEmployeeID.AutoSize = true;
            this.lblEmployeeID.Enabled = false;
            this.lblEmployeeID.Location = new System.Drawing.Point(112, 5);
            this.lblEmployeeID.Name = "lblEmployeeID";
            this.lblEmployeeID.Size = new System.Drawing.Size(73, 13);
            this.lblEmployeeID.TabIndex = 76;
            this.lblEmployeeID.Tag = "";
            this.lblEmployeeID.Text = "Employee ID:";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Available",
            "Unavailable"});
            this.cmbStatus.Location = new System.Drawing.Point(221, 99);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 74;
            this.cmbStatus.Tag = "Status";
            // 
            // cmbSpecialization
            // 
            this.cmbSpecialization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSpecialization.Enabled = false;
            this.cmbSpecialization.FormattingEnabled = true;
            this.cmbSpecialization.Items.AddRange(new object[] {
            "General",
            "Mechanical",
            "Electrical"});
            this.cmbSpecialization.Location = new System.Drawing.Point(221, 59);
            this.cmbSpecialization.Name = "cmbSpecialization";
            this.cmbSpecialization.Size = new System.Drawing.Size(100, 21);
            this.cmbSpecialization.TabIndex = 73;
            this.cmbSpecialization.Tag = "Specialization";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(274, 206);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(300, 206);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Enabled = false;
            this.lblNotes.Location = new System.Drawing.Point(6, 165);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(40, 13);
            this.lblNotes.TabIndex = 70;
            this.lblNotes.Tag = "";
            this.lblNotes.Text = "Notes:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(217, 85);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 68;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Enabled = false;
            this.lblPhone.Location = new System.Drawing.Point(113, 45);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(43, 13);
            this.lblPhone.TabIndex = 66;
            this.lblPhone.Tag = "";
            this.lblPhone.Text = "Phone:";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Enabled = false;
            this.lblSalary.Location = new System.Drawing.Point(113, 125);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(40, 13);
            this.lblSalary.TabIndex = 64;
            this.lblSalary.Tag = "";
            this.lblSalary.Text = "Salary:";
            // 
            // txtLastName
            // 
            this.txtLastName.Enabled = false;
            this.txtLastName.Location = new System.Drawing.Point(115, 99);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 22);
            this.txtLastName.TabIndex = 63;
            this.txtLastName.Tag = "LastName";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Enabled = false;
            this.lblLastName.Location = new System.Drawing.Point(112, 85);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(62, 13);
            this.lblLastName.TabIndex = 62;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblSpecialization
            // 
            this.lblSpecialization.AutoSize = true;
            this.lblSpecialization.Enabled = false;
            this.lblSpecialization.Location = new System.Drawing.Point(218, 45);
            this.lblSpecialization.Name = "lblSpecialization";
            this.lblSpecialization.Size = new System.Drawing.Size(81, 13);
            this.lblSpecialization.TabIndex = 61;
            this.lblSpecialization.Tag = "";
            this.lblSpecialization.Text = "Specialization:";
            // 
            // txtEmail
            // 
            this.txtEmail.Enabled = false;
            this.txtEmail.Location = new System.Drawing.Point(9, 59);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 22);
            this.txtEmail.TabIndex = 60;
            this.txtEmail.Tag = "Email";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Enabled = false;
            this.lblEmail.Location = new System.Drawing.Point(6, 45);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(37, 13);
            this.lblEmail.TabIndex = 59;
            this.lblEmail.Tag = "";
            this.lblEmail.Text = "Email:";
            // 
            // lblDateOfBirth
            // 
            this.lblDateOfBirth.AutoSize = true;
            this.lblDateOfBirth.Enabled = false;
            this.lblDateOfBirth.Location = new System.Drawing.Point(8, 125);
            this.lblDateOfBirth.Name = "lblDateOfBirth";
            this.lblDateOfBirth.Size = new System.Drawing.Size(33, 13);
            this.lblDateOfBirth.TabIndex = 58;
            this.lblDateOfBirth.Tag = "";
            this.lblDateOfBirth.Text = "DOB:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Enabled = false;
            this.txtFirstName.Location = new System.Drawing.Point(9, 99);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 22);
            this.txtFirstName.TabIndex = 57;
            this.txtFirstName.Tag = "FirstName";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Enabled = false;
            this.lblFirstName.Location = new System.Drawing.Point(6, 85);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(64, 13);
            this.lblFirstName.TabIndex = 56;
            this.lblFirstName.Tag = "";
            this.lblFirstName.Text = "First Name:";
            // 
            // txtTechnicianID
            // 
            this.txtTechnicianID.Enabled = false;
            this.txtTechnicianID.Location = new System.Drawing.Point(9, 19);
            this.txtTechnicianID.Name = "txtTechnicianID";
            this.txtTechnicianID.Size = new System.Drawing.Size(100, 22);
            this.txtTechnicianID.TabIndex = 54;
            this.txtTechnicianID.Tag = "TechnicianID";
            // 
            // lblTechnicianID
            // 
            this.lblTechnicianID.AutoSize = true;
            this.lblTechnicianID.Enabled = false;
            this.lblTechnicianID.Location = new System.Drawing.Point(5, 5);
            this.lblTechnicianID.Name = "lblTechnicianID";
            this.lblTechnicianID.Size = new System.Drawing.Size(78, 13);
            this.lblTechnicianID.TabIndex = 51;
            this.lblTechnicianID.Tag = "";
            this.lblTechnicianID.Text = "Technician ID:";
            // 
            // frmTechnician
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 270);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlTitleBar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "frmTechnician";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Technician";
            this.Load += new System.EventHandler(this.frmTechnician_Load);
            this.Shown += new System.EventHandler(this.frmTechnician_Shown);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlDatePicker.ResumeLayout(false);
            this.pnlAddress.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Label lblTechnicianTitle;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.ComboBox cmbSpecialization;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblSpecialization;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblDateOfBirth;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtTechnicianID;
        private System.Windows.Forms.Label lblTechnicianID;
        private System.Windows.Forms.Label lblCompletedRequests;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label lblEmployeeID;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.MaskedTextBox mxtCompleted;
        private System.Windows.Forms.MaskedTextBox mxtSalary;
        private System.Windows.Forms.MaskedTextBox mxtPhone;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.ComboBox cmbSchedule;
        private System.Windows.Forms.Label lblSchedule;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Panel pnlAddress;
        private System.Windows.Forms.Button btnAddress;
        private System.Windows.Forms.ComboBox cmbAddressID;
        private System.Windows.Forms.Label lblAddressID;
        private System.Windows.Forms.Panel pnlDatePicker;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
    }
}