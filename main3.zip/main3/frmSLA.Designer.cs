﻿namespace Main
{
    partial class frmSLA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSLA));
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.lblSlaTitle = new System.Windows.Forms.Label();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.rtbServicePriority = new System.Windows.Forms.RichTextBox();
            this.rtbMetricProtocol = new System.Windows.Forms.RichTextBox();
            this.lblMetricProtocol = new System.Windows.Forms.Label();
            this.rtbPerformanceTarget = new System.Windows.Forms.RichTextBox();
            this.lblPerformanceTarget = new System.Windows.Forms.Label();
            this.rtbBreachPenalty = new System.Windows.Forms.RichTextBox();
            this.lblBreachPenalty = new System.Windows.Forms.Label();
            this.rtbPartyObligation = new System.Windows.Forms.RichTextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.lblPartyObligation = new System.Windows.Forms.Label();
            this.lblPackages = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.txtSlaID = new System.Windows.Forms.TextBox();
            this.lblSlaID = new System.Windows.Forms.Label();
            this.mxtServicePackageDetails = new System.Windows.Forms.MaskedTextBox();
            this.pnlTitleBar.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblSlaTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 18;
            // 
            // lblSlaTitle
            // 
            this.lblSlaTitle.AutoSize = true;
            this.lblSlaTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSlaTitle.Location = new System.Drawing.Point(3, 4);
            this.lblSlaTitle.Name = "lblSlaTitle";
            this.lblSlaTitle.Size = new System.Drawing.Size(44, 25);
            this.lblSlaTitle.TabIndex = 6;
            this.lblSlaTitle.Tag = "";
            this.lblSlaTitle.Text = "SLA";
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.Controls.Add(this.mxtServicePackageDetails);
            this.pnlControls.Controls.Add(this.label1);
            this.pnlControls.Controls.Add(this.rtbServicePriority);
            this.pnlControls.Controls.Add(this.rtbMetricProtocol);
            this.pnlControls.Controls.Add(this.lblMetricProtocol);
            this.pnlControls.Controls.Add(this.rtbPerformanceTarget);
            this.pnlControls.Controls.Add(this.lblPerformanceTarget);
            this.pnlControls.Controls.Add(this.rtbBreachPenalty);
            this.pnlControls.Controls.Add(this.lblBreachPenalty);
            this.pnlControls.Controls.Add(this.rtbPartyObligation);
            this.pnlControls.Controls.Add(this.lblDescription);
            this.pnlControls.Controls.Add(this.rtbDescription);
            this.pnlControls.Controls.Add(this.lblPartyObligation);
            this.pnlControls.Controls.Add(this.lblPackages);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.txtSlaID);
            this.pnlControls.Controls.Add(this.lblSlaID);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 275);
            this.pnlControls.TabIndex = 19;
            this.pnlControls.Tag = "Controls";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(6, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 165;
            this.label1.Tag = "";
            this.label1.Text = "Priority:";
            // 
            // rtbServicePriority
            // 
            this.rtbServicePriority.Enabled = false;
            this.rtbServicePriority.Location = new System.Drawing.Point(9, 99);
            this.rtbServicePriority.Name = "rtbServicePriority";
            this.rtbServicePriority.Size = new System.Drawing.Size(100, 142);
            this.rtbServicePriority.TabIndex = 164;
            this.rtbServicePriority.Tag = "ServicePriorityDetails";
            this.rtbServicePriority.Text = "";
            // 
            // rtbMetricProtocol
            // 
            this.rtbMetricProtocol.Enabled = false;
            this.rtbMetricProtocol.Location = new System.Drawing.Point(115, 179);
            this.rtbMetricProtocol.Name = "rtbMetricProtocol";
            this.rtbMetricProtocol.Size = new System.Drawing.Size(100, 62);
            this.rtbMetricProtocol.TabIndex = 159;
            this.rtbMetricProtocol.Tag = "MetricProtocolDetails";
            this.rtbMetricProtocol.Text = "";
            // 
            // lblMetricProtocol
            // 
            this.lblMetricProtocol.AutoSize = true;
            this.lblMetricProtocol.Enabled = false;
            this.lblMetricProtocol.Location = new System.Drawing.Point(112, 165);
            this.lblMetricProtocol.Name = "lblMetricProtocol";
            this.lblMetricProtocol.Size = new System.Drawing.Size(69, 13);
            this.lblMetricProtocol.TabIndex = 158;
            this.lblMetricProtocol.Tag = "";
            this.lblMetricProtocol.Text = "M. Protocol:";
            // 
            // rtbPerformanceTarget
            // 
            this.rtbPerformanceTarget.Enabled = false;
            this.rtbPerformanceTarget.Location = new System.Drawing.Point(115, 99);
            this.rtbPerformanceTarget.Name = "rtbPerformanceTarget";
            this.rtbPerformanceTarget.Size = new System.Drawing.Size(100, 62);
            this.rtbPerformanceTarget.TabIndex = 157;
            this.rtbPerformanceTarget.Tag = "TargetPerformanceDetails";
            this.rtbPerformanceTarget.Text = "";
            // 
            // lblPerformanceTarget
            // 
            this.lblPerformanceTarget.AutoSize = true;
            this.lblPerformanceTarget.Enabled = false;
            this.lblPerformanceTarget.Location = new System.Drawing.Point(112, 85);
            this.lblPerformanceTarget.Name = "lblPerformanceTarget";
            this.lblPerformanceTarget.Size = new System.Drawing.Size(59, 13);
            this.lblPerformanceTarget.TabIndex = 156;
            this.lblPerformanceTarget.Tag = "";
            this.lblPerformanceTarget.Text = "P. Targets:";
            // 
            // rtbBreachPenalty
            // 
            this.rtbBreachPenalty.Enabled = false;
            this.rtbBreachPenalty.Location = new System.Drawing.Point(221, 179);
            this.rtbBreachPenalty.Name = "rtbBreachPenalty";
            this.rtbBreachPenalty.Size = new System.Drawing.Size(100, 62);
            this.rtbBreachPenalty.TabIndex = 155;
            this.rtbBreachPenalty.Tag = "BreachPenaltyDetails";
            this.rtbBreachPenalty.Text = "";
            // 
            // lblBreachPenalty
            // 
            this.lblBreachPenalty.AutoSize = true;
            this.lblBreachPenalty.Enabled = false;
            this.lblBreachPenalty.Location = new System.Drawing.Point(218, 165);
            this.lblBreachPenalty.Name = "lblBreachPenalty";
            this.lblBreachPenalty.Size = new System.Drawing.Size(59, 13);
            this.lblBreachPenalty.TabIndex = 154;
            this.lblBreachPenalty.Tag = "";
            this.lblBreachPenalty.Text = "B. Penalty:";
            // 
            // rtbPartyObligation
            // 
            this.rtbPartyObligation.Enabled = false;
            this.rtbPartyObligation.Location = new System.Drawing.Point(221, 99);
            this.rtbPartyObligation.Name = "rtbPartyObligation";
            this.rtbPartyObligation.Size = new System.Drawing.Size(100, 62);
            this.rtbPartyObligation.TabIndex = 153;
            this.rtbPartyObligation.Tag = "PartyObligationDetails";
            this.rtbPartyObligation.Text = "";
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Enabled = false;
            this.lblDescription.Location = new System.Drawing.Point(112, 5);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(69, 13);
            this.lblDescription.TabIndex = 149;
            this.lblDescription.Tag = "";
            this.lblDescription.Text = "Description:";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Enabled = false;
            this.rtbDescription.Location = new System.Drawing.Point(115, 19);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(206, 62);
            this.rtbDescription.TabIndex = 148;
            this.rtbDescription.Tag = "Description";
            this.rtbDescription.Text = "";
            // 
            // lblPartyObligation
            // 
            this.lblPartyObligation.AutoSize = true;
            this.lblPartyObligation.Enabled = false;
            this.lblPartyObligation.Location = new System.Drawing.Point(218, 85);
            this.lblPartyObligation.Name = "lblPartyObligation";
            this.lblPartyObligation.Size = new System.Drawing.Size(83, 13);
            this.lblPartyObligation.TabIndex = 128;
            this.lblPartyObligation.Tag = "";
            this.lblPartyObligation.Text = "P. Obligations:";
            // 
            // lblPackages
            // 
            this.lblPackages.AutoSize = true;
            this.lblPackages.Enabled = false;
            this.lblPackages.Location = new System.Drawing.Point(6, 43);
            this.lblPackages.Name = "lblPackages";
            this.lblPackages.Size = new System.Drawing.Size(57, 13);
            this.lblPackages.TabIndex = 101;
            this.lblPackages.Tag = "";
            this.lblPackages.Text = "Packages:";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(275, 247);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(301, 247);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // txtSlaID
            // 
            this.txtSlaID.Enabled = false;
            this.txtSlaID.Location = new System.Drawing.Point(9, 19);
            this.txtSlaID.Name = "txtSlaID";
            this.txtSlaID.Size = new System.Drawing.Size(100, 22);
            this.txtSlaID.TabIndex = 54;
            this.txtSlaID.Tag = "SlaID";
            // 
            // lblSlaID
            // 
            this.lblSlaID.AutoSize = true;
            this.lblSlaID.Enabled = false;
            this.lblSlaID.Location = new System.Drawing.Point(5, 5);
            this.lblSlaID.Name = "lblSlaID";
            this.lblSlaID.Size = new System.Drawing.Size(42, 13);
            this.lblSlaID.TabIndex = 51;
            this.lblSlaID.Tag = "";
            this.lblSlaID.Text = "SLA ID:";
            // 
            // mxtServicePackageDetails
            // 
            this.mxtServicePackageDetails.Location = new System.Drawing.Point(9, 59);
            this.mxtServicePackageDetails.Mask = "09, 99, 99, 99, 99";
            this.mxtServicePackageDetails.Name = "mxtServicePackageDetails";
            this.mxtServicePackageDetails.Size = new System.Drawing.Size(100, 22);
            this.mxtServicePackageDetails.TabIndex = 166;
            this.mxtServicePackageDetails.Tag = "ServicePackageDetails";
            // 
            // frmSLA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 310);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlControls);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSLA";
            this.Tag = "SLA";
            this.Text = "frmSLA";
            this.Load += new System.EventHandler(this.frmSLA_Load);
            this.Shown += new System.EventHandler(this.frmSLA_Shown);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Label lblSlaTitle;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.TextBox txtSlaID;
        private System.Windows.Forms.Label lblSlaID;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblPackages;
        private System.Windows.Forms.Label lblPartyObligation;
        private System.Windows.Forms.Label lblBreachPenalty;
        private System.Windows.Forms.Label lblMetricProtocol;
        private System.Windows.Forms.Label lblPerformanceTarget;
        private System.Windows.Forms.RichTextBox rtbMetricProtocol;
        private System.Windows.Forms.RichTextBox rtbPerformanceTarget;
        private System.Windows.Forms.RichTextBox rtbBreachPenalty;
        private System.Windows.Forms.RichTextBox rtbPartyObligation;
        private System.Windows.Forms.RichTextBox rtbServicePriority;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mxtServicePackageDetails;
    }
}