﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class IndividualClient : Client
    {
        public int IndividualID { get; private set; }
        public DateTime DateOfBirth { get; private set; }
        public IndividualClient(
            int individualID = 0,
            int clientID = 0,
            int addressID = 0,
            string category = "",
            string firstName = "",
            string lastName = "",
            DateTime registrationDate = default,
            string email = "",
            string phone = "",
            string status = "",
            string notes = "",
            DateTime dateOfBirth = default)
            : base(clientID, addressID, category, firstName, lastName, registrationDate, email, phone, status, notes)
        {
            IndividualID = individualID;
            DateOfBirth = dateOfBirth;
        }
    }
}
