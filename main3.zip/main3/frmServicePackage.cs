﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmServicePackage : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        public frmServicePackage()
        {
            InitializeComponent();
        }

        private void frmServicePackage_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
        }

        private void frmServicePackage_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            uim.SetControlState(frmState.ToLower());
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }
    }
}
