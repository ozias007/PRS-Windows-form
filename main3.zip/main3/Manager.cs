﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Manager : Employee
    {
        public int ManagerID { get; private set; }
        public string Area { get; private set; }
        public Manager(
            int managerID = 0,
            int employeeID = 0,
            int addressID = 0,
            string firstName = "",
            string lastName = "",
            DateTime dateOfBirth = default,
            string email = "",
            string phone = "",
            string category = "",
            string status = "",
            string schedule = "",
            float salary = 0,
            string notes = "",
            string area = "")
            : base(employeeID, addressID, firstName, lastName, dateOfBirth, email, phone, category, status, schedule, salary, notes)
        {
            ManagerID = managerID;
            Area = area;
        }
    }

}
