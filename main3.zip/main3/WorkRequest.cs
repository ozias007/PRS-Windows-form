﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    using System;
    using System.Collections.Generic;
    public class WorkRequest
    {
        public int RequestID { get; private set; }
        public DateTime RequestDate { get; private set; }
        public DateTime ScheduledDate { get; private set; }
        public DateTime? CompletedDate { get; private set; }
        public int ExpectedDuration { get; private set; }
        public int? FinalDuration { get; private set; }
        public string MaintenanceType { get; private set; }
        public string Priority { get; private set; }
        public string Status { get; private set; }
        public WorkRequest(
            int requestID = 0,
            DateTime requestDate = default,
            DateTime scheduledDate = default,
            DateTime? completedDate = null,
            int expectedDuration = 0,
            int? finalDuration = 0,
            string maintenanceType = "",
            string priority = "",
            string status = "")
        {
            RequestID = requestID;
            RequestDate = requestDate;
            ScheduledDate = scheduledDate;
            CompletedDate = completedDate;
            ExpectedDuration = expectedDuration;
            FinalDuration = finalDuration;
            MaintenanceType = maintenanceType;
            Priority = priority;
            Status = status;
        }
    }
}
