﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class WorkRequestAssignedTechnicians
    {
        public int RequestID { get; private set; }
        public int TechnicianID { get; private set; }
        public WorkRequestAssignedTechnicians(int requestID = 0, int technicianID = 0)
        {
            RequestID = requestID;
            TechnicianID = technicianID;
        }
    }
}
