﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Employee
    {
        public int EmployeeID { get; private set; }
        public int AddressID { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public DateTime DateOfBirth { get; private set; }
        public string Email { get; private set; }
        public string Phone { get; private set; }
        public string Category { get; private set; }
        public string Status { get; private set; }
        public string Schedule { get; private set; }
        public float Salary { get; private set; }
        public string Notes { get; private set; }
        public Employee(
            int employeeID = 0,
            int addressID = 0,
            string firstName = "",
            string lastName = "",
            DateTime dateOfBirth = default,
            string email = "",
            string phone = "",
            string category = "",
            string status = "",
            string schedule = "",
            float salary = 0,
            string notes = "")
        {
            EmployeeID = employeeID;
            AddressID = addressID;
            FirstName = firstName;
            LastName = lastName;
            DateOfBirth = dateOfBirth;
            Email = email;
            Phone = phone;
            Category = category;
            Status = status;
            Schedule = schedule;
            Salary = salary;
            Notes = notes;
        }
    }
}
