﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Main
{
    public partial class frmCallCentre : Form
    {
        private int click = 0;
        private string frmState = "";
        private UIManager uim;
        private DataHandler dhl = new DataHandler();
        private List<ListBox> btnLsts = new List<ListBox>();
        private string[] arrCallReport = { "All", "Create" };
        private string[] arrWorkRequest = { "All", "Create" };
        private string[] arrClient = { "All" };
        private string[] arrSLA = { "All" };
        private string[] arrServiceContract = { "All" };
        public frmCallCentre()
        {
            InitializeComponent();
        }

        private void frmCallCentre_Load(object sender, EventArgs e)
        {
            foreach (Control cntrl in pnlButtons.Controls)
            {
                if (cntrl is ListBox lst) { btnLsts.Add(lst); }
            }
            uim = new UIManager(this, pnlTitleBar, picExit, pnlButtons, btnLsts, dgvCallCentre, cmbSearch, txtSearch);
            uim.dgvTemplate(dgvCallCentre);
            dhl.LoadCallReportData(dgvCallCentre);
            UIManager.dgvState = "CallReport";
            ActiveControl = picTitleIcon;
            uim.RegisterControlEvents();
        }
        private void picExit_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmHome");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            uim.Search(txtSearch.Text, cmbSearch.Text);
        }

        private void btnCallReport_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnCallReport, pnlButtons);
            uim.SetListState(lstCallReport, arrCallReport, btnCallReport);
        }

        private void btnWorkRequest_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnWorkRequest, pnlButtons);
            uim.SetListState(lstWorkRequest, arrWorkRequest, btnWorkRequest);
        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnClient, pnlButtons);
            uim.SetListState(lstClient, arrClient, btnClient);
        }

        private void btnSLA_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnSLA, pnlButtons);
            uim.SetListState(lstSLA, arrSLA, btnSLA);
        }

        private void btnServiceContract_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnServiceContract, pnlButtons);
            uim.SetListState(lstServiceContract, arrServiceContract, btnServiceContract);
        }

        private void btnAnswer_Click(object sender, EventArgs e)
        {
            uim.ShowForm("Main.frmPopup");
        }
    }
}
