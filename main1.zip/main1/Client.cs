﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Client
    {
        public int ClientID { get; private set; }
        public int AddressID { get; private set; }
        public string Category { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public DateTime RegistrationDate { get; private set; }
        public string Email { get; private set; }
        public string Phone { get; private set; }
        public string Status { get; private set; }
        public string Notes { get; private set; }
        public Client(
            int clientID = 0,
            int addressID = 0,
            string category = "",
            string firstName = "",
            string lastName = "",
            DateTime registrationDate = default,
            string email = "",
            string phone = "",
            string status = "",
            string notes = "")
        {
            ClientID = clientID;
            AddressID = addressID;
            Category = category;
            FirstName = firstName;
            LastName = lastName;
            RegistrationDate = registrationDate;
            Email = email;
            Phone = phone;
            Status = status;
            Notes = notes;
        }
    }
}
