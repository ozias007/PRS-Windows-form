﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmCallReport : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Client> clients = new List<Client>();
        public frmCallReport()
        {
            InitializeComponent();
        }

        private void frmCallReport_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
        }

        private void frmCallReport_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            clients = dlh.GetClients();
            uim.AddListToCmb(clients, cmbClientID, client => client.ClientID.ToString());
            uim.SetControlState(frmState.ToLower());
            if (frmState.ToLower() == "create") 
            {
                uim.ClearControls(this);
                cmbStatus.Enabled = false;
                txtStartTime.Enabled = false;
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                CallReport report = new CallReport(
                    0, int.Parse(cmbClientID.Text), 
                    rtbDetails.Text, 
                    cmbStatus.Text, 
                    dtpReportDate.Value.Date, 
                    TimeSpan.Parse(txtStartTime.Text), 
                    TimeSpan.Parse(mxtEndTime.Text));
                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateCallReport(report);
                    uim.ClearControls(this);
                    MessageBox.Show("Report created.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }
    }
}
