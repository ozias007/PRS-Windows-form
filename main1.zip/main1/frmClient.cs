﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmClient : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        public static ComboBox cmbA;
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Address> addresses = new List<Address>();
        private List<ServiceContract> contracts = new List<ServiceContract>();
        private List<ClientContracts> clientContracts = new List<ClientContracts>();
        public frmClient()
        {
            InitializeComponent();
        }

        private void frmClient_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
            cmbA = cmbAddressID;
        }

        private void frmClient_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            addresses = dlh.GetAddresses();
            contracts = dlh.GetServiceContracts();
            clientContracts = dlh.GetClientContracts();
            uim.AddListToCmb(addresses, cmbAddressID, address => address.AddressID.ToString());
            uim.AddContractIDs(contracts, clbClientContracts, txtClientID.Text, clientContracts);
            uim.SetControlState(frmState.ToLower());
            uim.CheckedState(frmState.ToLower());
            cmbCategory.SelectedIndex = 1;
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                Client client = new Client();
                switch(cmbCategory.Text.ToLower())
                {
                    case "business":
                        client = new BusinessClient(
                            0, 0, int.Parse(cmbAddressID.Text),
                            cmbCategory.Text, txtFirstName.Text,
                            txtLastName.Text, dtpRegistrationDate.Value.Date,
                            txtEmail.Text, mxtPhone.Text, cmbStatus.Text,
                            txtNotes.Text, txtBusinessName.Text, txtContactTitle.Text);
                        break;
                    case "individual":
                        client = new IndividualClient(
                            0, 0, int.Parse(cmbAddressID.Text),
                            cmbCategory.Text, txtFirstName.Text,
                            txtLastName.Text, dtpRegistrationDate.Value.Date,
                            txtEmail.Text, mxtPhone.Text, cmbStatus.Text,
                            txtNotes.Text, dtpDateOfBirth.Value.Date);
                        break;
                }
                dlh.CreateClient(client);
                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateClient(client);
                    uim.ClearControls(this);
                    MessageBox.Show("Client created.");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }

        private void btnAddress_Click(object sender, EventArgs e)
        {
            frmAddress.frmState = frmState.ToLower();
            frmAddress.frmSender = "client";
            uim.SelectedOption("address");
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(frmState.ToLower())
            {
                case "create":
                    switch (cmbCategory.SelectedItem.ToString().ToLower())
                    {
                        case "business":
                            dtpDateOfBirth.Checked = false;
                            dtpDateOfBirth.Enabled = false;
                            txtBusinessName.Enabled = true;
                            txtContactTitle.Enabled = true;
                            break;
                        case "individual":
                            txtBusinessName.Clear();
                            txtBusinessName.Enabled = false;
                            txtContactTitle.Clear();
                            txtContactTitle.Enabled = false;
                            dtpDateOfBirth.Checked = true;
                            dtpDateOfBirth.Enabled = true;
                            break;
                    }
                    break;
            }
        }
    }
}
