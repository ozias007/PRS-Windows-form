﻿namespace Main
{
    partial class frmCallReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCallReport));
            this.pnlControls = new System.Windows.Forms.Panel();
            this.txtStartTime = new System.Windows.Forms.TextBox();
            this.rtbDetails = new System.Windows.Forms.RichTextBox();
            this.mxtEndTime = new System.Windows.Forms.MaskedTextBox();
            this.cmbClientID = new System.Windows.Forms.ComboBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblClientID = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblReportDate = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.txtReportID = new System.Windows.Forms.TextBox();
            this.lblReportID = new System.Windows.Forms.Label();
            this.pnlDatePicker = new System.Windows.Forms.Panel();
            this.dtpReportDate = new System.Windows.Forms.DateTimePicker();
            this.lblCallReportTitle = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.pnlControls.SuspendLayout();
            this.pnlDatePicker.SuspendLayout();
            this.pnlTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.txtStartTime);
            this.pnlControls.Controls.Add(this.rtbDetails);
            this.pnlControls.Controls.Add(this.mxtEndTime);
            this.pnlControls.Controls.Add(this.cmbClientID);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.lblClientID);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.lblStartTime);
            this.pnlControls.Controls.Add(this.lblEndTime);
            this.pnlControls.Controls.Add(this.lblReportDate);
            this.pnlControls.Controls.Add(this.lblDetails);
            this.pnlControls.Controls.Add(this.txtReportID);
            this.pnlControls.Controls.Add(this.lblReportID);
            this.pnlControls.Controls.Add(this.pnlDatePicker);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 235);
            this.pnlControls.TabIndex = 19;
            this.pnlControls.Tag = "Controls";
            // 
            // txtStartTime
            // 
            this.txtStartTime.Enabled = false;
            this.txtStartTime.Location = new System.Drawing.Point(115, 59);
            this.txtStartTime.Name = "txtStartTime";
            this.txtStartTime.ReadOnly = true;
            this.txtStartTime.Size = new System.Drawing.Size(100, 22);
            this.txtStartTime.TabIndex = 116;
            this.txtStartTime.Tag = "StartTime";
            this.txtStartTime.Text = "00:00:00";
            // 
            // rtbDetails
            // 
            this.rtbDetails.Enabled = false;
            this.rtbDetails.Location = new System.Drawing.Point(9, 99);
            this.rtbDetails.Name = "rtbDetails";
            this.rtbDetails.Size = new System.Drawing.Size(312, 96);
            this.rtbDetails.TabIndex = 115;
            this.rtbDetails.Tag = "Details";
            this.rtbDetails.Text = "";
            // 
            // mxtEndTime
            // 
            this.mxtEndTime.Enabled = false;
            this.mxtEndTime.Location = new System.Drawing.Point(221, 59);
            this.mxtEndTime.Mask = "00:00:00";
            this.mxtEndTime.Name = "mxtEndTime";
            this.mxtEndTime.Size = new System.Drawing.Size(100, 22);
            this.mxtEndTime.TabIndex = 114;
            this.mxtEndTime.Tag = "EndTime";
            // 
            // cmbClientID
            // 
            this.cmbClientID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClientID.Enabled = false;
            this.cmbClientID.FormattingEnabled = true;
            this.cmbClientID.Location = new System.Drawing.Point(115, 19);
            this.cmbClientID.Name = "cmbClientID";
            this.cmbClientID.Size = new System.Drawing.Size(100, 21);
            this.cmbClientID.TabIndex = 112;
            this.cmbClientID.Tag = "ClientID";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Open",
            "In-progress",
            "Closed"});
            this.cmbStatus.Location = new System.Drawing.Point(221, 19);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 111;
            this.cmbStatus.Tag = "Status";
            // 
            // lblClientID
            // 
            this.lblClientID.AutoSize = true;
            this.lblClientID.Enabled = false;
            this.lblClientID.Location = new System.Drawing.Point(113, 5);
            this.lblClientID.Name = "lblClientID";
            this.lblClientID.Size = new System.Drawing.Size(54, 13);
            this.lblClientID.TabIndex = 110;
            this.lblClientID.Tag = "";
            this.lblClientID.Text = "Client ID:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(218, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 109;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(274, 206);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(300, 206);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblStartTime
            // 
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.Enabled = false;
            this.lblStartTime.Location = new System.Drawing.Point(113, 45);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(61, 13);
            this.lblStartTime.TabIndex = 66;
            this.lblStartTime.Tag = "";
            this.lblStartTime.Text = "Start Time:";
            // 
            // lblEndTime
            // 
            this.lblEndTime.AutoSize = true;
            this.lblEndTime.Enabled = false;
            this.lblEndTime.Location = new System.Drawing.Point(218, 45);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(57, 13);
            this.lblEndTime.TabIndex = 61;
            this.lblEndTime.Tag = "";
            this.lblEndTime.Text = "End Time:";
            // 
            // lblReportDate
            // 
            this.lblReportDate.AutoSize = true;
            this.lblReportDate.Enabled = false;
            this.lblReportDate.Location = new System.Drawing.Point(6, 45);
            this.lblReportDate.Name = "lblReportDate";
            this.lblReportDate.Size = new System.Drawing.Size(34, 13);
            this.lblReportDate.TabIndex = 59;
            this.lblReportDate.Tag = "";
            this.lblReportDate.Text = "Date:";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Enabled = false;
            this.lblDetails.Location = new System.Drawing.Point(6, 86);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(45, 13);
            this.lblDetails.TabIndex = 56;
            this.lblDetails.Tag = "";
            this.lblDetails.Text = "Details:";
            // 
            // txtReportID
            // 
            this.txtReportID.Enabled = false;
            this.txtReportID.Location = new System.Drawing.Point(9, 19);
            this.txtReportID.Name = "txtReportID";
            this.txtReportID.Size = new System.Drawing.Size(100, 22);
            this.txtReportID.TabIndex = 54;
            this.txtReportID.Tag = "ReportID";
            // 
            // lblReportID
            // 
            this.lblReportID.AutoSize = true;
            this.lblReportID.Enabled = false;
            this.lblReportID.Location = new System.Drawing.Point(5, 5);
            this.lblReportID.Name = "lblReportID";
            this.lblReportID.Size = new System.Drawing.Size(59, 13);
            this.lblReportID.TabIndex = 51;
            this.lblReportID.Tag = "";
            this.lblReportID.Text = "Report ID:";
            // 
            // pnlDatePicker
            // 
            this.pnlDatePicker.Controls.Add(this.dtpReportDate);
            this.pnlDatePicker.Location = new System.Drawing.Point(9, 59);
            this.pnlDatePicker.Name = "pnlDatePicker";
            this.pnlDatePicker.Size = new System.Drawing.Size(102, 24);
            this.pnlDatePicker.TabIndex = 119;
            this.pnlDatePicker.Tag = "DatePickerNOW";
            // 
            // dtpReportDate
            // 
            this.dtpReportDate.Enabled = false;
            this.dtpReportDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReportDate.Location = new System.Drawing.Point(1, 1);
            this.dtpReportDate.Name = "dtpReportDate";
            this.dtpReportDate.Size = new System.Drawing.Size(100, 22);
            this.dtpReportDate.TabIndex = 111;
            this.dtpReportDate.Tag = "ReportDate";
            this.dtpReportDate.Value = new System.DateTime(2023, 8, 16, 0, 0, 0, 0);
            // 
            // lblCallReportTitle
            // 
            this.lblCallReportTitle.AutoSize = true;
            this.lblCallReportTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCallReportTitle.Location = new System.Drawing.Point(3, 4);
            this.lblCallReportTitle.Name = "lblCallReportTitle";
            this.lblCallReportTitle.Size = new System.Drawing.Size(70, 25);
            this.lblCallReportTitle.TabIndex = 6;
            this.lblCallReportTitle.Tag = "";
            this.lblCallReportTitle.Text = "Report";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblCallReportTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 18;
            // 
            // frmCallReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 270);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlTitleBar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCallReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Tag = "CallReport";
            this.Text = "frmCallReport";
            this.Load += new System.EventHandler(this.frmCallReport_Load);
            this.Shown += new System.EventHandler(this.frmCallReport_Shown);
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlDatePicker.ResumeLayout(false);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblReportDate;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.TextBox txtReportID;
        private System.Windows.Forms.Label lblReportID;
        private System.Windows.Forms.Label lblCallReportTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label lblClientID;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.RichTextBox rtbDetails;
        private System.Windows.Forms.MaskedTextBox mxtEndTime;
        private System.Windows.Forms.ComboBox cmbClientID;
        private System.Windows.Forms.TextBox txtStartTime;
        private System.Windows.Forms.Panel pnlDatePicker;
        private System.Windows.Forms.DateTimePicker dtpReportDate;
    }
}