﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Twilio.Rest.Messaging.V1.Service;
using Twilio.TwiML.Voice;

namespace Main
{
    public partial class frmAddress : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        public static string frmSender = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Address> addresses = new List<Address>();
        public frmAddress()
        {
            InitializeComponent();
        }

        private void frmAddress_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
        }

        private void frmAddress_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            uim.SetControlState(frmState.ToLower());
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
            }
            if (frmState.ToLower() == "view")
            {
                Address address = new Address();
                int i = 0;
                addresses = dlh.GetAddresses();
                switch(frmSender)
                {
                    case "technician":
                        foreach (var item in addresses)
                        {
                            if (item.AddressID.ToString() == frmTechnician.cmbA.Text)
                            {
                                address = addresses[i];
                                break;
                            }
                            i++;
                        }
                        break;
                    case "client":
                        foreach (var item in addresses)
                        {
                            if (item.AddressID.ToString() == frmClient.cmbA.Text)
                            {
                                address = addresses[i];
                                break;
                            }
                            i++;
                        }
                        break;
                }
                txtAddressLine1.Text = address.AddressLine1;
                txtAddressLine2.Text = address.AddressLine2;
                cmbCountry.SelectedItem = address.Country;
                cmbProvince.SelectedItem = address.Province;
                txtCity.Text = address.City;
                mxtPostalCode.Text = address.PostalCode;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                Address address = new Address(
                    0, txtAddressLine1.Text, 
                    txtAddressLine2.Text, 
                    cmbCountry.Text, 
                    mxtPostalCode.Text, 
                    txtCity.Text, 
                    cmbProvince.Text);
                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    int id = dlh.CreateAddress(address);
                    switch (frmSender.ToLower())
                    {
                        case "technician":
                            uim.AddItemToCmb(id.ToString(), frmTechnician.cmbA, true);
                            break;
                        case "client":
                            uim.AddItemToCmb(id.ToString(), frmClient.cmbA, true);
                            break;
                    }
                    uim.ClearControls(this);
                    MessageBox.Show("Address created.");
                    frmCount = 0;
                    Hide();
                }

            }
        }
    }
}
