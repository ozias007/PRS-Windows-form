﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Address
    {
        public int AddressID { get; private set; }
        public string AddressLine1 { get; private set; }
        public string AddressLine2 { get; private set; }
        public string Country { get; private set; }
        public string PostalCode { get; private set; }
        public string City { get; private set; }
        public string Province { get; private set; }
        public Address(
            int addressID = 0,
            string addressLine1 = "",
            string addressLine2 = "",
            string country = "",
            string postalCode = "",
            string city = "",
            string province = "")
        {
            AddressID = addressID;
            AddressLine1 = addressLine1;
            AddressLine2 = addressLine2;
            Country = country;
            PostalCode = postalCode;
            City = city;
            Province = province;
        }
    }
}
