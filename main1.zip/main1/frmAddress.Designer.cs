﻿namespace Main
{
    partial class frmAddress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddress));
            this.pnlControls = new System.Windows.Forms.Panel();
            this.mxtPostalCode = new System.Windows.Forms.MaskedTextBox();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.cmbProvince = new System.Windows.Forms.ComboBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.cmbCountry = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblProvince = new System.Windows.Forms.Label();
            this.txtAddressLine2 = new System.Windows.Forms.TextBox();
            this.lblAddressLine2 = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.txtAddressLine1 = new System.Windows.Forms.TextBox();
            this.lblAddressLine1 = new System.Windows.Forms.Label();
            this.lblAddressTitle = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.pnlControls.SuspendLayout();
            this.pnlTitleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.mxtPostalCode);
            this.pnlControls.Controls.Add(this.lblPostalCode);
            this.pnlControls.Controls.Add(this.cmbProvince);
            this.pnlControls.Controls.Add(this.lblCity);
            this.pnlControls.Controls.Add(this.txtCity);
            this.pnlControls.Controls.Add(this.cmbCountry);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnAdd);
            this.pnlControls.Controls.Add(this.lblProvince);
            this.pnlControls.Controls.Add(this.txtAddressLine2);
            this.pnlControls.Controls.Add(this.lblAddressLine2);
            this.pnlControls.Controls.Add(this.lblCountry);
            this.pnlControls.Controls.Add(this.txtAddressLine1);
            this.pnlControls.Controls.Add(this.lblAddressLine1);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(225, 195);
            this.pnlControls.TabIndex = 17;
            this.pnlControls.Tag = "Controls";
            // 
            // mxtPostalCode
            // 
            this.mxtPostalCode.Enabled = false;
            this.mxtPostalCode.Location = new System.Drawing.Point(117, 139);
            this.mxtPostalCode.Mask = "0000999999";
            this.mxtPostalCode.Name = "mxtPostalCode";
            this.mxtPostalCode.Size = new System.Drawing.Size(100, 22);
            this.mxtPostalCode.TabIndex = 147;
            this.mxtPostalCode.Tag = "PostalCode";
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Enabled = false;
            this.lblPostalCode.Location = new System.Drawing.Point(114, 125);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(71, 13);
            this.lblPostalCode.TabIndex = 146;
            this.lblPostalCode.Text = "Postal Code:";
            // 
            // cmbProvince
            // 
            this.cmbProvince.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProvince.Enabled = false;
            this.cmbProvince.FormattingEnabled = true;
            this.cmbProvince.Items.AddRange(new object[] {
            "Eastern Cape",
            "Free State",
            "Gauteng",
            "KwaZulu-Natal",
            "Limpopo",
            "Mpumalanga",
            "Northern Cape",
            "North West",
            "Western Cape"});
            this.cmbProvince.Location = new System.Drawing.Point(117, 99);
            this.cmbProvince.Name = "cmbProvince";
            this.cmbProvince.Size = new System.Drawing.Size(100, 21);
            this.cmbProvince.TabIndex = 145;
            this.cmbProvince.Tag = "Province";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Enabled = false;
            this.lblCity.Location = new System.Drawing.Point(6, 125);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(29, 13);
            this.lblCity.TabIndex = 144;
            this.lblCity.Tag = "";
            this.lblCity.Text = "City:";
            // 
            // txtCity
            // 
            this.txtCity.Enabled = false;
            this.txtCity.Location = new System.Drawing.Point(9, 139);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 22);
            this.txtCity.TabIndex = 143;
            this.txtCity.Tag = "City";
            // 
            // cmbCountry
            // 
            this.cmbCountry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCountry.Enabled = false;
            this.cmbCountry.FormattingEnabled = true;
            this.cmbCountry.Items.AddRange(new object[] {
            "South Africa"});
            this.cmbCountry.Location = new System.Drawing.Point(9, 99);
            this.cmbCountry.Name = "cmbCountry";
            this.cmbCountry.Size = new System.Drawing.Size(100, 21);
            this.cmbCountry.TabIndex = 141;
            this.cmbCountry.Tag = "Country";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(170, 168);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 129;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.BackgroundImage")));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Location = new System.Drawing.Point(196, 168);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(20, 20);
            this.btnAdd.TabIndex = 128;
            this.btnAdd.Tag = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Enabled = false;
            this.lblProvince.Location = new System.Drawing.Point(115, 85);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(53, 13);
            this.lblProvince.TabIndex = 138;
            this.lblProvince.Tag = "";
            this.lblProvince.Text = "Province:";
            // 
            // txtAddressLine2
            // 
            this.txtAddressLine2.Enabled = false;
            this.txtAddressLine2.Location = new System.Drawing.Point(9, 59);
            this.txtAddressLine2.Name = "txtAddressLine2";
            this.txtAddressLine2.Size = new System.Drawing.Size(208, 22);
            this.txtAddressLine2.TabIndex = 135;
            this.txtAddressLine2.Tag = "AddressLine2";
            // 
            // lblAddressLine2
            // 
            this.lblAddressLine2.AutoSize = true;
            this.lblAddressLine2.Enabled = false;
            this.lblAddressLine2.Location = new System.Drawing.Point(6, 45);
            this.lblAddressLine2.Name = "lblAddressLine2";
            this.lblAddressLine2.Size = new System.Drawing.Size(84, 13);
            this.lblAddressLine2.TabIndex = 134;
            this.lblAddressLine2.Tag = "";
            this.lblAddressLine2.Text = "Address Line 2:";
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Enabled = false;
            this.lblCountry.Location = new System.Drawing.Point(6, 85);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(51, 13);
            this.lblCountry.TabIndex = 131;
            this.lblCountry.Tag = "";
            this.lblCountry.Text = "Country:";
            // 
            // txtAddressLine1
            // 
            this.txtAddressLine1.Enabled = false;
            this.txtAddressLine1.Location = new System.Drawing.Point(9, 19);
            this.txtAddressLine1.Name = "txtAddressLine1";
            this.txtAddressLine1.Size = new System.Drawing.Size(208, 22);
            this.txtAddressLine1.TabIndex = 130;
            this.txtAddressLine1.Tag = "AddressLine1";
            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.Enabled = false;
            this.lblAddressLine1.Location = new System.Drawing.Point(5, 5);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.Size = new System.Drawing.Size(84, 13);
            this.lblAddressLine1.TabIndex = 127;
            this.lblAddressLine1.Tag = "";
            this.lblAddressLine1.Text = "Address Line 1:";
            // 
            // lblAddressTitle
            // 
            this.lblAddressTitle.AutoSize = true;
            this.lblAddressTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddressTitle.Location = new System.Drawing.Point(3, 4);
            this.lblAddressTitle.Name = "lblAddressTitle";
            this.lblAddressTitle.Size = new System.Drawing.Size(80, 25);
            this.lblAddressTitle.TabIndex = 6;
            this.lblAddressTitle.Tag = "";
            this.lblAddressTitle.Text = "Address";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblAddressTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(225, 35);
            this.pnlTitleBar.TabIndex = 16;
            // 
            // frmAddress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(225, 230);
            this.Controls.Add(this.pnlControls);
            this.Controls.Add(this.pnlTitleBar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAddress";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmAddress";
            this.Load += new System.EventHandler(this.frmAddress_Load);
            this.Shown += new System.EventHandler(this.frmAddress_Shown);
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.Label lblAddressTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtAddressLine2;
        private System.Windows.Forms.Label lblAddressLine2;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.TextBox txtAddressLine1;
        private System.Windows.Forms.Label lblAddressLine1;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.MaskedTextBox mxtPostalCode;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.ComboBox cmbProvince;
        private System.Windows.Forms.ComboBox cmbCountry;
    }
}