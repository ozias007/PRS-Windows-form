﻿namespace Main
{
    partial class frmCallCentre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCallCentre));
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.lstCallReport = new System.Windows.Forms.ListBox();
            this.picCallReport = new System.Windows.Forms.PictureBox();
            this.btnCallReport = new System.Windows.Forms.Button();
            this.lstWorkRequest = new System.Windows.Forms.ListBox();
            this.picWorkRequest = new System.Windows.Forms.PictureBox();
            this.btnWorkRequest = new System.Windows.Forms.Button();
            this.lstClient = new System.Windows.Forms.ListBox();
            this.picClient = new System.Windows.Forms.PictureBox();
            this.btnClient = new System.Windows.Forms.Button();
            this.lstSLA = new System.Windows.Forms.ListBox();
            this.picSLA = new System.Windows.Forms.PictureBox();
            this.btnSLA = new System.Windows.Forms.Button();
            this.lstServiceContract = new System.Windows.Forms.ListBox();
            this.picServiceContract = new System.Windows.Forms.PictureBox();
            this.btnServiceContract = new System.Windows.Forms.Button();
            this.picAnswer = new System.Windows.Forms.PictureBox();
            this.btnAnswer = new System.Windows.Forms.Button();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.picTitleIcon = new System.Windows.Forms.PictureBox();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.dgvCallCentre = new System.Windows.Forms.DataGridView();
            this.lblSearch = new System.Windows.Forms.Label();
            this.cmbSearch = new System.Windows.Forms.ComboBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.pnlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCallReport)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWorkRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceContract)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAnswer)).BeginInit();
            this.pnlTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCallCentre)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.lstCallReport);
            this.pnlButtons.Controls.Add(this.picCallReport);
            this.pnlButtons.Controls.Add(this.btnCallReport);
            this.pnlButtons.Controls.Add(this.lstWorkRequest);
            this.pnlButtons.Controls.Add(this.picWorkRequest);
            this.pnlButtons.Controls.Add(this.btnWorkRequest);
            this.pnlButtons.Controls.Add(this.lstClient);
            this.pnlButtons.Controls.Add(this.picClient);
            this.pnlButtons.Controls.Add(this.btnClient);
            this.pnlButtons.Controls.Add(this.lstSLA);
            this.pnlButtons.Controls.Add(this.picSLA);
            this.pnlButtons.Controls.Add(this.btnSLA);
            this.pnlButtons.Controls.Add(this.lstServiceContract);
            this.pnlButtons.Controls.Add(this.picServiceContract);
            this.pnlButtons.Controls.Add(this.btnServiceContract);
            this.pnlButtons.Controls.Add(this.picAnswer);
            this.pnlButtons.Controls.Add(this.btnAnswer);
            this.pnlButtons.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButtons.Location = new System.Drawing.Point(0, 49);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(142, 551);
            this.pnlButtons.TabIndex = 56;
            // 
            // lstCallReport
            // 
            this.lstCallReport.FormattingEnabled = true;
            this.lstCallReport.ItemHeight = 15;
            this.lstCallReport.Location = new System.Drawing.Point(78, 11);
            this.lstCallReport.Name = "lstCallReport";
            this.lstCallReport.Size = new System.Drawing.Size(22, 4);
            this.lstCallReport.TabIndex = 116;
            this.lstCallReport.Tag = "CallReport";
            this.lstCallReport.Visible = false;
            // 
            // picCallReport
            // 
            this.picCallReport.BackColor = System.Drawing.Color.White;
            this.picCallReport.BackgroundImage = global::Main.Properties.Resources.report;
            this.picCallReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCallReport.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picCallReport.Enabled = false;
            this.picCallReport.Location = new System.Drawing.Point(106, 11);
            this.picCallReport.Name = "picCallReport";
            this.picCallReport.Size = new System.Drawing.Size(22, 22);
            this.picCallReport.TabIndex = 118;
            this.picCallReport.TabStop = false;
            this.picCallReport.Tag = "CallReport";
            // 
            // btnCallReport
            // 
            this.btnCallReport.BackColor = System.Drawing.Color.White;
            this.btnCallReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCallReport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnCallReport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnCallReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCallReport.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallReport.ForeColor = System.Drawing.Color.Black;
            this.btnCallReport.Location = new System.Drawing.Point(4, 5);
            this.btnCallReport.Name = "btnCallReport";
            this.btnCallReport.Size = new System.Drawing.Size(132, 35);
            this.btnCallReport.TabIndex = 117;
            this.btnCallReport.Tag = "CallReport";
            this.btnCallReport.Text = "Report";
            this.btnCallReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCallReport.UseVisualStyleBackColor = false;
            this.btnCallReport.Click += new System.EventHandler(this.btnCallReport_Click);
            // 
            // lstWorkRequest
            // 
            this.lstWorkRequest.FormattingEnabled = true;
            this.lstWorkRequest.ItemHeight = 15;
            this.lstWorkRequest.Location = new System.Drawing.Point(78, 51);
            this.lstWorkRequest.Name = "lstWorkRequest";
            this.lstWorkRequest.Size = new System.Drawing.Size(22, 4);
            this.lstWorkRequest.TabIndex = 115;
            this.lstWorkRequest.Tag = "WorkRequest";
            this.lstWorkRequest.Visible = false;
            // 
            // picWorkRequest
            // 
            this.picWorkRequest.BackColor = System.Drawing.Color.White;
            this.picWorkRequest.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picWorkRequest.BackgroundImage")));
            this.picWorkRequest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picWorkRequest.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picWorkRequest.Enabled = false;
            this.picWorkRequest.Location = new System.Drawing.Point(106, 51);
            this.picWorkRequest.Name = "picWorkRequest";
            this.picWorkRequest.Size = new System.Drawing.Size(22, 22);
            this.picWorkRequest.TabIndex = 114;
            this.picWorkRequest.TabStop = false;
            this.picWorkRequest.Tag = "WorkRequest";
            // 
            // btnWorkRequest
            // 
            this.btnWorkRequest.BackColor = System.Drawing.Color.White;
            this.btnWorkRequest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnWorkRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWorkRequest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnWorkRequest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnWorkRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWorkRequest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkRequest.ForeColor = System.Drawing.Color.Black;
            this.btnWorkRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnWorkRequest.Location = new System.Drawing.Point(4, 45);
            this.btnWorkRequest.Name = "btnWorkRequest";
            this.btnWorkRequest.Size = new System.Drawing.Size(132, 35);
            this.btnWorkRequest.TabIndex = 113;
            this.btnWorkRequest.Tag = "WorkRequest";
            this.btnWorkRequest.Text = "Request";
            this.btnWorkRequest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWorkRequest.UseVisualStyleBackColor = false;
            this.btnWorkRequest.Click += new System.EventHandler(this.btnWorkRequest_Click);
            // 
            // lstClient
            // 
            this.lstClient.FormattingEnabled = true;
            this.lstClient.ItemHeight = 15;
            this.lstClient.Location = new System.Drawing.Point(78, 92);
            this.lstClient.Name = "lstClient";
            this.lstClient.Size = new System.Drawing.Size(22, 4);
            this.lstClient.TabIndex = 112;
            this.lstClient.Tag = "Client";
            this.lstClient.Visible = false;
            // 
            // picClient
            // 
            this.picClient.BackColor = System.Drawing.Color.White;
            this.picClient.BackgroundImage = global::Main.Properties.Resources.clients;
            this.picClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClient.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picClient.Enabled = false;
            this.picClient.Location = new System.Drawing.Point(106, 92);
            this.picClient.Name = "picClient";
            this.picClient.Size = new System.Drawing.Size(22, 22);
            this.picClient.TabIndex = 111;
            this.picClient.TabStop = false;
            this.picClient.Tag = "Client";
            // 
            // btnClient
            // 
            this.btnClient.BackColor = System.Drawing.Color.White;
            this.btnClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnClient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClient.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClient.ForeColor = System.Drawing.Color.Black;
            this.btnClient.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClient.Location = new System.Drawing.Point(4, 86);
            this.btnClient.Name = "btnClient";
            this.btnClient.Size = new System.Drawing.Size(132, 35);
            this.btnClient.TabIndex = 110;
            this.btnClient.Tag = "Client";
            this.btnClient.Text = "Client";
            this.btnClient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClient.UseVisualStyleBackColor = false;
            this.btnClient.Click += new System.EventHandler(this.btnClient_Click);
            // 
            // lstSLA
            // 
            this.lstSLA.FormattingEnabled = true;
            this.lstSLA.ItemHeight = 15;
            this.lstSLA.Location = new System.Drawing.Point(78, 133);
            this.lstSLA.Name = "lstSLA";
            this.lstSLA.Size = new System.Drawing.Size(22, 4);
            this.lstSLA.TabIndex = 107;
            this.lstSLA.Tag = "SLA";
            this.lstSLA.Visible = false;
            // 
            // picSLA
            // 
            this.picSLA.BackColor = System.Drawing.Color.White;
            this.picSLA.BackgroundImage = global::Main.Properties.Resources.sla;
            this.picSLA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSLA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picSLA.Enabled = false;
            this.picSLA.Location = new System.Drawing.Point(106, 133);
            this.picSLA.Name = "picSLA";
            this.picSLA.Size = new System.Drawing.Size(22, 22);
            this.picSLA.TabIndex = 109;
            this.picSLA.TabStop = false;
            this.picSLA.Tag = "SLA";
            // 
            // btnSLA
            // 
            this.btnSLA.BackColor = System.Drawing.Color.White;
            this.btnSLA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSLA.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnSLA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnSLA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSLA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSLA.ForeColor = System.Drawing.Color.Black;
            this.btnSLA.Location = new System.Drawing.Point(4, 127);
            this.btnSLA.Name = "btnSLA";
            this.btnSLA.Size = new System.Drawing.Size(132, 35);
            this.btnSLA.TabIndex = 108;
            this.btnSLA.Tag = "SLA";
            this.btnSLA.Text = "SLA";
            this.btnSLA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSLA.UseVisualStyleBackColor = false;
            this.btnSLA.Click += new System.EventHandler(this.btnSLA_Click);
            // 
            // lstServiceContract
            // 
            this.lstServiceContract.FormattingEnabled = true;
            this.lstServiceContract.ItemHeight = 15;
            this.lstServiceContract.Location = new System.Drawing.Point(78, 174);
            this.lstServiceContract.Name = "lstServiceContract";
            this.lstServiceContract.Size = new System.Drawing.Size(22, 4);
            this.lstServiceContract.TabIndex = 104;
            this.lstServiceContract.Tag = "ServiceContract";
            this.lstServiceContract.Visible = false;
            // 
            // picServiceContract
            // 
            this.picServiceContract.BackColor = System.Drawing.Color.White;
            this.picServiceContract.BackgroundImage = global::Main.Properties.Resources.icons8_contract_50;
            this.picServiceContract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picServiceContract.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picServiceContract.Enabled = false;
            this.picServiceContract.Location = new System.Drawing.Point(106, 174);
            this.picServiceContract.Name = "picServiceContract";
            this.picServiceContract.Size = new System.Drawing.Size(22, 22);
            this.picServiceContract.TabIndex = 106;
            this.picServiceContract.TabStop = false;
            this.picServiceContract.Tag = "ServiceContract";
            // 
            // btnServiceContract
            // 
            this.btnServiceContract.BackColor = System.Drawing.Color.White;
            this.btnServiceContract.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServiceContract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnServiceContract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnServiceContract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServiceContract.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceContract.ForeColor = System.Drawing.Color.Black;
            this.btnServiceContract.Location = new System.Drawing.Point(4, 168);
            this.btnServiceContract.Name = "btnServiceContract";
            this.btnServiceContract.Size = new System.Drawing.Size(132, 35);
            this.btnServiceContract.TabIndex = 105;
            this.btnServiceContract.Tag = "ServiceContract";
            this.btnServiceContract.Text = "Contract";
            this.btnServiceContract.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServiceContract.UseVisualStyleBackColor = false;
            this.btnServiceContract.Click += new System.EventHandler(this.btnServiceContract_Click);
            // 
            // picAnswer
            // 
            this.picAnswer.BackgroundImage = global::Main.Properties.Resources.cellphone21;
            this.picAnswer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picAnswer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picAnswer.Enabled = false;
            this.picAnswer.Location = new System.Drawing.Point(53, 219);
            this.picAnswer.Name = "picAnswer";
            this.picAnswer.Size = new System.Drawing.Size(30, 30);
            this.picAnswer.TabIndex = 62;
            this.picAnswer.TabStop = false;
            this.picAnswer.Tag = "Answer";
            // 
            // btnAnswer
            // 
            this.btnAnswer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAnswer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAnswer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnswer.Location = new System.Drawing.Point(48, 214);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(40, 40);
            this.btnAnswer.TabIndex = 103;
            this.btnAnswer.Tag = "Answer";
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // txtTitle
            // 
            this.txtTitle.BackColor = System.Drawing.Color.Black;
            this.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTitle.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtTitle.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitle.ForeColor = System.Drawing.Color.White;
            this.txtTitle.Location = new System.Drawing.Point(47, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(157, 39);
            this.txtTitle.TabIndex = 2;
            this.txtTitle.Text = "Call Centre";
            this.txtTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.Black;
            this.pnlTitleBar.Controls.Add(this.picTitleIcon);
            this.pnlTitleBar.Controls.Add(this.txtTitle);
            this.pnlTitleBar.Controls.Add(this.picExit);
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(1000, 50);
            this.pnlTitleBar.TabIndex = 57;
            this.pnlTitleBar.Tag = "TitleBar";
            // 
            // picTitleIcon
            // 
            this.picTitleIcon.BackColor = System.Drawing.Color.Black;
            this.picTitleIcon.BackgroundImage = global::Main.Properties.Resources.callcentre1;
            this.picTitleIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picTitleIcon.Location = new System.Drawing.Point(13, 10);
            this.picTitleIcon.Name = "picTitleIcon";
            this.picTitleIcon.Size = new System.Drawing.Size(30, 30);
            this.picTitleIcon.TabIndex = 51;
            this.picTitleIcon.TabStop = false;
            // 
            // picExit
            // 
            this.picExit.BackColor = System.Drawing.Color.Transparent;
            this.picExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picExit.BackgroundImage")));
            this.picExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExit.Location = new System.Drawing.Point(949, 9);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(24, 30);
            this.picExit.TabIndex = 1;
            this.picExit.TabStop = false;
            this.picExit.Tag = "Exit";
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // dgvCallCentre
            // 
            this.dgvCallCentre.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCallCentre.Location = new System.Drawing.Point(154, 95);
            this.dgvCallCentre.Name = "dgvCallCentre";
            this.dgvCallCentre.Size = new System.Drawing.Size(834, 493);
            this.dgvCallCentre.TabIndex = 58;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(687, 70);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(50, 17);
            this.lblSearch.TabIndex = 59;
            this.lblSearch.Tag = "";
            this.lblSearch.Text = "Search:";
            // 
            // cmbSearch
            // 
            this.cmbSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearch.FormattingEnabled = true;
            this.cmbSearch.Location = new System.Drawing.Point(743, 68);
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(100, 21);
            this.cmbSearch.TabIndex = 60;
            this.cmbSearch.Tag = "Search";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(849, 68);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(139, 21);
            this.txtSearch.TabIndex = 61;
            this.txtSearch.Tag = "Search";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // frmCallCentre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.cmbSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.dgvCallCentre);
            this.Controls.Add(this.pnlButtons);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmCallCentre";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "CallCentre";
            this.Text = "frmCallCentre";
            this.Load += new System.EventHandler(this.frmCallCentre_Load);
            this.pnlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCallReport)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWorkRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceContract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAnswer)).EndInit();
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCallCentre)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.PictureBox picTitleIcon;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.DataGridView dgvCallCentre;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ComboBox cmbSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ListBox lstClient;
        private System.Windows.Forms.PictureBox picClient;
        private System.Windows.Forms.Button btnClient;
        private System.Windows.Forms.ListBox lstSLA;
        private System.Windows.Forms.PictureBox picSLA;
        private System.Windows.Forms.Button btnSLA;
        private System.Windows.Forms.ListBox lstServiceContract;
        private System.Windows.Forms.PictureBox picServiceContract;
        private System.Windows.Forms.Button btnServiceContract;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.ListBox lstCallReport;
        private System.Windows.Forms.PictureBox picCallReport;
        private System.Windows.Forms.Button btnCallReport;
        private System.Windows.Forms.ListBox lstWorkRequest;
        private System.Windows.Forms.PictureBox picWorkRequest;
        private System.Windows.Forms.Button btnWorkRequest;
        private System.Windows.Forms.PictureBox picAnswer;
    }
}