﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class Account
    {
        public string Username { get; private set; }
        public string Password { get; private set; }
        public string Category { get; private set; }
        public Account(string username = "", string password = "", string category = "")
        {
            Username = username;
            Password = password;
            Category = category;
        }
    }
}
