﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class ClientContracts
    {
        public int ClientID { get; private set; }
        public int ContractID { get; private set; }
        public ClientContracts(int clientID = 0, int contractID = 0)
        {
            ClientID = clientID;
            ContractID = contractID;
        }
    }
}
