﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class BusinessClient : Client
    {
        public int BusinessID { get; private set; }
        public string BusinessName { get; private set; }
        public string ContactTitle { get; private set; }
        public BusinessClient(
            int businessID = 0,
            int clientID = 0,
            int addressID = 0,
            string category = "",
            string firstName = "",
            string lastName = "",
            DateTime registrationDate = default,
            string email = "",
            string phone = "",
            string status = "",
            string notes = "",
            string businessName = "",
            string contactTitle = "")
            : base(clientID, addressID, category, firstName, lastName, registrationDate, email, phone, status, notes)
        {
            BusinessID = businessID;
            BusinessName = businessName;
            ContactTitle = contactTitle;
        }
    }
}
