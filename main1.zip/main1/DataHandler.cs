﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Main
{
    public class DataHandler
    {
        public static string conString = @"Data Source=(local);Initial Catalog=PremierServiceSolutions;Integrated Security=SSPI";
        private SqlConnection con = new SqlConnection(conString);
        private SqlCommand cmd;
        private SqlDataReader rdr;
        private string query;

        public void CreateSPS(ServicePackageServices sps)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateServicePackage", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@PackageID", SqlDbType.Int).Value = sps.PackageID;
                    cmd.Parameters.Add("@ServiceID", SqlDbType.Int).Value = sps.ServiceID;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateServicePackage(Service sp)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateServicePackage", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@AvailableFrom", SqlDbType.Date).Value = sp.Name;
                    cmd.Parameters.Add("@AvailableUntil", SqlDbType.NVarChar).Value = sp.Category;
                    cmd.Parameters.Add("@Status", SqlDbType.Float).Value = sp.Price;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateService(Service service)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateService", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = service.Name;
                    cmd.Parameters.Add("@Category", SqlDbType.NVarChar).Value = service.Category;
                    cmd.Parameters.Add("@Price", SqlDbType.Float).Value = service.Price;
                    cmd.Parameters.Add("@Level", SqlDbType.NVarChar).Value = service.Level;
                    cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = service.Description;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateSLA(SLA sla)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateSLA", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Description", SqlDbType.NVarChar).Value = sla.Description;
                    cmd.Parameters.Add("@ServicePackageDetails", SqlDbType.NVarChar).Value = sla.ServicePackageDetails;
                    cmd.Parameters.Add("@ServicePriorityDetails", SqlDbType.NVarChar).Value = sla.ServicePriorityDetails;
                    cmd.Parameters.Add("@TargetPerformanceDetails", SqlDbType.NVarChar).Value = sla.TargetPerformanceDetails;
                    cmd.Parameters.Add("@PartyObligationDetails", SqlDbType.NVarChar).Value = sla.PartyObligationDetails;
                    cmd.Parameters.Add("@BreachPenaltyDetails", SqlDbType.NVarChar).Value = sla.BreachPenaltyDetails;
                    cmd.Parameters.Add("@MetricProtocolDetails", SqlDbType.NVarChar).Value = sla.MetricProtocolDetails;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateServiceContract(ServiceContract contract)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateServiceContract", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@PackageID", SqlDbType.Int).Value = contract.PackageID;
                    cmd.Parameters.Add("@SlaID", SqlDbType.Int).Value = contract.SlaID;
                    cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value = contract.Status;
                    cmd.Parameters.Add("@Details", SqlDbType.NVarChar).Value = contract.Details;
                    cmd.Parameters.Add("@Category", SqlDbType.NVarChar).Value = contract.Category;
                    cmd.Parameters.Add("@PurchaseDate", SqlDbType.Date).Value = contract.PurchaseDate;
                    cmd.Parameters.Add("@EffectDate", SqlDbType.Date).Value = contract.EffectDate;
                    cmd.Parameters.Add("@ExpiryDate", SqlDbType.Date).Value = contract.ExpiryDate;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateClientContract(ClientContracts clientContract)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateClientContract", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@ClientID", SqlDbType.Int).Value = clientContract.ClientID;
                    cmd.Parameters.Add("@ContractID", SqlDbType.Int).Value = clientContract.ContractID;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateClient(Client client)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                using (SqlCommand cmd = new SqlCommand("USP_CreateClient", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@AddressID", SqlDbType.Int).Value = client.AddressID;
                    cmd.Parameters.Add("@Category", SqlDbType.NVarChar).Value = client.Category;
                    cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = client.FirstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.NVarChar).Value = client.LastName;
                    cmd.Parameters.Add("@RegistrationDate", SqlDbType.Date).Value = client.RegistrationDate;
                    cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = client.Email;
                    cmd.Parameters.Add("@Phone", SqlDbType.NVarChar).Value = client.Phone;
                    cmd.Parameters.Add("@Status", SqlDbType.NVarChar).Value = client.Status;
                    cmd.Parameters.Add("@Notes", SqlDbType.NVarChar).Value = client.Notes;

                    if (client is IndividualClient individualClient)
                    {
                        cmd.Parameters.Add("@DateOfBirth", SqlDbType.Date).Value = individualClient.DateOfBirth;
                    }

                    if (client is BusinessClient businessClient)
                    {
                        cmd.Parameters.Add("@BusinessName", SqlDbType.NVarChar).Value = businessClient.BusinessName;
                        cmd.Parameters.Add("@ContactTitle", SqlDbType.NVarChar).Value = businessClient.ContactTitle;
                    }

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void CreateWorkRequest(WorkRequest workRequest, List<int> technicianIDs, List<int> reportIDs)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_CreateWorkRequest", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@RequestDate", SqlDbType.Date)).Value = workRequest.RequestDate;
                        cmd.Parameters.Add(new SqlParameter("@ScheduledDate", SqlDbType.Date)).Value = workRequest.ScheduledDate;
                        cmd.Parameters.Add(new SqlParameter("@CompletedDate", SqlDbType.Date)).Value = (workRequest.CompletedDate != null) ? (object)workRequest.CompletedDate : DBNull.Value;
                        cmd.Parameters.Add(new SqlParameter("@ExpectedDuration", SqlDbType.Int)).Value = workRequest.ExpectedDuration;
                        cmd.Parameters.Add(new SqlParameter("@FinalDuration", SqlDbType.Int)).Value = (workRequest.FinalDuration != null) ? (object)workRequest.FinalDuration : DBNull.Value;
                        cmd.Parameters.Add(new SqlParameter("@MaintenanceType", SqlDbType.NVarChar, 50)).Value = workRequest.MaintenanceType;
                        cmd.Parameters.Add(new SqlParameter("@Priority", SqlDbType.NVarChar, 25)).Value = workRequest.Priority;
                        cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.NVarChar, 25)).Value = workRequest.Status;

                        SqlParameter techIDsParam = cmd.Parameters.AddWithValue("@TechnicianIDs", CreateDataTable(technicianIDs));
                        techIDsParam.SqlDbType = SqlDbType.Structured;
                        techIDsParam.TypeName = "dbo.TechnicianIDTableType";

                        SqlParameter reportIDsParam = cmd.Parameters.AddWithValue("@ReportIDs", CreateDataTable(reportIDs));
                        reportIDsParam.SqlDbType = SqlDbType.Structured;
                        reportIDsParam.TypeName = "dbo.ReportIDTableType";

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }


        private DataTable CreateDataTable(List<int> ids)
        {
            DataTable table = new DataTable();
            table.Columns.Add("ID", typeof(int));

            foreach (var id in ids)
            {
                table.Rows.Add(id);
            }
            return table;
        }

        public int CreateAddress(Address address)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_CreateAddress", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@AddressLine1", SqlDbType.NVarChar, 100)).Value = address.AddressLine1;
                        cmd.Parameters.Add(new SqlParameter("@AddressLine2", SqlDbType.NVarChar, 100)).Value = address.AddressLine2 ?? (object)DBNull.Value;
                        cmd.Parameters.Add(new SqlParameter("@Country", SqlDbType.NVarChar, 50)).Value = address.Country;
                        cmd.Parameters.Add(new SqlParameter("@PostalCode", SqlDbType.NVarChar, 25)).Value = address.PostalCode;
                        cmd.Parameters.Add(new SqlParameter("@City", SqlDbType.NVarChar, 50)).Value = address.City;
                        cmd.Parameters.Add(new SqlParameter("@Province", SqlDbType.NVarChar, 50)).Value = address.Province;
                        SqlParameter outputIdParam = new SqlParameter("@NewAddressID", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Output
                        };
                        cmd.Parameters.Add(outputIdParam);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        return (int)outputIdParam.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return -1;
            }
        }

        public void CreateTechnician(Technician technician)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_CreateTechnician", con))
                    {

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@AddressID", SqlDbType.Int)).Value = technician.AddressID;
                        cmd.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.NVarChar, 100)).Value = technician.FirstName;
                        cmd.Parameters.Add(new SqlParameter("@LastName", SqlDbType.NVarChar, 100)).Value = technician.LastName;
                        cmd.Parameters.Add(new SqlParameter("@DateOfBirth", SqlDbType.Date)).Value = technician.DateOfBirth;
                        cmd.Parameters.Add(new SqlParameter("@Email", SqlDbType.NVarChar, 50)).Value = technician.Email;
                        cmd.Parameters.Add(new SqlParameter("@Phone", SqlDbType.NVarChar, 25)).Value = technician.Phone;
                        cmd.Parameters.Add(new SqlParameter("@Category", SqlDbType.NVarChar, 25)).Value = technician.Category;
                        cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.NVarChar, 25)).Value = technician.Status;
                        cmd.Parameters.Add(new SqlParameter("@Schedule", SqlDbType.NVarChar, 25)).Value = technician.Schedule;
                        cmd.Parameters.Add(new SqlParameter("@Salary", SqlDbType.Float)).Value = technician.Salary;
                        cmd.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NVarChar, 100)).Value = technician.Notes ?? (object)DBNull.Value;
                        cmd.Parameters.Add(new SqlParameter("@CompletedRequests", SqlDbType.Int)).Value = technician.CompletedRequests;
                        cmd.Parameters.Add(new SqlParameter("@Specialization", SqlDbType.NVarChar, 25)).Value = technician.Specialization;
                        con.Open();
                        MessageBox.Show($"Inserting technician: {technician.TechnicianID.ToString()}, {technician.CompletedRequests.ToString()}, {technician.Specialization}, {technician.EmployeeID.ToString()},{technician.AddressID.ToString()}, {technician.FirstName}, {technician.LastName}, {technician.DateOfBirth}, {technician.Email}, {technician.Phone}, {technician.Category},{technician.Status},{technician.Schedule},{technician.Salary.ToString()},{technician.Notes.ToString()}");
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        public void CreateAccount(Account account) 
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_CreateAccount", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.NVarChar, 100)).Value = account.Username;
                        cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.NVarChar, 100)).Value = account.Password;
                        cmd.Parameters.Add(new SqlParameter("@Category", SqlDbType.NVarChar, 25)).Value = account.Category;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        public void CreateCallReport(CallReport report)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_CreateCallReport", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@ClientID", SqlDbType.Int)).Value = report.ClientID;
                        cmd.Parameters.Add(new SqlParameter("@Details", SqlDbType.NVarChar, -1)).Value = report.Details;
                        cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.NVarChar, 25)).Value = report.Status;
                        cmd.Parameters.Add(new SqlParameter("@ReportDate", SqlDbType.Date)).Value = report.ReportDate;
                        cmd.Parameters.Add(new SqlParameter("@StartTime", SqlDbType.Time)).Value = report.StartTime;
                        cmd.Parameters.Add(new SqlParameter("@EndTime", SqlDbType.Time)).Value = report.EndTime;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        // Load and get data
        public void LoadTechnicianData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetTechnicians", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bindingSource = new BindingSource();
                        bindingSource.DataSource = dt;
                        dgv.DataSource = bindingSource;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadWorkRequestData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetWorkRequests", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadClientData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetClients", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadSLAData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetSLAs", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadServiceContractData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetServiceContracts", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred aaa: " + ex.Message);
            }
        }
        public void LoadServiceData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetServices", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadServicePackageData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetServicePackages", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public void LoadCallReportData(DataGridView dgv)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter("USP_GetCallReports", con))
                    {
                        con.Open();
                        sda.SelectCommand.CommandType = CommandType.StoredProcedure;
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        BindingSource bs = new BindingSource();
                        bs.DataSource = dt;
                        dgv.DataSource = bs;
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }
        public List<Address> GetAddresses()
        {
            List<Address> addresses = new List<Address>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetAddresses", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                Address address = new Address(
                                    Convert.ToInt32(rdr["AddressID"]),
                                    rdr["AddressLine1"].ToString(),
                                    rdr["AddressLine2"].ToString(),
                                    rdr["Country"].ToString(),
                                    rdr["PostalCode"].ToString(),
                                    rdr["City"].ToString(),
                                    rdr["Province"].ToString()
                                );
                                addresses.Add(address);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return addresses;
        }

        public List<Client> GetClients()
        {
            List<Client> clients = new List<Client>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetClients", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                Client client = new Client(
                                    Convert.ToInt32(rdr["ClientID"]),
                                    Convert.ToInt32(rdr["AddressID"]),
                                    rdr["Category"].ToString(),
                                    rdr["FirstName"].ToString(),
                                    rdr["LastName"].ToString(),
                                    Convert.ToDateTime(rdr["RegistrationDate"]),
                                    rdr["Email"].ToString(),
                                    rdr["Phone"].ToString(),
                                    rdr["Status"].ToString(),
                                    rdr["Notes"].ToString()
                                );
                                clients.Add(client);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return clients;
        }

        public List<Technician> GetTechnicians()
        {
            List<Technician> technicians = new List<Technician>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetTechnicians", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                Technician technician = new Technician(
                                    technicianID: Convert.ToInt32(rdr["TechnicianID"]),
                                    addressID: Convert.ToInt32(rdr["AddressID"]),
                                    firstName: rdr["FirstName"].ToString(),
                                    lastName: rdr["LastName"].ToString(),
                                    dateOfBirth: Convert.ToDateTime(rdr["DateOfBirth"]),
                                    salary: Convert.ToSingle(rdr["Salary"]),
                                    email: rdr["Email"].ToString(),
                                    phone: rdr["Phone"].ToString(),
                                    status: rdr["Status"].ToString(),
                                    completedRequests: Convert.ToInt32(rdr["CompletedRequests"]),
                                    specialization: rdr["Specialization"].ToString(),
                                    schedule: rdr["Schedule"].ToString(),
                                    notes: rdr["Notes"].ToString()
                                );
                                technicians.Add(technician);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred aaa: " + ex.Message);
            }
            return technicians;
        }

        public List<ServiceContract> GetServiceContracts()
        {
            List<ServiceContract> contracts = new List<ServiceContract>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetServiceContracts", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                DateTime? purchaseDate = rdr["PurchaseDate"] != DBNull.Value ? Convert.ToDateTime(rdr["PurchaseDate"]) : (DateTime?)null;
                                DateTime? effectDate = rdr["EffectDate"] != DBNull.Value ? Convert.ToDateTime(rdr["EffectDate"]) : (DateTime?)null;
                                DateTime? expiryDate = rdr["ExpiryDate"] != DBNull.Value ? Convert.ToDateTime(rdr["ExpiryDate"]) : (DateTime?)null;

                                ServiceContract contract = new ServiceContract(
                                    Convert.ToInt32(rdr["ContractID"]),
                                    Convert.ToInt32(rdr["PackageID"]),
                                    Convert.ToInt32(rdr["SlaID"]),
                                    rdr["Status"].ToString(),
                                    rdr["Details"].ToString(),
                                    rdr["Category"].ToString(),
                                    purchaseDate,
                                    effectDate,
                                    expiryDate);
                                contracts.Add(contract);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return contracts;
        }

        public List<ClientContracts> GetClientContracts()
        {
            List<ClientContracts> clientContracts = new List<ClientContracts>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetClientContracts", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                ClientContracts clientContract = new ClientContracts(
                                    Convert.ToInt32(rdr["ClientID"]),
                                    Convert.ToInt32(rdr["ContractID"]));
                                clientContracts.Add(clientContract);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return clientContracts;
        }

        public List<WorkRequest> GetWorkRequests()
        {
            List<WorkRequest> serviceRequests = new List<WorkRequest>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetWorkRequests", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                DateTime completedDate = default;
                                int finalDuration = 0;
                                if (!rdr.IsDBNull(rdr.GetOrdinal("CompletedDate"))) { completedDate = Convert.ToDateTime(rdr["CompletedDate"]); }
                                if (!rdr.IsDBNull(rdr.GetOrdinal("FinalDuration"))) { finalDuration = Convert.ToInt32(rdr["FinalDuration"]); }
                                WorkRequest request = new WorkRequest(
                                    Convert.ToInt32(rdr["RequestID"]),
                                    Convert.ToDateTime(rdr["RequestDate"]),
                                    Convert.ToDateTime(rdr["ScheduledDate"]),
                                    completedDate,
                                    Convert.ToInt32(rdr["ExpectedDuration"]),
                                    finalDuration,
                                    rdr["MaintenanceType"].ToString(),
                                    rdr["Priority"].ToString(),
                                    rdr["Status"].ToString()
                                );
                                serviceRequests.Add(request);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return serviceRequests;
        }

        public List<WorkRequestAssignedTechnicians> GetWRAT()
        {
            List<WorkRequestAssignedTechnicians> assignedTechnicians = new List<WorkRequestAssignedTechnicians>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetWRAT", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                WorkRequestAssignedTechnicians assignedTechnician = new WorkRequestAssignedTechnicians
                                (
                                    Convert.ToInt32(rdr["RequestID"]),
                                    Convert.ToInt32(rdr["TechnicianID"])
                                );
                                assignedTechnicians.Add(assignedTechnician);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return assignedTechnicians;
        }

        public List<WorkRequestAssignedTechnicians> GetWRATByTechnicianID(int id)
        {
            List<WorkRequestAssignedTechnicians> assignedTechnicians = new List<WorkRequestAssignedTechnicians>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetWRATByTechnicianID", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@TechnicianID", SqlDbType.Int)).Value = id;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                WorkRequestAssignedTechnicians assignedTechnician = new WorkRequestAssignedTechnicians
                                (
                                    Convert.ToInt32(rdr["RequestID"]),
                                    Convert.ToInt32(rdr["TechnicianID"])
                                );
                                assignedTechnicians.Add(assignedTechnician);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return assignedTechnicians;
        }

        public List<WorkRequestAssignedReports> GetWRAR()
        {
            List<WorkRequestAssignedReports> assignedReports = new List<WorkRequestAssignedReports>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetWRAR", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();

                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                WorkRequestAssignedReports assignedReport = new WorkRequestAssignedReports
                                (
                                    Convert.ToInt32(rdr["RequestID"]),
                                    Convert.ToInt32(rdr["ReportID"])
                                );
                                assignedReports.Add(assignedReport);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return assignedReports;
        }

        public List<WorkRequestAssignedReports> GetWRARByReportID(int id)
        {
            List<WorkRequestAssignedReports> assignedReports = new List<WorkRequestAssignedReports>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetWRARByReportID", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@ReportID", SqlDbType.Int)).Value = id;
                        con.Open();

                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                WorkRequestAssignedReports assignedReport = new WorkRequestAssignedReports
                                (
                                    Convert.ToInt32(rdr["RequestID"]),
                                    Convert.ToInt32(rdr["ReportID"])
                                );
                                assignedReports.Add(assignedReport);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return assignedReports;
        }

        public Account GetAccountByUsername(string username)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetAccountByUsername", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Username", SqlDbType.NVarChar, 100)).Value = username;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            if (rdr.Read())
                            {
                                Account account = new Account(
                                    rdr["Username"].ToString(),
                                    rdr["Password"].ToString(),
                                    rdr["Category"].ToString()
                                );
                                return account;
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return null;
            }
            return null;
        }

        public List<Account> GetAccounts()
        {
            List<Account> accounts = new List<Account>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetAccounts", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                Account account = new Account(
                                    rdr["Username"].ToString(),
                                    rdr["Password"].ToString(),
                                    rdr["Category"].ToString()
                                );
                                accounts.Add(account);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return accounts;
        }

        public List<CallReport> GetCallReports()
        {
            List<CallReport> callReports = new List<CallReport>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetCallReports", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                CallReport callReport = new CallReport(
                                    Convert.ToInt32(rdr["ReportID"]),
                                    Convert.ToInt32(rdr["ClientID"]),
                                    rdr["Details"].ToString(),
                                    rdr["Status"].ToString(),
                                    Convert.ToDateTime(rdr["ReportDate"]),
                                    (TimeSpan)rdr["StartTime"],
                                    (TimeSpan)rdr["EndTime"]
                                );
                                callReports.Add(callReport);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return callReports;
        }

        public List<ServicePackage> GetPackages()
        {
            List<ServicePackage> packages = new List<ServicePackage>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetServicePackages", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {

                                ServicePackage package = new ServicePackage(
                                        Convert.ToInt32(rdr["PackageID"]),
                                        Convert.ToDateTime(rdr["AvailableFrom"]),
                                        Convert.ToDateTime(rdr["AvailableUntil"]),
                                        rdr["Status"].ToString()
                                    );
                                packages.Add(package);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return packages;
        }

        public List<SLA> GetSLAs()
        {
            List<SLA> slas = new List<SLA>();
            try
            {
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetSLAs", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader rdr = cmd.ExecuteReader())
                        {
                            while (rdr.Read())
                            {

                                SLA sla = new SLA(
                                    Convert.ToInt32(rdr["SlaID"]),
                                    rdr["Description"].ToString(),
                                    rdr["ServicePackageDetails"].ToString(),
                                    rdr["ServicePriorityDetails"].ToString(),
                                    rdr["TargetPerformanceDetails"].ToString(),
                                    rdr["PartyObligationDetails"].ToString(),
                                    rdr["BreachPenaltyDetails"].ToString(),
                                    rdr["MetricProtocolDetails"].ToString()
                                );
                                slas.Add(sla);
                            }
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            return slas;
        }
    }
}