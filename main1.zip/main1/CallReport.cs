﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main
{
    public class CallReport
    {
        public int ReportID { get; private set; }
        public int ClientID { get; private set; }
        public string Details { get; private set; }
        public string Status { get; private set; }
        public DateTime ReportDate { get; private set; }
        public TimeSpan StartTime { get; private set; }
        public TimeSpan EndTime { get; private set; }
        public CallReport(
            int reportID = 0,
            int clientID = 0,
            string details = "",
            string status = "",
            DateTime reportDate = default,
            TimeSpan startTime = default,
            TimeSpan endTime = default)
        {
            ReportID = reportID;
            ClientID = clientID;
            Details = details;
            Status = status;
            ReportDate = reportDate;
            StartTime = startTime;
            EndTime = endTime;
        }
    }
}
