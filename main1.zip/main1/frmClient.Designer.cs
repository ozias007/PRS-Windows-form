﻿namespace Main
{
    partial class frmClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClient));
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.mxtPhone = new System.Windows.Forms.MaskedTextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtClientID = new System.Windows.Forms.TextBox();
            this.lblClientTitle = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.pnlAddress = new System.Windows.Forms.Panel();
            this.btnAddress = new System.Windows.Forms.Button();
            this.cmbAddressID = new System.Windows.Forms.ComboBox();
            this.lblAddressID = new System.Windows.Forms.Label();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.lblNotes = new System.Windows.Forms.Label();
            this.lblRegistrationDate = new System.Windows.Forms.Label();
            this.clbClientContracts = new System.Windows.Forms.CheckedListBox();
            this.lblClientContracts = new System.Windows.Forms.Label();
            this.lblBusinessName = new System.Windows.Forms.Label();
            this.lblContactTitle = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtContactTitle = new System.Windows.Forms.TextBox();
            this.txtBusinessName = new System.Windows.Forms.TextBox();
            this.lblDateOfBirth = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.txtBusinessID = new System.Windows.Forms.TextBox();
            this.lblBusinessID = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtIndividualID = new System.Windows.Forms.TextBox();
            this.lblIndividualID = new System.Windows.Forms.Label();
            this.lblClientID = new System.Windows.Forms.Label();
            this.pnlDatePicker = new System.Windows.Forms.Panel();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtpRegistrationDate = new System.Windows.Forms.DateTimePicker();
            this.pnlTitleBar.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.pnlAddress.SuspendLayout();
            this.pnlDatePicker.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtEmail
            // 
            this.txtEmail.Enabled = false;
            this.txtEmail.Location = new System.Drawing.Point(9, 179);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 22);
            this.txtEmail.TabIndex = 96;
            this.txtEmail.Tag = "Email";
            // 
            // mxtPhone
            // 
            this.mxtPhone.Enabled = false;
            this.mxtPhone.Location = new System.Drawing.Point(115, 179);
            this.mxtPhone.Mask = "+0000000000099999";
            this.mxtPhone.Name = "mxtPhone";
            this.mxtPhone.Size = new System.Drawing.Size(100, 22);
            this.mxtPhone.TabIndex = 91;
            this.mxtPhone.Tag = "Phone";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Enabled = false;
            this.lblPhone.Location = new System.Drawing.Point(112, 165);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(43, 13);
            this.lblPhone.TabIndex = 78;
            this.lblPhone.Tag = "";
            this.lblPhone.Text = "Phone:";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.cmbStatus.Location = new System.Drawing.Point(221, 19);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 74;
            this.cmbStatus.Tag = "Status";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Enabled = false;
            this.lblEmail.Location = new System.Drawing.Point(6, 165);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(37, 13);
            this.lblEmail.TabIndex = 70;
            this.lblEmail.Tag = "";
            this.lblEmail.Text = "Email:";
            // 
            // txtClientID
            // 
            this.txtClientID.Enabled = false;
            this.txtClientID.Location = new System.Drawing.Point(9, 19);
            this.txtClientID.Name = "txtClientID";
            this.txtClientID.Size = new System.Drawing.Size(100, 22);
            this.txtClientID.TabIndex = 54;
            this.txtClientID.Tag = "ClientID";
            // 
            // lblClientTitle
            // 
            this.lblClientTitle.AutoSize = true;
            this.lblClientTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClientTitle.Location = new System.Drawing.Point(3, 4);
            this.lblClientTitle.Name = "lblClientTitle";
            this.lblClientTitle.Size = new System.Drawing.Size(62, 25);
            this.lblClientTitle.TabIndex = 6;
            this.lblClientTitle.Tag = "";
            this.lblClientTitle.Text = "Client";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblClientTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 16;
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlControls.Controls.Add(this.pnlAddress);
            this.pnlControls.Controls.Add(this.cmbAddressID);
            this.pnlControls.Controls.Add(this.lblAddressID);
            this.pnlControls.Controls.Add(this.txtNotes);
            this.pnlControls.Controls.Add(this.lblNotes);
            this.pnlControls.Controls.Add(this.lblRegistrationDate);
            this.pnlControls.Controls.Add(this.clbClientContracts);
            this.pnlControls.Controls.Add(this.lblClientContracts);
            this.pnlControls.Controls.Add(this.lblBusinessName);
            this.pnlControls.Controls.Add(this.lblContactTitle);
            this.pnlControls.Controls.Add(this.txtLastName);
            this.pnlControls.Controls.Add(this.lblLastName);
            this.pnlControls.Controls.Add(this.txtFirstName);
            this.pnlControls.Controls.Add(this.lblFirstName);
            this.pnlControls.Controls.Add(this.txtContactTitle);
            this.pnlControls.Controls.Add(this.txtBusinessName);
            this.pnlControls.Controls.Add(this.lblDateOfBirth);
            this.pnlControls.Controls.Add(this.cmbCategory);
            this.pnlControls.Controls.Add(this.lblCategory);
            this.pnlControls.Controls.Add(this.txtBusinessID);
            this.pnlControls.Controls.Add(this.lblBusinessID);
            this.pnlControls.Controls.Add(this.txtEmail);
            this.pnlControls.Controls.Add(this.mxtPhone);
            this.pnlControls.Controls.Add(this.lblPhone);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.lblEmail);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.txtIndividualID);
            this.pnlControls.Controls.Add(this.lblIndividualID);
            this.pnlControls.Controls.Add(this.txtClientID);
            this.pnlControls.Controls.Add(this.lblClientID);
            this.pnlControls.Controls.Add(this.pnlDatePicker);
            this.pnlControls.Controls.Add(this.panel1);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 275);
            this.pnlControls.TabIndex = 17;
            this.pnlControls.Tag = "Controls";
            // 
            // pnlAddress
            // 
            this.pnlAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddress.Controls.Add(this.btnAddress);
            this.pnlAddress.Location = new System.Drawing.Point(9, 139);
            this.pnlAddress.Name = "pnlAddress";
            this.pnlAddress.Size = new System.Drawing.Size(21, 21);
            this.pnlAddress.TabIndex = 147;
            this.pnlAddress.Tag = "Address";
            // 
            // btnAddress
            // 
            this.btnAddress.BackColor = System.Drawing.SystemColors.Control;
            this.btnAddress.BackgroundImage = global::Main.Properties.Resources.add;
            this.btnAddress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddress.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddress.Enabled = false;
            this.btnAddress.FlatAppearance.BorderSize = 0;
            this.btnAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddress.Location = new System.Drawing.Point(2, 2);
            this.btnAddress.Name = "btnAddress";
            this.btnAddress.Size = new System.Drawing.Size(15, 15);
            this.btnAddress.TabIndex = 101;
            this.btnAddress.Tag = "Address";
            this.btnAddress.UseVisualStyleBackColor = false;
            this.btnAddress.Click += new System.EventHandler(this.btnAddress_Click);
            // 
            // cmbAddressID
            // 
            this.cmbAddressID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddressID.Enabled = false;
            this.cmbAddressID.FormattingEnabled = true;
            this.cmbAddressID.Location = new System.Drawing.Point(30, 139);
            this.cmbAddressID.Name = "cmbAddressID";
            this.cmbAddressID.Size = new System.Drawing.Size(79, 21);
            this.cmbAddressID.TabIndex = 146;
            this.cmbAddressID.Tag = "AddressID";
            // 
            // lblAddressID
            // 
            this.lblAddressID.AutoSize = true;
            this.lblAddressID.Enabled = false;
            this.lblAddressID.Location = new System.Drawing.Point(7, 125);
            this.lblAddressID.Name = "lblAddressID";
            this.lblAddressID.Size = new System.Drawing.Size(65, 13);
            this.lblAddressID.TabIndex = 145;
            this.lblAddressID.Tag = "";
            this.lblAddressID.Text = "Address ID:";
            // 
            // txtNotes
            // 
            this.txtNotes.Enabled = false;
            this.txtNotes.Location = new System.Drawing.Point(221, 219);
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(100, 22);
            this.txtNotes.TabIndex = 136;
            this.txtNotes.Tag = "Notes";
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Enabled = false;
            this.lblNotes.Location = new System.Drawing.Point(218, 205);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(40, 13);
            this.lblNotes.TabIndex = 135;
            this.lblNotes.Tag = "";
            this.lblNotes.Text = "Notes:";
            // 
            // lblRegistrationDate
            // 
            this.lblRegistrationDate.AutoSize = true;
            this.lblRegistrationDate.Enabled = false;
            this.lblRegistrationDate.Location = new System.Drawing.Point(112, 125);
            this.lblRegistrationDate.Name = "lblRegistrationDate";
            this.lblRegistrationDate.Size = new System.Drawing.Size(79, 13);
            this.lblRegistrationDate.TabIndex = 133;
            this.lblRegistrationDate.Tag = "";
            this.lblRegistrationDate.Text = "Register Date:";
            // 
            // clbClientContracts
            // 
            this.clbClientContracts.Enabled = false;
            this.clbClientContracts.FormattingEnabled = true;
            this.clbClientContracts.Location = new System.Drawing.Point(221, 99);
            this.clbClientContracts.Name = "clbClientContracts";
            this.clbClientContracts.Size = new System.Drawing.Size(100, 106);
            this.clbClientContracts.TabIndex = 129;
            this.clbClientContracts.Tag = "ContractIDs";
            // 
            // lblClientContracts
            // 
            this.lblClientContracts.AutoSize = true;
            this.lblClientContracts.Enabled = false;
            this.lblClientContracts.Location = new System.Drawing.Point(218, 85);
            this.lblClientContracts.Name = "lblClientContracts";
            this.lblClientContracts.Size = new System.Drawing.Size(59, 13);
            this.lblClientContracts.TabIndex = 128;
            this.lblClientContracts.Tag = "";
            this.lblClientContracts.Text = "Contracts:";
            // 
            // lblBusinessName
            // 
            this.lblBusinessName.AutoSize = true;
            this.lblBusinessName.Enabled = false;
            this.lblBusinessName.Location = new System.Drawing.Point(112, 45);
            this.lblBusinessName.Name = "lblBusinessName";
            this.lblBusinessName.Size = new System.Drawing.Size(54, 13);
            this.lblBusinessName.TabIndex = 123;
            this.lblBusinessName.Tag = "";
            this.lblBusinessName.Text = "Business:";
            // 
            // lblContactTitle
            // 
            this.lblContactTitle.AutoSize = true;
            this.lblContactTitle.Enabled = false;
            this.lblContactTitle.Location = new System.Drawing.Point(218, 45);
            this.lblContactTitle.Name = "lblContactTitle";
            this.lblContactTitle.Size = new System.Drawing.Size(75, 13);
            this.lblContactTitle.TabIndex = 122;
            this.lblContactTitle.Tag = "";
            this.lblContactTitle.Text = "Contact Title:";
            // 
            // txtLastName
            // 
            this.txtLastName.Enabled = false;
            this.txtLastName.Location = new System.Drawing.Point(115, 219);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 22);
            this.txtLastName.TabIndex = 119;
            this.txtLastName.Tag = "LastName";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Enabled = false;
            this.lblLastName.Location = new System.Drawing.Point(112, 205);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(62, 13);
            this.lblLastName.TabIndex = 118;
            this.lblLastName.Tag = "";
            this.lblLastName.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Enabled = false;
            this.txtFirstName.Location = new System.Drawing.Point(9, 219);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 22);
            this.txtFirstName.TabIndex = 117;
            this.txtFirstName.Tag = "FirstName";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Enabled = false;
            this.lblFirstName.Location = new System.Drawing.Point(6, 205);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(64, 13);
            this.lblFirstName.TabIndex = 116;
            this.lblFirstName.Tag = "";
            this.lblFirstName.Text = "First Name:";
            // 
            // txtContactTitle
            // 
            this.txtContactTitle.Enabled = false;
            this.txtContactTitle.Location = new System.Drawing.Point(221, 59);
            this.txtContactTitle.Name = "txtContactTitle";
            this.txtContactTitle.Size = new System.Drawing.Size(100, 22);
            this.txtContactTitle.TabIndex = 115;
            this.txtContactTitle.Tag = "ContactTitle";
            // 
            // txtBusinessName
            // 
            this.txtBusinessName.Enabled = false;
            this.txtBusinessName.Location = new System.Drawing.Point(115, 59);
            this.txtBusinessName.Name = "txtBusinessName";
            this.txtBusinessName.Size = new System.Drawing.Size(100, 22);
            this.txtBusinessName.TabIndex = 112;
            this.txtBusinessName.Tag = "BusinessName";
            // 
            // lblDateOfBirth
            // 
            this.lblDateOfBirth.AutoSize = true;
            this.lblDateOfBirth.Enabled = false;
            this.lblDateOfBirth.Location = new System.Drawing.Point(114, 85);
            this.lblDateOfBirth.Name = "lblDateOfBirth";
            this.lblDateOfBirth.Size = new System.Drawing.Size(33, 13);
            this.lblDateOfBirth.TabIndex = 110;
            this.lblDateOfBirth.Tag = "";
            this.lblDateOfBirth.Text = "DOB:";
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Enabled = false;
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "Business",
            "Individual"});
            this.cmbCategory.Location = new System.Drawing.Point(115, 19);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(100, 21);
            this.cmbCategory.TabIndex = 107;
            this.cmbCategory.Tag = "Category";
            this.cmbCategory.SelectedIndexChanged += new System.EventHandler(this.cmbCategory_SelectedIndexChanged);
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Enabled = false;
            this.lblCategory.Location = new System.Drawing.Point(112, 5);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(56, 13);
            this.lblCategory.TabIndex = 106;
            this.lblCategory.Tag = "";
            this.lblCategory.Text = "Category:";
            // 
            // txtBusinessID
            // 
            this.txtBusinessID.Enabled = false;
            this.txtBusinessID.Location = new System.Drawing.Point(9, 59);
            this.txtBusinessID.Name = "txtBusinessID";
            this.txtBusinessID.Size = new System.Drawing.Size(100, 22);
            this.txtBusinessID.TabIndex = 102;
            this.txtBusinessID.Tag = "BusinessID";
            // 
            // lblBusinessID
            // 
            this.lblBusinessID.AutoSize = true;
            this.lblBusinessID.Enabled = false;
            this.lblBusinessID.Location = new System.Drawing.Point(6, 45);
            this.lblBusinessID.Name = "lblBusinessID";
            this.lblBusinessID.Size = new System.Drawing.Size(68, 13);
            this.lblBusinessID.TabIndex = 101;
            this.lblBusinessID.Tag = "";
            this.lblBusinessID.Text = "Business ID:";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(275, 247);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(301, 247);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(217, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 68;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // txtIndividualID
            // 
            this.txtIndividualID.Enabled = false;
            this.txtIndividualID.Location = new System.Drawing.Point(9, 99);
            this.txtIndividualID.Name = "txtIndividualID";
            this.txtIndividualID.Size = new System.Drawing.Size(100, 22);
            this.txtIndividualID.TabIndex = 60;
            this.txtIndividualID.Tag = "IndividualID";
            // 
            // lblIndividualID
            // 
            this.lblIndividualID.AutoSize = true;
            this.lblIndividualID.Enabled = false;
            this.lblIndividualID.Location = new System.Drawing.Point(6, 85);
            this.lblIndividualID.Name = "lblIndividualID";
            this.lblIndividualID.Size = new System.Drawing.Size(75, 13);
            this.lblIndividualID.TabIndex = 59;
            this.lblIndividualID.Tag = "";
            this.lblIndividualID.Text = "Individual ID:";
            // 
            // lblClientID
            // 
            this.lblClientID.AutoSize = true;
            this.lblClientID.Enabled = false;
            this.lblClientID.Location = new System.Drawing.Point(5, 5);
            this.lblClientID.Name = "lblClientID";
            this.lblClientID.Size = new System.Drawing.Size(54, 13);
            this.lblClientID.TabIndex = 51;
            this.lblClientID.Tag = "";
            this.lblClientID.Text = "Client ID:";
            // 
            // pnlDatePicker
            // 
            this.pnlDatePicker.Controls.Add(this.dtpDateOfBirth);
            this.pnlDatePicker.Location = new System.Drawing.Point(115, 99);
            this.pnlDatePicker.Name = "pnlDatePicker";
            this.pnlDatePicker.Size = new System.Drawing.Size(102, 24);
            this.pnlDatePicker.TabIndex = 148;
            this.pnlDatePicker.Tag = "DatePickerDOB";
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.Enabled = false;
            this.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateOfBirth.Location = new System.Drawing.Point(1, 1);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(100, 22);
            this.dtpDateOfBirth.TabIndex = 113;
            this.dtpDateOfBirth.Tag = "DateOfBirth";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtpRegistrationDate);
            this.panel1.Location = new System.Drawing.Point(115, 138);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(102, 24);
            this.panel1.TabIndex = 150;
            this.panel1.Tag = "DatePickerNOW";
            // 
            // dtpRegistrationDate
            // 
            this.dtpRegistrationDate.Enabled = false;
            this.dtpRegistrationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRegistrationDate.Location = new System.Drawing.Point(1, 1);
            this.dtpRegistrationDate.Name = "dtpRegistrationDate";
            this.dtpRegistrationDate.Size = new System.Drawing.Size(100, 22);
            this.dtpRegistrationDate.TabIndex = 136;
            this.dtpRegistrationDate.Tag = "RegistrationDate";
            // 
            // frmClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 310);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlControls);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmClient";
            this.Tag = "Client";
            this.Text = "frmClient";
            this.Load += new System.EventHandler(this.frmClient_Load);
            this.Shown += new System.EventHandler(this.frmClient_Shown);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.pnlAddress.ResumeLayout(false);
            this.pnlDatePicker.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.MaskedTextBox mxtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtClientID;
        private System.Windows.Forms.Label lblClientTitle;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.TextBox txtBusinessID;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label lblDateOfBirth;
        private System.Windows.Forms.TextBox txtBusinessName;
        private System.Windows.Forms.TextBox txtIndividualID;
        private System.Windows.Forms.Label lblIndividualID;
        private System.Windows.Forms.TextBox txtContactTitle;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblContactTitle;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblBusinessID;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblClientID;
        private System.Windows.Forms.Label lblBusinessName;
        private System.Windows.Forms.CheckedListBox clbClientContracts;
        private System.Windows.Forms.Label lblClientContracts;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Label lblRegistrationDate;
        private System.Windows.Forms.Panel pnlAddress;
        private System.Windows.Forms.Button btnAddress;
        private System.Windows.Forms.ComboBox cmbAddressID;
        private System.Windows.Forms.Label lblAddressID;
        private System.Windows.Forms.Panel pnlDatePicker;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.DateTimePicker dtpRegistrationDate;
    }
}