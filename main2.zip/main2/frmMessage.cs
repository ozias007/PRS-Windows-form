﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using System.Configuration;

namespace Main
{
    public partial class frmMessage : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private List<Technician> technicians = new List<Technician>();
        private List<(string TechnicianID, string Phone)> availableTechnicians = new List<(string, string)>();
        private List<WorkRequest> workRequests = new List<WorkRequest>();
        private List<WorkRequest> openRequests = new List<WorkRequest>();
        public frmMessage()
        {
            InitializeComponent();
            uim = new UIManager(this, pnlTitleBar);
            uim.RegisterControlEvents();
        }
        private void frmNotify_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            technicians = dlh.GetTechnicians();
            workRequests = dlh.GetWorkRequests();
            foreach(Technician technician in technicians)
            {
                if (technician.Status == "Available")
                {
                    availableTechnicians.Add((technician.TechnicianID.ToString(), technician.Phone.ToString()));
                    chkTechnician.Items.Add($"{technician.TechnicianID}: {technician.LastName}");
                }
            }
            foreach (WorkRequest request in workRequests)
            {
                if (request.Status == "Open")
                {
                    openRequests.Add(request);
                    chkRequest.Items.Add($"{request.RequestID}: {request.Priority}");
                }
            }
        }
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string accountSid = ConfigurationManager.AppSettings["TwilioAccountSid"];
            string authToken = ConfigurationManager.AppSettings["TwilioAuthToken"];
            string senderNum = ConfigurationManager.AppSettings["TwilioSender"]; ;
            if (!string.IsNullOrEmpty(accountSid) && !string.IsNullOrEmpty(authToken) && !string.IsNullOrEmpty(senderNum))
            {
                string msg = GetMsg(chkRequest);
                List<string> sendTo = SendTo(chkTechnician);
                if (sendTo.Count > 0 && msg != "")
                {
                    foreach (string phoneNumber in sendTo)
                    {
                        try
                        {
                            string messageSid = SendMsg(accountSid, authToken, senderNum, phoneNumber, msg);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }
                    MessageBox.Show("Notification(s) sent.");
                }
                else MessageBox.Show("No selection(s) made.");
            }
            else MessageBox.Show("Twilio credentials are invalid.");
        }

        private string SendMsg(string accountSid, string authToken, string from, string to, string body)
        {
            TwilioClient.Init(accountSid, authToken);
            var message = MessageResource.Create(
                body: body,
                from: new Twilio.Types.PhoneNumber(from),
                to: new Twilio.Types.PhoneNumber(to)
            );
            return message.Sid;
        }

        private string GetMsg(CheckedListBox chk)
        {
            string msg = "";
            List<string> high = new List<string>();
            List<string> medium = new List<string>();
            List<string> low = new List<string>();
            foreach (var @checked in chk.CheckedItems)
            {
                int charloc = @checked.ToString().IndexOf(":") + 2;
                string priority = @checked.ToString().Substring(charloc);
                switch (priority)
                {
                    case "High":
                        high.Add(@checked.ToString().Substring(0, charloc - 2));
                        break;
                    case "Medium":
                        medium.Add(@checked.ToString().Substring(0, charloc - 2));
                        break;
                    case "Low":
                        low.Add(@checked.ToString().Substring(0, charloc - 2));
                        break;
                }
            }
            if (high.Count > 0 || medium.Count > 0 || low.Count > 0)
            {
                msg += "OPEN:";
                if (high.Count > 0)
                {
                    msg += "[H:";
                    msg += $"{string.Join(",", high)}";
                    msg += "]";
                }
                if (medium.Count > 0)
                {
                    msg += "[M:";
                    msg += $"{string.Join(",", medium)}";
                    msg += "]";
                }
                if (low.Count > 0)
                {
                    msg += "[L:";
                    msg += $"{string.Join(",", low)}";
                    msg += "]";
                }
            }
            return msg;
        }

        private List<string> SendTo(CheckedListBox chk)
        {
            List<string> sendTo = new List<string>();
            foreach (var @checked in chk.CheckedItems)
            {
                int charloc = @checked.ToString().IndexOf(":");
                string id = @checked.ToString().Substring(0, charloc);
                foreach (var technician in availableTechnicians)
                {
                    if (id == technician.TechnicianID)
                    {
                        sendTo.Add($"{technician.Phone}");
                        break;
                    }
                }
            }
            return sendTo;
        }
        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }
    }
}
