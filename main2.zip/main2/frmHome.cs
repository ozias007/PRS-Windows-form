﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmHome : Form
    {
        private UIManager uim;
        private Account user;
        public frmHome()
        {
            InitializeComponent();
            uim = new UIManager(this, pnlTitleBar, picExit, pnlButtons);
            user = LoginManager.lm.GetLoggedInAccount();
            if (user.Category != "admin")
            {
                uim.SetHomeState(user.Category);
            }
        }
        private void frmHome_Load(object sender, EventArgs e)
        {
            ActiveControl = picPSS;
            uim.RegisterControlEvents();
        }
        private void picExit_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Return to login?", "Confirmation", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                LoginManager.lm.Logout();
                Hide();
                uim.ShowForm("Main.frmLogin");
            }
            if (res == DialogResult.No)
            {
                Application.Exit();
            }
        }

        private void btnServiceDepartment_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmServiceDepartment");
        }

        private void btnCallCentre_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmCallCentre");
        }

        private void btnClientMaintenance_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmClientMaintenance");
        }

        private void btnContractMaintenance_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmContractMaintenance");
        }
    }
}
