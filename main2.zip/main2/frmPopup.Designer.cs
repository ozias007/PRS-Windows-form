﻿namespace Main
{
    partial class frmPopup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitlebar = new System.Windows.Forms.Panel();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btnStop = new System.Windows.Forms.Button();
            this.pnlPopupIcon = new System.Windows.Forms.Panel();
            this.pnlTitlebar.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitlebar
            // 
            this.pnlTitlebar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitlebar.Controls.Add(this.lblTimer);
            this.pnlTitlebar.Controls.Add(this.btnStop);
            this.pnlTitlebar.Controls.Add(this.pnlPopupIcon);
            this.pnlTitlebar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitlebar.Name = "pnlTitlebar";
            this.pnlTitlebar.Size = new System.Drawing.Size(144, 150);
            this.pnlTitlebar.TabIndex = 7;
            this.pnlTitlebar.Tag = "TitleBar";
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(33, 121);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(49, 13);
            this.lblTimer.TabIndex = 9;
            this.lblTimer.Tag = "Timer";
            this.lblTimer.Text = "00:00:00";
            // 
            // btnStop
            // 
            this.btnStop.BackgroundImage = global::Main.Properties.Resources.stop_button;
            this.btnStop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStop.FlatAppearance.BorderSize = 0;
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStop.Location = new System.Drawing.Point(87, 117);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(20, 20);
            this.btnStop.TabIndex = 8;
            this.btnStop.Tag = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // pnlPopupIcon
            // 
            this.pnlPopupIcon.BackgroundImage = global::Main.Properties.Resources.cellphone21;
            this.pnlPopupIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPopupIcon.Enabled = false;
            this.pnlPopupIcon.Location = new System.Drawing.Point(21, 12);
            this.pnlPopupIcon.Name = "pnlPopupIcon";
            this.pnlPopupIcon.Size = new System.Drawing.Size(100, 100);
            this.pnlPopupIcon.TabIndex = 7;
            // 
            // frmPopup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(144, 150);
            this.Controls.Add(this.pnlTitlebar);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmPopup";
            this.Tag = "Popup";
            this.Text = "frmPopup";
            this.Load += new System.EventHandler(this.frmPopup_Load);
            this.Shown += new System.EventHandler(this.frmPopup_Shown);
            this.pnlTitlebar.ResumeLayout(false);
            this.pnlTitlebar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitlebar;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Panel pnlPopupIcon;
    }
}