﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmServiceDepartment : Form
    {
        private int click = 0;
        private string frmState = "";
        private UIManager uim;
        private DataHandler dhl = new DataHandler();
        private List<ListBox> btnLsts = new List<ListBox>();
        private string[] arrTechnician = { "All", "Create", "Message" };
        private string[] arrWorkRequest = { "All", "Create" };
        public frmServiceDepartment()
        {
            InitializeComponent();
        }
        private void frmServiceDepartment_Load(object sender, EventArgs e)
        {
            foreach (Control cntrl in pnlButtons.Controls)
            {
                if (cntrl is ListBox lst) { btnLsts.Add(lst); }
            }
            uim = new UIManager(this, pnlTitleBar, picExit, pnlButtons, btnLsts, dgvServiceDepartment, cmbSearch, txtSearch);
            uim.dgvTemplate(dgvServiceDepartment);
            dhl.LoadTechnicianData(dgvServiceDepartment);
            UIManager.dgvState = "Technician";
            ActiveControl = picTitleIcon;
            uim.RegisterControlEvents();
        }
        private void picExit_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmHome");
        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            uim.Search(txtSearch.Text, cmbSearch.Text);
        }
        private void btnTechnician_Click_1(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnTechnician, pnlButtons);
            uim.SetListState(lstTechnician, arrTechnician, btnTechnician);
        }
        private void btnWorkRequest_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnWorkRequest, pnlButtons);
            uim.SetListState(lstWorkRequest, arrWorkRequest, btnWorkRequest);
        }
    }
}
