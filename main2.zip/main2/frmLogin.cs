﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmLogin : Form
    {
        private UIManager uim;
        private string plhUser = "Username", plhPass = "Password";
        public frmLogin()
        {
            InitializeComponent();
            uim = new UIManager(this);
            InitializePlaceholder(txtUsername, plhUser);
            InitializePlaceholder(txtPassword, plhPass);
            txtUsername.Enter += RemovePlaceholder;
            txtUsername.Leave += SetPlaceholder;
            txtPassword.Enter += RemovePlaceholder;
            txtPassword.Leave += SetPlaceholder;
        }
        private void frmLogin_Load(object sender, EventArgs e)
        {
            ActiveControl = picAccount;
            picBackground.Image = Image.FromFile(uim.ImagePath("background2.gif"));
            picBackground.SizeMode = PictureBoxSizeMode.StretchImage;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            if (LoginManager.lm.Login(username, password))
            {
                Hide();
                uim.ShowForm("Main.frmHome");
            }
            else MessageBox.Show("Login failed.");
        }
        private void SetPlaceholder(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb == txtUsername && tb.Text == "")
            {
                tb.Text = plhUser;
                tb.ForeColor = Color.Gray;
            }
            else if (tb == txtPassword && tb.Text == "")
            {
                tb.Text = plhPass;
                tb.ForeColor = Color.Gray;
                tb.PasswordChar = '\0';
            }
        }

        private void RemovePlaceholder(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb == txtUsername && tb.Text == plhUser)
            {
                tb.Text = "";
                tb.ForeColor = Color.Black;
            }
            else if (tb == txtPassword && tb.Text == plhPass)
            {
                tb.Text = "";
                tb.ForeColor = Color.Black;
                tb.PasswordChar = '●';
            }
        }

        private void pnlAccount_Click(object sender, EventArgs e)
        {
            ActiveControl = pnlAccount;
        }

        private void InitializePlaceholder(TextBox tb, string placeholderText)
        {
            tb.Text = placeholderText;
            tb.ForeColor = Color.Gray;
        }
    }
}
