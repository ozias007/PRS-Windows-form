﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Main
{
    public partial class frmPopup : Form
    {
        public string endTime = "";
        private UIManager uim;
        private System.Timers.Timer callDuration = new System.Timers.Timer();
        private int[,] arrTimer = new int[1, 6] { { 0, 0, 0, 0, 0, 0 } };
        public frmPopup()
        {
            InitializeComponent();
        }

        private void frmPopup_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, pnlTitlebar);
            uim.RegisterControlEvents();
        }

        private void frmPopup_Shown(object sender, EventArgs e)
        {
            callDuration.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            callDuration.Interval = 1000;
            callDuration.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            endTime = lblTimer.Text;
            if (lblTimer.Text == "00:00:00")
            {
                Thread.Sleep(1000);
            }
            callDuration.Enabled = false;
            callDuration.Elapsed -= new ElapsedEventHandler(OnTimedEvent);
            for (int i = 0; i < arrTimer.Length; i++)
            {
                arrTimer[0, i] = 0;
            }
            MessageBox.Show(endTime);
            Hide();
        }

        delegate void SetValue(string val);
        private void SetTimerText(string val)
        {
            if (lblTimer.InvokeRequired)
            {
                SetValue sv = new SetValue(SetTimerText);
                Invoke(sv, new object[] { val });
            }
            else lblTimer.Text = val;
        }
        public void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            int a, b, c, d, k, f;
            a = arrTimer[0, 0];
            b = arrTimer[0, 1];
            c = arrTimer[0, 2];
            d = arrTimer[0, 3];
            k = arrTimer[0, 4];
            f = arrTimer[0, 5];
            if (f == 9)
            {
                if (k == 5)
                {
                    if (d == 9)
                    {
                        if (c == 5)
                        {
                            if (b == 9)
                            {
                                if (a == 9)
                                {
                                    a = 0;
                                }
                                else a++;
                                b = 0;
                            }
                            else b++;
                            c = 0;
                        }
                        else c++;
                        d = 0;
                    }
                    else d++;
                    k = 0;
                }
                else k++;
                f = 0;
            }
            else f++;
            arrTimer[0, 0] = a;
            arrTimer[0, 1] = b;
            arrTimer[0, 2] = c;
            arrTimer[0, 3] = d;
            arrTimer[0, 4] = k;
            arrTimer[0, 5] = f;
            SetTimerText(a.ToString() + b.ToString() + ":" + c.ToString() + d.ToString() + ":" + k.ToString() + f.ToString());
        }
    }
}
