﻿namespace Main
{
    partial class frmContractMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmContractMaintenance));
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.lstService = new System.Windows.Forms.ListBox();
            this.picService = new System.Windows.Forms.PictureBox();
            this.btnService = new System.Windows.Forms.Button();
            this.lstServicePackage = new System.Windows.Forms.ListBox();
            this.picServicePackage = new System.Windows.Forms.PictureBox();
            this.btnServicePackage = new System.Windows.Forms.Button();
            this.picTitleIcon = new System.Windows.Forms.PictureBox();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.dgvContractMaintenance = new System.Windows.Forms.DataGridView();
            this.lstSLA = new System.Windows.Forms.ListBox();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.picSLA = new System.Windows.Forms.PictureBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSLA = new System.Windows.Forms.Button();
            this.lstServiceContract = new System.Windows.Forms.ListBox();
            this.picServiceContract = new System.Windows.Forms.PictureBox();
            this.btnServiceContract = new System.Windows.Forms.Button();
            this.cmbSearch = new System.Windows.Forms.ComboBox();
            this.pnlButtons = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.picService)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServicePackage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractMaintenance)).BeginInit();
            this.pnlTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceContract)).BeginInit();
            this.pnlButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtTitle
            // 
            this.txtTitle.BackColor = System.Drawing.Color.Black;
            this.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTitle.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtTitle.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitle.ForeColor = System.Drawing.Color.White;
            this.txtTitle.Location = new System.Drawing.Point(47, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(308, 39);
            this.txtTitle.TabIndex = 2;
            this.txtTitle.Text = "Contract Maintenance";
            this.txtTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lstService
            // 
            this.lstService.FormattingEnabled = true;
            this.lstService.ItemHeight = 15;
            this.lstService.Location = new System.Drawing.Point(78, 11);
            this.lstService.Name = "lstService";
            this.lstService.Size = new System.Drawing.Size(22, 4);
            this.lstService.TabIndex = 116;
            this.lstService.Tag = "Service";
            this.lstService.Visible = false;
            // 
            // picService
            // 
            this.picService.BackColor = System.Drawing.Color.White;
            this.picService.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picService.BackgroundImage")));
            this.picService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picService.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picService.Enabled = false;
            this.picService.Location = new System.Drawing.Point(106, 11);
            this.picService.Name = "picService";
            this.picService.Size = new System.Drawing.Size(22, 22);
            this.picService.TabIndex = 118;
            this.picService.TabStop = false;
            this.picService.Tag = "Service";
            // 
            // btnService
            // 
            this.btnService.BackColor = System.Drawing.Color.White;
            this.btnService.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnService.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnService.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnService.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnService.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnService.ForeColor = System.Drawing.Color.Black;
            this.btnService.Location = new System.Drawing.Point(4, 5);
            this.btnService.Name = "btnService";
            this.btnService.Size = new System.Drawing.Size(132, 35);
            this.btnService.TabIndex = 117;
            this.btnService.Tag = "Service";
            this.btnService.Text = "Service";
            this.btnService.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnService.UseVisualStyleBackColor = false;
            this.btnService.Click += new System.EventHandler(this.btnService_Click);
            // 
            // lstServicePackage
            // 
            this.lstServicePackage.FormattingEnabled = true;
            this.lstServicePackage.ItemHeight = 15;
            this.lstServicePackage.Location = new System.Drawing.Point(78, 52);
            this.lstServicePackage.Name = "lstServicePackage";
            this.lstServicePackage.Size = new System.Drawing.Size(22, 4);
            this.lstServicePackage.TabIndex = 115;
            this.lstServicePackage.Tag = "ServicePackage";
            this.lstServicePackage.Visible = false;
            // 
            // picServicePackage
            // 
            this.picServicePackage.BackColor = System.Drawing.Color.White;
            this.picServicePackage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picServicePackage.BackgroundImage")));
            this.picServicePackage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picServicePackage.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picServicePackage.Enabled = false;
            this.picServicePackage.Location = new System.Drawing.Point(106, 52);
            this.picServicePackage.Name = "picServicePackage";
            this.picServicePackage.Size = new System.Drawing.Size(22, 22);
            this.picServicePackage.TabIndex = 114;
            this.picServicePackage.TabStop = false;
            this.picServicePackage.Tag = "ServicePackage";
            // 
            // btnServicePackage
            // 
            this.btnServicePackage.BackColor = System.Drawing.Color.White;
            this.btnServicePackage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnServicePackage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServicePackage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnServicePackage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnServicePackage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServicePackage.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServicePackage.ForeColor = System.Drawing.Color.Black;
            this.btnServicePackage.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnServicePackage.Location = new System.Drawing.Point(4, 46);
            this.btnServicePackage.Name = "btnServicePackage";
            this.btnServicePackage.Size = new System.Drawing.Size(132, 35);
            this.btnServicePackage.TabIndex = 113;
            this.btnServicePackage.Tag = "ServicePackage";
            this.btnServicePackage.Text = "Package";
            this.btnServicePackage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServicePackage.UseVisualStyleBackColor = false;
            this.btnServicePackage.Click += new System.EventHandler(this.btnServicePackage_Click);
            // 
            // picTitleIcon
            // 
            this.picTitleIcon.BackColor = System.Drawing.Color.Black;
            this.picTitleIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picTitleIcon.BackgroundImage")));
            this.picTitleIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picTitleIcon.Location = new System.Drawing.Point(13, 10);
            this.picTitleIcon.Name = "picTitleIcon";
            this.picTitleIcon.Size = new System.Drawing.Size(30, 30);
            this.picTitleIcon.TabIndex = 51;
            this.picTitleIcon.TabStop = false;
            // 
            // picExit
            // 
            this.picExit.BackColor = System.Drawing.Color.Transparent;
            this.picExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picExit.BackgroundImage")));
            this.picExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExit.Location = new System.Drawing.Point(949, 9);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(24, 30);
            this.picExit.TabIndex = 1;
            this.picExit.TabStop = false;
            this.picExit.Tag = "Exit";
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(687, 70);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(50, 17);
            this.lblSearch.TabIndex = 65;
            this.lblSearch.Tag = "";
            this.lblSearch.Text = "Search:";
            // 
            // dgvContractMaintenance
            // 
            this.dgvContractMaintenance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContractMaintenance.Location = new System.Drawing.Point(154, 95);
            this.dgvContractMaintenance.Name = "dgvContractMaintenance";
            this.dgvContractMaintenance.Size = new System.Drawing.Size(834, 493);
            this.dgvContractMaintenance.TabIndex = 64;
            // 
            // lstSLA
            // 
            this.lstSLA.FormattingEnabled = true;
            this.lstSLA.ItemHeight = 15;
            this.lstSLA.Location = new System.Drawing.Point(78, 93);
            this.lstSLA.Name = "lstSLA";
            this.lstSLA.Size = new System.Drawing.Size(22, 4);
            this.lstSLA.TabIndex = 107;
            this.lstSLA.Tag = "SLA";
            this.lstSLA.Visible = false;
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.Black;
            this.pnlTitleBar.Controls.Add(this.picTitleIcon);
            this.pnlTitleBar.Controls.Add(this.txtTitle);
            this.pnlTitleBar.Controls.Add(this.picExit);
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(1000, 50);
            this.pnlTitleBar.TabIndex = 63;
            this.pnlTitleBar.Tag = "TitleBar";
            // 
            // picSLA
            // 
            this.picSLA.BackColor = System.Drawing.Color.White;
            this.picSLA.BackgroundImage = global::Main.Properties.Resources.sla;
            this.picSLA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSLA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picSLA.Enabled = false;
            this.picSLA.Location = new System.Drawing.Point(106, 93);
            this.picSLA.Name = "picSLA";
            this.picSLA.Size = new System.Drawing.Size(22, 22);
            this.picSLA.TabIndex = 109;
            this.picSLA.TabStop = false;
            this.picSLA.Tag = "SLA";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(849, 68);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(139, 21);
            this.txtSearch.TabIndex = 67;
            this.txtSearch.Tag = "Search";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnSLA
            // 
            this.btnSLA.BackColor = System.Drawing.Color.White;
            this.btnSLA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSLA.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnSLA.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnSLA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSLA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSLA.ForeColor = System.Drawing.Color.Black;
            this.btnSLA.Location = new System.Drawing.Point(4, 87);
            this.btnSLA.Name = "btnSLA";
            this.btnSLA.Size = new System.Drawing.Size(132, 35);
            this.btnSLA.TabIndex = 108;
            this.btnSLA.Tag = "SLA";
            this.btnSLA.Text = "SLA";
            this.btnSLA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSLA.UseVisualStyleBackColor = false;
            this.btnSLA.Click += new System.EventHandler(this.btnSLA_Click);
            // 
            // lstServiceContract
            // 
            this.lstServiceContract.FormattingEnabled = true;
            this.lstServiceContract.ItemHeight = 15;
            this.lstServiceContract.Location = new System.Drawing.Point(78, 134);
            this.lstServiceContract.Name = "lstServiceContract";
            this.lstServiceContract.Size = new System.Drawing.Size(22, 4);
            this.lstServiceContract.TabIndex = 104;
            this.lstServiceContract.Tag = "ServiceContract";
            this.lstServiceContract.Visible = false;
            // 
            // picServiceContract
            // 
            this.picServiceContract.BackColor = System.Drawing.Color.White;
            this.picServiceContract.BackgroundImage = global::Main.Properties.Resources.icons8_contract_50;
            this.picServiceContract.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picServiceContract.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picServiceContract.Enabled = false;
            this.picServiceContract.Location = new System.Drawing.Point(106, 134);
            this.picServiceContract.Name = "picServiceContract";
            this.picServiceContract.Size = new System.Drawing.Size(22, 22);
            this.picServiceContract.TabIndex = 106;
            this.picServiceContract.TabStop = false;
            this.picServiceContract.Tag = "ServiceContract";
            // 
            // btnServiceContract
            // 
            this.btnServiceContract.BackColor = System.Drawing.Color.White;
            this.btnServiceContract.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServiceContract.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnServiceContract.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnServiceContract.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServiceContract.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceContract.ForeColor = System.Drawing.Color.Black;
            this.btnServiceContract.Location = new System.Drawing.Point(4, 128);
            this.btnServiceContract.Name = "btnServiceContract";
            this.btnServiceContract.Size = new System.Drawing.Size(132, 35);
            this.btnServiceContract.TabIndex = 105;
            this.btnServiceContract.Tag = "ServiceContract";
            this.btnServiceContract.Text = "Contract";
            this.btnServiceContract.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServiceContract.UseVisualStyleBackColor = false;
            this.btnServiceContract.Click += new System.EventHandler(this.btnServiceContract_Click);
            // 
            // cmbSearch
            // 
            this.cmbSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearch.FormattingEnabled = true;
            this.cmbSearch.Location = new System.Drawing.Point(743, 68);
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(100, 21);
            this.cmbSearch.TabIndex = 66;
            this.cmbSearch.Tag = "Search";
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.lstService);
            this.pnlButtons.Controls.Add(this.picService);
            this.pnlButtons.Controls.Add(this.btnService);
            this.pnlButtons.Controls.Add(this.lstServicePackage);
            this.pnlButtons.Controls.Add(this.picServicePackage);
            this.pnlButtons.Controls.Add(this.btnServicePackage);
            this.pnlButtons.Controls.Add(this.lstSLA);
            this.pnlButtons.Controls.Add(this.picSLA);
            this.pnlButtons.Controls.Add(this.btnSLA);
            this.pnlButtons.Controls.Add(this.lstServiceContract);
            this.pnlButtons.Controls.Add(this.picServiceContract);
            this.pnlButtons.Controls.Add(this.btnServiceContract);
            this.pnlButtons.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlButtons.Location = new System.Drawing.Point(0, 49);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(142, 551);
            this.pnlButtons.TabIndex = 62;
            // 
            // frmContractMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.dgvContractMaintenance);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.cmbSearch);
            this.Controls.Add(this.pnlButtons);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmContractMaintenance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmContractMaintenance";
            this.Load += new System.EventHandler(this.frmContractMaintenance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picService)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServicePackage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractMaintenance)).EndInit();
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceContract)).EndInit();
            this.pnlButtons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.ListBox lstService;
        private System.Windows.Forms.PictureBox picService;
        private System.Windows.Forms.Button btnService;
        private System.Windows.Forms.ListBox lstServicePackage;
        private System.Windows.Forms.PictureBox picServicePackage;
        private System.Windows.Forms.Button btnServicePackage;
        private System.Windows.Forms.PictureBox picTitleIcon;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.DataGridView dgvContractMaintenance;
        private System.Windows.Forms.ListBox lstSLA;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.PictureBox picSLA;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSLA;
        private System.Windows.Forms.ListBox lstServiceContract;
        private System.Windows.Forms.PictureBox picServiceContract;
        private System.Windows.Forms.Button btnServiceContract;
        private System.Windows.Forms.ComboBox cmbSearch;
        private System.Windows.Forms.Panel pnlButtons;
    }
}