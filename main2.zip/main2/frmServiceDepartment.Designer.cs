﻿namespace Main
{
    partial class frmServiceDepartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServiceDepartment));
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.lstWorkRequest = new System.Windows.Forms.ListBox();
            this.lstTechnician = new System.Windows.Forms.ListBox();
            this.btnTechnician = new System.Windows.Forms.Button();
            this.btnWorkRequest = new System.Windows.Forms.Button();
            this.dgvServiceDepartment = new System.Windows.Forms.DataGridView();
            this.lblSearch = new System.Windows.Forms.Label();
            this.cmbSearch = new System.Windows.Forms.ComboBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.picTitleIcon = new System.Windows.Forms.PictureBox();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.picTechnician = new System.Windows.Forms.PictureBox();
            this.picWorkRequest = new System.Windows.Forms.PictureBox();
            this.pnlTitleBar.SuspendLayout();
            this.pnlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServiceDepartment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTechnician)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWorkRequest)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.Black;
            this.pnlTitleBar.Controls.Add(this.picTitleIcon);
            this.pnlTitleBar.Controls.Add(this.txtTitle);
            this.pnlTitleBar.Controls.Add(this.picExit);
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(1000, 50);
            this.pnlTitleBar.TabIndex = 50;
            // 
            // txtTitle
            // 
            this.txtTitle.BackColor = System.Drawing.Color.Black;
            this.txtTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTitle.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtTitle.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitle.ForeColor = System.Drawing.Color.White;
            this.txtTitle.Location = new System.Drawing.Point(49, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(282, 39);
            this.txtTitle.TabIndex = 2;
            this.txtTitle.Text = "Service Department";
            this.txtTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.lstWorkRequest);
            this.pnlButtons.Controls.Add(this.lstTechnician);
            this.pnlButtons.Controls.Add(this.picTechnician);
            this.pnlButtons.Controls.Add(this.picWorkRequest);
            this.pnlButtons.Controls.Add(this.btnTechnician);
            this.pnlButtons.Controls.Add(this.btnWorkRequest);
            this.pnlButtons.Location = new System.Drawing.Point(0, 49);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(142, 551);
            this.pnlButtons.TabIndex = 49;
            // 
            // lstWorkRequest
            // 
            this.lstWorkRequest.FormattingEnabled = true;
            this.lstWorkRequest.Location = new System.Drawing.Point(78, 11);
            this.lstWorkRequest.Name = "lstWorkRequest";
            this.lstWorkRequest.Size = new System.Drawing.Size(22, 17);
            this.lstWorkRequest.TabIndex = 89;
            this.lstWorkRequest.Tag = "WorkRequest";
            this.lstWorkRequest.Visible = false;
            // 
            // lstTechnician
            // 
            this.lstTechnician.FormattingEnabled = true;
            this.lstTechnician.Location = new System.Drawing.Point(78, 52);
            this.lstTechnician.Name = "lstTechnician";
            this.lstTechnician.Size = new System.Drawing.Size(22, 17);
            this.lstTechnician.TabIndex = 84;
            this.lstTechnician.Tag = "Technician";
            this.lstTechnician.Visible = false;
            // 
            // btnTechnician
            // 
            this.btnTechnician.BackColor = System.Drawing.Color.White;
            this.btnTechnician.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTechnician.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnTechnician.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnTechnician.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTechnician.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTechnician.ForeColor = System.Drawing.Color.Black;
            this.btnTechnician.Location = new System.Drawing.Point(4, 46);
            this.btnTechnician.Name = "btnTechnician";
            this.btnTechnician.Size = new System.Drawing.Size(132, 35);
            this.btnTechnician.TabIndex = 86;
            this.btnTechnician.Tag = "Technician";
            this.btnTechnician.Text = "Technician";
            this.btnTechnician.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTechnician.UseVisualStyleBackColor = false;
            this.btnTechnician.Click += new System.EventHandler(this.btnTechnician_Click_1);
            // 
            // btnWorkRequest
            // 
            this.btnWorkRequest.BackColor = System.Drawing.Color.White;
            this.btnWorkRequest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnWorkRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWorkRequest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnWorkRequest.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnWorkRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWorkRequest.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkRequest.ForeColor = System.Drawing.Color.Black;
            this.btnWorkRequest.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnWorkRequest.Location = new System.Drawing.Point(4, 5);
            this.btnWorkRequest.Name = "btnWorkRequest";
            this.btnWorkRequest.Size = new System.Drawing.Size(132, 35);
            this.btnWorkRequest.TabIndex = 85;
            this.btnWorkRequest.Tag = "WorkRequest";
            this.btnWorkRequest.Text = "Request";
            this.btnWorkRequest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnWorkRequest.UseVisualStyleBackColor = false;
            this.btnWorkRequest.Click += new System.EventHandler(this.btnWorkRequest_Click);
            // 
            // dgvServiceDepartment
            // 
            this.dgvServiceDepartment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServiceDepartment.Location = new System.Drawing.Point(154, 95);
            this.dgvServiceDepartment.Name = "dgvServiceDepartment";
            this.dgvServiceDepartment.Size = new System.Drawing.Size(834, 493);
            this.dgvServiceDepartment.TabIndex = 51;
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.Location = new System.Drawing.Point(687, 70);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(50, 17);
            this.lblSearch.TabIndex = 52;
            this.lblSearch.Tag = "";
            this.lblSearch.Text = "Search:";
            // 
            // cmbSearch
            // 
            this.cmbSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSearch.FormattingEnabled = true;
            this.cmbSearch.Location = new System.Drawing.Point(743, 68);
            this.cmbSearch.Name = "cmbSearch";
            this.cmbSearch.Size = new System.Drawing.Size(100, 21);
            this.cmbSearch.TabIndex = 53;
            this.cmbSearch.Tag = "Search";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(849, 68);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(139, 21);
            this.txtSearch.TabIndex = 55;
            this.txtSearch.Tag = "Search";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // picTitleIcon
            // 
            this.picTitleIcon.BackColor = System.Drawing.Color.Black;
            this.picTitleIcon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picTitleIcon.BackgroundImage")));
            this.picTitleIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picTitleIcon.Location = new System.Drawing.Point(13, 10);
            this.picTitleIcon.Name = "picTitleIcon";
            this.picTitleIcon.Size = new System.Drawing.Size(30, 30);
            this.picTitleIcon.TabIndex = 51;
            this.picTitleIcon.TabStop = false;
            // 
            // picExit
            // 
            this.picExit.BackColor = System.Drawing.Color.Transparent;
            this.picExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picExit.BackgroundImage")));
            this.picExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExit.Location = new System.Drawing.Point(949, 9);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(24, 30);
            this.picExit.TabIndex = 1;
            this.picExit.TabStop = false;
            this.picExit.Tag = "Exit";
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // picTechnician
            // 
            this.picTechnician.BackColor = System.Drawing.Color.White;
            this.picTechnician.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picTechnician.BackgroundImage")));
            this.picTechnician.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picTechnician.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picTechnician.Enabled = false;
            this.picTechnician.Location = new System.Drawing.Point(106, 52);
            this.picTechnician.Name = "picTechnician";
            this.picTechnician.Size = new System.Drawing.Size(22, 22);
            this.picTechnician.TabIndex = 88;
            this.picTechnician.TabStop = false;
            this.picTechnician.Tag = "Technician";
            // 
            // picWorkRequest
            // 
            this.picWorkRequest.BackColor = System.Drawing.Color.White;
            this.picWorkRequest.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picWorkRequest.BackgroundImage")));
            this.picWorkRequest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picWorkRequest.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.picWorkRequest.Enabled = false;
            this.picWorkRequest.Location = new System.Drawing.Point(106, 11);
            this.picWorkRequest.Name = "picWorkRequest";
            this.picWorkRequest.Size = new System.Drawing.Size(22, 22);
            this.picWorkRequest.TabIndex = 87;
            this.picWorkRequest.TabStop = false;
            this.picWorkRequest.Tag = "WorkRequest";
            // 
            // frmServiceDepartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.cmbSearch);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.dgvServiceDepartment);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlButtons);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmServiceDepartment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "ServiceDepartment";
            this.Text = "frmServiceDepartment";
            this.Load += new System.EventHandler(this.frmServiceDepartment_Load);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServiceDepartment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTitleIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTechnician)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picWorkRequest)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.PictureBox picTitleIcon;
        private System.Windows.Forms.DataGridView dgvServiceDepartment;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ComboBox cmbSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ListBox lstWorkRequest;
        private System.Windows.Forms.ListBox lstTechnician;
        private System.Windows.Forms.PictureBox picTechnician;
        private System.Windows.Forms.PictureBox picWorkRequest;
        private System.Windows.Forms.Button btnTechnician;
        private System.Windows.Forms.Button btnWorkRequest;
    }
}