﻿namespace Main
{
    partial class frmServiceContract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServiceContract));
            this.dtpEffectDate = new System.Windows.Forms.DateTimePicker();
            this.lblEffectDate = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.lblCategory = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblServiceContractTitle = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtContractID = new System.Windows.Forms.TextBox();
            this.lblContractID = new System.Windows.Forms.Label();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.pnlControls = new System.Windows.Forms.Panel();
            this.rtbDetails = new System.Windows.Forms.RichTextBox();
            this.dtpPurchaseDate = new System.Windows.Forms.DateTimePicker();
            this.lblPurchaseDate = new System.Windows.Forms.Label();
            this.dtpExpiryDate = new System.Windows.Forms.DateTimePicker();
            this.lblExpiryDate = new System.Windows.Forms.Label();
            this.cmbClientID = new System.Windows.Forms.ComboBox();
            this.lblClientID = new System.Windows.Forms.Label();
            this.cmbPackageID = new System.Windows.Forms.ComboBox();
            this.lblPackageID = new System.Windows.Forms.Label();
            this.cmbSlaID = new System.Windows.Forms.ComboBox();
            this.lblSlaID = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.pnlTitleBar.SuspendLayout();
            this.pnlControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpEffectDate
            // 
            this.dtpEffectDate.Enabled = false;
            this.dtpEffectDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEffectDate.Location = new System.Drawing.Point(115, 99);
            this.dtpEffectDate.Name = "dtpEffectDate";
            this.dtpEffectDate.Size = new System.Drawing.Size(100, 22);
            this.dtpEffectDate.TabIndex = 111;
            this.dtpEffectDate.Tag = "EffectDate";
            // 
            // lblEffectDate
            // 
            this.lblEffectDate.AutoSize = true;
            this.lblEffectDate.Enabled = false;
            this.lblEffectDate.Location = new System.Drawing.Point(112, 85);
            this.lblEffectDate.Name = "lblEffectDate";
            this.lblEffectDate.Size = new System.Drawing.Size(66, 13);
            this.lblEffectDate.TabIndex = 110;
            this.lblEffectDate.Tag = "";
            this.lblEffectDate.Text = "Effect Date:";
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Enabled = false;
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "General",
            "Mechanical",
            "Electrical"});
            this.cmbCategory.Location = new System.Drawing.Point(115, 19);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(100, 21);
            this.cmbCategory.TabIndex = 107;
            this.cmbCategory.Tag = "Category";
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Enabled = false;
            this.lblCategory.Location = new System.Drawing.Point(112, 5);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(56, 13);
            this.lblCategory.TabIndex = 106;
            this.lblCategory.Tag = "";
            this.lblCategory.Text = "Category:";
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.Enabled = false;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "Inactive",
            "Open",
            "Closed"});
            this.cmbStatus.Location = new System.Drawing.Point(221, 19);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(100, 21);
            this.cmbStatus.TabIndex = 74;
            this.cmbStatus.Tag = "Status";
            // 
            // lblServiceContractTitle
            // 
            this.lblServiceContractTitle.AutoSize = true;
            this.lblServiceContractTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceContractTitle.Location = new System.Drawing.Point(3, 4);
            this.lblServiceContractTitle.Name = "lblServiceContractTitle";
            this.lblServiceContractTitle.Size = new System.Drawing.Size(86, 25);
            this.lblServiceContractTitle.TabIndex = 6;
            this.lblServiceContractTitle.Tag = "";
            this.lblServiceContractTitle.Text = "Contract";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Enabled = false;
            this.lblStatus.Location = new System.Drawing.Point(217, 5);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(42, 13);
            this.lblStatus.TabIndex = 68;
            this.lblStatus.Tag = "";
            this.lblStatus.Text = "Status:";
            // 
            // txtContractID
            // 
            this.txtContractID.Enabled = false;
            this.txtContractID.Location = new System.Drawing.Point(9, 19);
            this.txtContractID.Name = "txtContractID";
            this.txtContractID.Size = new System.Drawing.Size(100, 22);
            this.txtContractID.TabIndex = 54;
            this.txtContractID.Tag = "ContractID";
            // 
            // lblContractID
            // 
            this.lblContractID.AutoSize = true;
            this.lblContractID.Enabled = false;
            this.lblContractID.Location = new System.Drawing.Point(5, 5);
            this.lblContractID.Name = "lblContractID";
            this.lblContractID.Size = new System.Drawing.Size(68, 13);
            this.lblContractID.TabIndex = 51;
            this.lblContractID.Tag = "";
            this.lblContractID.Text = "Contract ID:";
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.DimGray;
            this.pnlTitleBar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTitleBar.Controls.Add(this.lblServiceContractTitle);
            this.pnlTitleBar.ForeColor = System.Drawing.Color.White;
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(330, 35);
            this.pnlTitleBar.TabIndex = 18;
            // 
            // pnlControls
            // 
            this.pnlControls.BackColor = System.Drawing.Color.White;
            this.pnlControls.Controls.Add(this.rtbDetails);
            this.pnlControls.Controls.Add(this.dtpPurchaseDate);
            this.pnlControls.Controls.Add(this.lblPurchaseDate);
            this.pnlControls.Controls.Add(this.dtpExpiryDate);
            this.pnlControls.Controls.Add(this.lblExpiryDate);
            this.pnlControls.Controls.Add(this.cmbClientID);
            this.pnlControls.Controls.Add(this.lblClientID);
            this.pnlControls.Controls.Add(this.cmbPackageID);
            this.pnlControls.Controls.Add(this.lblPackageID);
            this.pnlControls.Controls.Add(this.cmbSlaID);
            this.pnlControls.Controls.Add(this.lblSlaID);
            this.pnlControls.Controls.Add(this.lblDetails);
            this.pnlControls.Controls.Add(this.dtpEffectDate);
            this.pnlControls.Controls.Add(this.lblEffectDate);
            this.pnlControls.Controls.Add(this.cmbCategory);
            this.pnlControls.Controls.Add(this.lblCategory);
            this.pnlControls.Controls.Add(this.cmbStatus);
            this.pnlControls.Controls.Add(this.btnCancel);
            this.pnlControls.Controls.Add(this.btnConfirm);
            this.pnlControls.Controls.Add(this.lblStatus);
            this.pnlControls.Controls.Add(this.txtContractID);
            this.pnlControls.Controls.Add(this.lblContractID);
            this.pnlControls.Location = new System.Drawing.Point(0, 35);
            this.pnlControls.Name = "pnlControls";
            this.pnlControls.Size = new System.Drawing.Size(330, 275);
            this.pnlControls.TabIndex = 19;
            this.pnlControls.Tag = "Controls";
            // 
            // rtbDetails
            // 
            this.rtbDetails.Enabled = false;
            this.rtbDetails.Location = new System.Drawing.Point(9, 139);
            this.rtbDetails.Name = "rtbDetails";
            this.rtbDetails.Size = new System.Drawing.Size(312, 102);
            this.rtbDetails.TabIndex = 158;
            this.rtbDetails.Tag = "Details";
            this.rtbDetails.Text = "";
            // 
            // dtpPurchaseDate
            // 
            this.dtpPurchaseDate.Enabled = false;
            this.dtpPurchaseDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPurchaseDate.Location = new System.Drawing.Point(9, 99);
            this.dtpPurchaseDate.Name = "dtpPurchaseDate";
            this.dtpPurchaseDate.Size = new System.Drawing.Size(100, 22);
            this.dtpPurchaseDate.TabIndex = 157;
            this.dtpPurchaseDate.Tag = "PurchaseDate";
            // 
            // lblPurchaseDate
            // 
            this.lblPurchaseDate.AutoSize = true;
            this.lblPurchaseDate.Enabled = false;
            this.lblPurchaseDate.Location = new System.Drawing.Point(6, 85);
            this.lblPurchaseDate.Name = "lblPurchaseDate";
            this.lblPurchaseDate.Size = new System.Drawing.Size(83, 13);
            this.lblPurchaseDate.TabIndex = 156;
            this.lblPurchaseDate.Tag = "";
            this.lblPurchaseDate.Text = "Purchase Date:";
            // 
            // dtpExpiryDate
            // 
            this.dtpExpiryDate.Enabled = false;
            this.dtpExpiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpExpiryDate.Location = new System.Drawing.Point(221, 99);
            this.dtpExpiryDate.Name = "dtpExpiryDate";
            this.dtpExpiryDate.Size = new System.Drawing.Size(100, 22);
            this.dtpExpiryDate.TabIndex = 155;
            this.dtpExpiryDate.Tag = "ExpiryDate";
            // 
            // lblExpiryDate
            // 
            this.lblExpiryDate.AutoSize = true;
            this.lblExpiryDate.Enabled = false;
            this.lblExpiryDate.Location = new System.Drawing.Point(218, 85);
            this.lblExpiryDate.Name = "lblExpiryDate";
            this.lblExpiryDate.Size = new System.Drawing.Size(67, 13);
            this.lblExpiryDate.TabIndex = 154;
            this.lblExpiryDate.Tag = "";
            this.lblExpiryDate.Text = "Expiry Date:";
            // 
            // cmbClientID
            // 
            this.cmbClientID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClientID.Enabled = false;
            this.cmbClientID.FormattingEnabled = true;
            this.cmbClientID.Items.AddRange(new object[] {
            "0"});
            this.cmbClientID.Location = new System.Drawing.Point(9, 59);
            this.cmbClientID.Name = "cmbClientID";
            this.cmbClientID.Size = new System.Drawing.Size(100, 21);
            this.cmbClientID.TabIndex = 153;
            this.cmbClientID.Tag = "ClientID";
            // 
            // lblClientID
            // 
            this.lblClientID.AutoSize = true;
            this.lblClientID.Enabled = false;
            this.lblClientID.Location = new System.Drawing.Point(6, 45);
            this.lblClientID.Name = "lblClientID";
            this.lblClientID.Size = new System.Drawing.Size(54, 13);
            this.lblClientID.TabIndex = 152;
            this.lblClientID.Tag = "";
            this.lblClientID.Text = "Client ID:";
            // 
            // cmbPackageID
            // 
            this.cmbPackageID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPackageID.Enabled = false;
            this.cmbPackageID.FormattingEnabled = true;
            this.cmbPackageID.Items.AddRange(new object[] {
            "0"});
            this.cmbPackageID.Location = new System.Drawing.Point(115, 59);
            this.cmbPackageID.Name = "cmbPackageID";
            this.cmbPackageID.Size = new System.Drawing.Size(100, 21);
            this.cmbPackageID.TabIndex = 151;
            this.cmbPackageID.Tag = "PackageID";
            // 
            // lblPackageID
            // 
            this.lblPackageID.AutoSize = true;
            this.lblPackageID.Enabled = false;
            this.lblPackageID.Location = new System.Drawing.Point(112, 45);
            this.lblPackageID.Name = "lblPackageID";
            this.lblPackageID.Size = new System.Drawing.Size(66, 13);
            this.lblPackageID.TabIndex = 150;
            this.lblPackageID.Tag = "";
            this.lblPackageID.Text = "Package ID:";
            // 
            // cmbSlaID
            // 
            this.cmbSlaID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSlaID.Enabled = false;
            this.cmbSlaID.FormattingEnabled = true;
            this.cmbSlaID.Items.AddRange(new object[] {
            "0"});
            this.cmbSlaID.Location = new System.Drawing.Point(221, 59);
            this.cmbSlaID.Name = "cmbSlaID";
            this.cmbSlaID.Size = new System.Drawing.Size(100, 21);
            this.cmbSlaID.TabIndex = 149;
            this.cmbSlaID.Tag = "SlaID";
            // 
            // lblSlaID
            // 
            this.lblSlaID.AutoSize = true;
            this.lblSlaID.Enabled = false;
            this.lblSlaID.Location = new System.Drawing.Point(217, 45);
            this.lblSlaID.Name = "lblSlaID";
            this.lblSlaID.Size = new System.Drawing.Size(42, 13);
            this.lblSlaID.TabIndex = 148;
            this.lblSlaID.Tag = "";
            this.lblSlaID.Text = "SLA ID:";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Enabled = false;
            this.lblDetails.Location = new System.Drawing.Point(7, 125);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(45, 13);
            this.lblDetails.TabIndex = 145;
            this.lblDetails.Tag = "";
            this.lblDetails.Text = "Details:";
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Location = new System.Drawing.Point(275, 247);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(20, 20);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Tag = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.BackgroundImage")));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.FlatAppearance.BorderSize = 0;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Location = new System.Drawing.Point(301, 247);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(20, 20);
            this.btnConfirm.TabIndex = 52;
            this.btnConfirm.Tag = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // frmServiceContract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(330, 310);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlControls);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmServiceContract";
            this.Tag = "ServiceContract";
            this.Text = "frmServiceContract";
            this.Load += new System.EventHandler(this.frmServiceContract_Load);
            this.Shown += new System.EventHandler(this.frmServiceContract_Shown);
            this.pnlTitleBar.ResumeLayout(false);
            this.pnlTitleBar.PerformLayout();
            this.pnlControls.ResumeLayout(false);
            this.pnlControls.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtpEffectDate;
        private System.Windows.Forms.Label lblEffectDate;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Label lblServiceContractTitle;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtContractID;
        private System.Windows.Forms.Label lblContractID;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Panel pnlControls;
        private System.Windows.Forms.ComboBox cmbClientID;
        private System.Windows.Forms.Label lblClientID;
        private System.Windows.Forms.ComboBox cmbPackageID;
        private System.Windows.Forms.Label lblPackageID;
        private System.Windows.Forms.ComboBox cmbSlaID;
        private System.Windows.Forms.Label lblSlaID;
        private System.Windows.Forms.DateTimePicker dtpPurchaseDate;
        private System.Windows.Forms.Label lblPurchaseDate;
        private System.Windows.Forms.DateTimePicker dtpExpiryDate;
        private System.Windows.Forms.Label lblExpiryDate;
        private System.Windows.Forms.RichTextBox rtbDetails;
        private System.Windows.Forms.Label lblDetails;
    }
}