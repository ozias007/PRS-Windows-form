﻿namespace Main
{
    partial class frmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHome));
            this.pnlButtons = new System.Windows.Forms.Panel();
            this.picReports = new System.Windows.Forms.PictureBox();
            this.picContractMaintenance = new System.Windows.Forms.PictureBox();
            this.picClientMaintenance = new System.Windows.Forms.PictureBox();
            this.picServiceDepartment = new System.Windows.Forms.PictureBox();
            this.picCallCentre = new System.Windows.Forms.PictureBox();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnContractMaintenance = new System.Windows.Forms.Button();
            this.btnClientMaintenance = new System.Windows.Forms.Button();
            this.btnServiceDepartment = new System.Windows.Forms.Button();
            this.btnCallCentre = new System.Windows.Forms.Button();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.picExit = new System.Windows.Forms.PictureBox();
            this.picPSS = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picNumbers5 = new System.Windows.Forms.PictureBox();
            this.picGraph3 = new System.Windows.Forms.PictureBox();
            this.picGraph1 = new System.Windows.Forms.PictureBox();
            this.picGraph2 = new System.Windows.Forms.PictureBox();
            this.pnlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picReports)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picContractMaintenance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClientMaintenance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceDepartment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCallCentre)).BeginInit();
            this.pnlTitleBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPSS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNumbers5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph2)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlButtons
            // 
            this.pnlButtons.BackColor = System.Drawing.Color.Gainsboro;
            this.pnlButtons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlButtons.Controls.Add(this.picReports);
            this.pnlButtons.Controls.Add(this.picContractMaintenance);
            this.pnlButtons.Controls.Add(this.picClientMaintenance);
            this.pnlButtons.Controls.Add(this.picServiceDepartment);
            this.pnlButtons.Controls.Add(this.picCallCentre);
            this.pnlButtons.Controls.Add(this.btnReports);
            this.pnlButtons.Controls.Add(this.btnContractMaintenance);
            this.pnlButtons.Controls.Add(this.btnClientMaintenance);
            this.pnlButtons.Controls.Add(this.btnServiceDepartment);
            this.pnlButtons.Controls.Add(this.btnCallCentre);
            this.pnlButtons.Location = new System.Drawing.Point(0, 0);
            this.pnlButtons.Name = "pnlButtons";
            this.pnlButtons.Size = new System.Drawing.Size(142, 600);
            this.pnlButtons.TabIndex = 36;
            // 
            // picReports
            // 
            this.picReports.BackColor = System.Drawing.Color.White;
            this.picReports.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picReports.BackgroundImage")));
            this.picReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picReports.Enabled = false;
            this.picReports.Location = new System.Drawing.Point(106, 224);
            this.picReports.Name = "picReports";
            this.picReports.Size = new System.Drawing.Size(22, 22);
            this.picReports.TabIndex = 85;
            this.picReports.TabStop = false;
            this.picReports.Tag = "Reports";
            // 
            // picContractMaintenance
            // 
            this.picContractMaintenance.BackColor = System.Drawing.Color.White;
            this.picContractMaintenance.BackgroundImage = global::Main.Properties.Resources.contract;
            this.picContractMaintenance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picContractMaintenance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picContractMaintenance.Enabled = false;
            this.picContractMaintenance.Location = new System.Drawing.Point(106, 183);
            this.picContractMaintenance.Name = "picContractMaintenance";
            this.picContractMaintenance.Size = new System.Drawing.Size(22, 22);
            this.picContractMaintenance.TabIndex = 84;
            this.picContractMaintenance.TabStop = false;
            this.picContractMaintenance.Tag = "ContractMaintenance";
            // 
            // picClientMaintenance
            // 
            this.picClientMaintenance.BackColor = System.Drawing.Color.White;
            this.picClientMaintenance.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picClientMaintenance.BackgroundImage")));
            this.picClientMaintenance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClientMaintenance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picClientMaintenance.Enabled = false;
            this.picClientMaintenance.Location = new System.Drawing.Point(106, 142);
            this.picClientMaintenance.Name = "picClientMaintenance";
            this.picClientMaintenance.Size = new System.Drawing.Size(22, 22);
            this.picClientMaintenance.TabIndex = 83;
            this.picClientMaintenance.TabStop = false;
            this.picClientMaintenance.Tag = "ClientMaintenance";
            // 
            // picServiceDepartment
            // 
            this.picServiceDepartment.BackColor = System.Drawing.Color.White;
            this.picServiceDepartment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picServiceDepartment.BackgroundImage")));
            this.picServiceDepartment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picServiceDepartment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picServiceDepartment.Enabled = false;
            this.picServiceDepartment.Location = new System.Drawing.Point(106, 101);
            this.picServiceDepartment.Name = "picServiceDepartment";
            this.picServiceDepartment.Size = new System.Drawing.Size(22, 22);
            this.picServiceDepartment.TabIndex = 82;
            this.picServiceDepartment.TabStop = false;
            this.picServiceDepartment.Tag = "ServiceDepartment";
            // 
            // picCallCentre
            // 
            this.picCallCentre.BackColor = System.Drawing.Color.White;
            this.picCallCentre.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picCallCentre.BackgroundImage")));
            this.picCallCentre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCallCentre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picCallCentre.Enabled = false;
            this.picCallCentre.Location = new System.Drawing.Point(106, 60);
            this.picCallCentre.Name = "picCallCentre";
            this.picCallCentre.Size = new System.Drawing.Size(22, 22);
            this.picCallCentre.TabIndex = 81;
            this.picCallCentre.TabStop = false;
            this.picCallCentre.Tag = "CallCentre";
            // 
            // btnReports
            // 
            this.btnReports.BackColor = System.Drawing.Color.White;
            this.btnReports.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReports.Enabled = false;
            this.btnReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReports.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReports.ForeColor = System.Drawing.Color.Black;
            this.btnReports.Location = new System.Drawing.Point(4, 218);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(132, 35);
            this.btnReports.TabIndex = 79;
            this.btnReports.Tag = "Reports";
            this.btnReports.Text = "Reports";
            this.btnReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReports.UseVisualStyleBackColor = false;
            // 
            // btnContractMaintenance
            // 
            this.btnContractMaintenance.BackColor = System.Drawing.Color.White;
            this.btnContractMaintenance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnContractMaintenance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnContractMaintenance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnContractMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnContractMaintenance.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContractMaintenance.ForeColor = System.Drawing.Color.Black;
            this.btnContractMaintenance.Location = new System.Drawing.Point(4, 177);
            this.btnContractMaintenance.Name = "btnContractMaintenance";
            this.btnContractMaintenance.Size = new System.Drawing.Size(132, 35);
            this.btnContractMaintenance.TabIndex = 77;
            this.btnContractMaintenance.Tag = "ContractMaintenance";
            this.btnContractMaintenance.Text = "Contract Main.";
            this.btnContractMaintenance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnContractMaintenance.UseVisualStyleBackColor = false;
            this.btnContractMaintenance.Click += new System.EventHandler(this.btnContractMaintenance_Click);
            // 
            // btnClientMaintenance
            // 
            this.btnClientMaintenance.BackColor = System.Drawing.Color.White;
            this.btnClientMaintenance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClientMaintenance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnClientMaintenance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnClientMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClientMaintenance.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientMaintenance.ForeColor = System.Drawing.Color.Black;
            this.btnClientMaintenance.Location = new System.Drawing.Point(4, 136);
            this.btnClientMaintenance.Name = "btnClientMaintenance";
            this.btnClientMaintenance.Size = new System.Drawing.Size(132, 35);
            this.btnClientMaintenance.TabIndex = 75;
            this.btnClientMaintenance.Tag = "ClientMaintenance";
            this.btnClientMaintenance.Text = "Client Main.";
            this.btnClientMaintenance.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClientMaintenance.UseVisualStyleBackColor = false;
            this.btnClientMaintenance.Click += new System.EventHandler(this.btnClientMaintenance_Click);
            // 
            // btnServiceDepartment
            // 
            this.btnServiceDepartment.BackColor = System.Drawing.Color.White;
            this.btnServiceDepartment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServiceDepartment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnServiceDepartment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnServiceDepartment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServiceDepartment.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnServiceDepartment.ForeColor = System.Drawing.Color.Black;
            this.btnServiceDepartment.Location = new System.Drawing.Point(4, 95);
            this.btnServiceDepartment.Name = "btnServiceDepartment";
            this.btnServiceDepartment.Size = new System.Drawing.Size(132, 35);
            this.btnServiceDepartment.TabIndex = 73;
            this.btnServiceDepartment.Tag = "ServiceDepartment";
            this.btnServiceDepartment.Text = "Service Dept.";
            this.btnServiceDepartment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnServiceDepartment.UseVisualStyleBackColor = false;
            this.btnServiceDepartment.Click += new System.EventHandler(this.btnServiceDepartment_Click);
            // 
            // btnCallCentre
            // 
            this.btnCallCentre.BackColor = System.Drawing.Color.White;
            this.btnCallCentre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCallCentre.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCallCentre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.btnCallCentre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnCallCentre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCallCentre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallCentre.ForeColor = System.Drawing.Color.Black;
            this.btnCallCentre.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCallCentre.Location = new System.Drawing.Point(4, 54);
            this.btnCallCentre.Name = "btnCallCentre";
            this.btnCallCentre.Size = new System.Drawing.Size(132, 35);
            this.btnCallCentre.TabIndex = 67;
            this.btnCallCentre.Tag = "CallCentre";
            this.btnCallCentre.Text = "Call Centre";
            this.btnCallCentre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCallCentre.UseVisualStyleBackColor = false;
            this.btnCallCentre.Click += new System.EventHandler(this.btnCallCentre_Click);
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.Black;
            this.pnlTitleBar.Controls.Add(this.picExit);
            this.pnlTitleBar.Controls.Add(this.picPSS);
            this.pnlTitleBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTitleBar.Name = "pnlTitleBar";
            this.pnlTitleBar.Size = new System.Drawing.Size(1000, 50);
            this.pnlTitleBar.TabIndex = 38;
            this.pnlTitleBar.Tag = "TitleBar";
            // 
            // picExit
            // 
            this.picExit.BackColor = System.Drawing.Color.Transparent;
            this.picExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picExit.BackgroundImage")));
            this.picExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picExit.Location = new System.Drawing.Point(949, 9);
            this.picExit.Name = "picExit";
            this.picExit.Size = new System.Drawing.Size(24, 30);
            this.picExit.TabIndex = 1;
            this.picExit.TabStop = false;
            this.picExit.Click += new System.EventHandler(this.picExit_Click);
            // 
            // picPSS
            // 
            this.picPSS.BackColor = System.Drawing.Color.Transparent;
            this.picPSS.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picPSS.BackgroundImage")));
            this.picPSS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPSS.Location = new System.Drawing.Point(12, 9);
            this.picPSS.Name = "picPSS";
            this.picPSS.Size = new System.Drawing.Size(70, 35);
            this.picPSS.TabIndex = 0;
            this.picPSS.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Location = new System.Drawing.Point(342, 58);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(125, 125);
            this.pictureBox4.TabIndex = 48;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Location = new System.Drawing.Point(473, 58);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(125, 125);
            this.pictureBox3.TabIndex = 47;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(604, 58);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 125);
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(735, 58);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 125);
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            // 
            // picNumbers5
            // 
            this.picNumbers5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picNumbers5.Location = new System.Drawing.Point(866, 58);
            this.picNumbers5.Name = "picNumbers5";
            this.picNumbers5.Size = new System.Drawing.Size(125, 125);
            this.picNumbers5.TabIndex = 44;
            this.picNumbers5.TabStop = false;
            // 
            // picGraph3
            // 
            this.picGraph3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGraph3.Location = new System.Drawing.Point(342, 189);
            this.picGraph3.Name = "picGraph3";
            this.picGraph3.Size = new System.Drawing.Size(649, 402);
            this.picGraph3.TabIndex = 43;
            this.picGraph3.TabStop = false;
            // 
            // picGraph1
            // 
            this.picGraph1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGraph1.Location = new System.Drawing.Point(150, 58);
            this.picGraph1.Name = "picGraph1";
            this.picGraph1.Size = new System.Drawing.Size(186, 341);
            this.picGraph1.TabIndex = 42;
            this.picGraph1.TabStop = false;
            // 
            // picGraph2
            // 
            this.picGraph2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picGraph2.Location = new System.Drawing.Point(150, 405);
            this.picGraph2.Name = "picGraph2";
            this.picGraph2.Size = new System.Drawing.Size(186, 186);
            this.picGraph2.TabIndex = 41;
            this.picGraph2.TabStop = false;
            // 
            // frmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.picNumbers5);
            this.Controls.Add(this.picGraph3);
            this.Controls.Add(this.picGraph1);
            this.Controls.Add(this.picGraph2);
            this.Controls.Add(this.pnlTitleBar);
            this.Controls.Add(this.pnlButtons);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.frmHome_Load);
            this.pnlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picReports)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picContractMaintenance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClientMaintenance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceDepartment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCallCentre)).EndInit();
            this.pnlTitleBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPSS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNumbers5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGraph2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlButtons;
        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Button btnCallCentre;
        private System.Windows.Forms.PictureBox picGraph2;
        private System.Windows.Forms.PictureBox picGraph1;
        private System.Windows.Forms.PictureBox picGraph3;
        private System.Windows.Forms.PictureBox picNumbers5;
        private System.Windows.Forms.PictureBox picPSS;
        private System.Windows.Forms.Button btnServiceDepartment;
        private System.Windows.Forms.Button btnContractMaintenance;
        private System.Windows.Forms.Button btnClientMaintenance;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.PictureBox picExit;
        private System.Windows.Forms.PictureBox picReports;
        private System.Windows.Forms.PictureBox picContractMaintenance;
        private System.Windows.Forms.PictureBox picClientMaintenance;
        private System.Windows.Forms.PictureBox picServiceDepartment;
        private System.Windows.Forms.PictureBox picCallCentre;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}