﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmServiceContract : Form
    {
        public static int frmCount = 0;
        public static string frmState = "";
        private UIManager uim;
        private DataHandler dlh = new DataHandler();
        private Dictionary<string, object> recordDetails = new Dictionary<string, object>();
        private List<Client> clients = new List<Client>();
        private List<ServicePackage> packages = new List<ServicePackage>();
        private List<SLA> slas = new List<SLA>();
        public frmServiceContract()
        {
            InitializeComponent();
        }
        private void frmServiceContract_Load(object sender, EventArgs e)
        {
            uim = new UIManager(this, titleBar: pnlTitleBar, subControls: pnlControls);
            uim.RegisterControlEvents();
            recordDetails = UIManager.recordDetails;
        }
        private void frmServiceContract_Shown(object sender, EventArgs e)
        {
            frmCount = 1;
            packages = dlh.GetPackages();
            slas = dlh.GetSLAs();
            clients = dlh.GetClients();
            uim.AddListToCmb(packages, cmbPackageID, p => p.PackageID.ToString());
            uim.AddListToCmb(slas, cmbSlaID, s => s.SlaID.ToString());
            uim.AddListToCmb(clients, cmbClientID, c => c.ClientID.ToString());
            uim.SetControlState(frmState.ToLower());
            if (frmState.ToLower() == "create")
            {
                uim.ClearControls(this);
            }
        }
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (uim.ValidateInput(pnlControls) == 0)
            {
                DateTime? purchaseDate = dtpPurchaseDate.Checked ? dtpPurchaseDate.Value.Date : (DateTime?)null;
                DateTime? effectDate = dtpEffectDate.Checked ? dtpEffectDate.Value.Date : (DateTime?)null;
                DateTime? expiryDate = dtpExpiryDate.Checked ? dtpExpiryDate.Value.Date : (DateTime?)null;

                ServiceContract contract = new ServiceContract(
                    0, int.Parse(cmbPackageID.Text),
                    int.Parse(cmbSlaID.Text),
                    cmbStatus.Text, 
                    rtbDetails.Text,
                    cmbCategory.Text,
                    dtpPurchaseDate.Value.Date,
                    dtpEffectDate.Value.Date,
                    dtpExpiryDate.Value.Date
                    );
                DialogResult result = MessageBox.Show("Confirm?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dlh.CreateServiceContract(contract);
                    uim.ClearControls(this);
                    MessageBox.Show("Contract created.");
                }
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmCount = 0;
            Hide();
        }
    }
}
