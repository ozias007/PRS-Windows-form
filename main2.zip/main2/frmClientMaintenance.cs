﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Main
{
    public partial class frmClientMaintenance : Form
    {
        private int click = 0;
        private string frmState = "";
        private UIManager uim;
        private DataHandler dhl = new DataHandler();
        private List<ListBox> btnLsts = new List<ListBox>();
        private string[] arrClient = { "All", "Create" };
        private string[] arrSLA = { "All", "Create" };
        private string[] arrServiceContract = { "All", "Create" };
        public frmClientMaintenance()
        {
            InitializeComponent();
        }

        private void frmClientMaintenance_Load(object sender, EventArgs e)
        {
            foreach (Control cntrl in pnlButtons.Controls)
            {
                if (cntrl is ListBox lst) { btnLsts.Add(lst); }
            }
            uim = new UIManager(this, pnlTitleBar, picExit, pnlButtons, btnLsts, dgvClientMaintenance, cmbSearch, txtSearch);
            uim.dgvTemplate(dgvClientMaintenance);
            dhl.LoadClientData(dgvClientMaintenance);
            UIManager.dgvState = "Client";
            ActiveControl = picTitleIcon;
            uim.RegisterControlEvents();
        }

        private void picExit_Click(object sender, EventArgs e)
        {
            Hide();
            uim.ShowForm("Main.frmHome");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            uim.Search(txtSearch.Text, cmbSearch.Text);
        }

        private void btnClient_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnClient, pnlButtons);
            uim.SetListState(lstClient, arrClient, btnClient);
        }

        private void btnSLA_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnSLA, pnlButtons);
            uim.SetListState(lstSLA, arrSLA, btnSLA);
        }

        private void btnServiceContract_Click(object sender, EventArgs e)
        {
            click = uim.SetButtonState(click, btnServiceContract, pnlButtons);
            uim.SetListState(lstServiceContract, arrServiceContract, btnServiceContract);
        }
    }
}
